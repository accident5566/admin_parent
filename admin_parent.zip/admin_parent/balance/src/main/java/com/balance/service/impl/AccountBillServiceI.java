package com.balance.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import com.admin_base.model.BalAccountBill;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.HttpUtil;
import com.admin_base.util.PageIndex;
import com.admin_base.util.UrlAttribute;
import com.balance.service.AccountBillService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class AccountBillServiceI  implements AccountBillService{
	
	private static final Logger log = Logger.getLogger(UserAccountManageServiceI.class);

	//��ѯ�û���ˮ��Ϣ
	@SuppressWarnings("unchecked")
	@Override
	public List<BalAccountBill> getAccountBillInfo(HashMap<String,String> parms,PageParameter pageView) {
		log.info("��ѯ�û���ˮ��Ϣ��ʼ-----start");
		Map<String,Object> responseResult = null;
		PageIndex pageIndex= new PageIndex(0, 0);
		HttpUtil httpUtil = new HttpUtil();
		String paramsStrBase =UrlAttribute.getUrl(parms);
		responseResult = httpUtil.sendHttpRequest("pay.gateway", "accountBill.info.query", paramsStrBase, "GET");
		String result = responseResult.get("respContent").toString();
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode json = mapper.readTree(result);
			JsonNode jsonNodeT = json.path("totalCount");
			String totalCount = jsonNodeT.toString();
			JsonNode jsonNodeP = json.path("pageCount");
			String pageCount = jsonNodeP.toString();
			JsonNode jsonNode = json.path("data");
			String jsonStr = jsonNode.toString();
			pageView.setRowCount(Integer.parseInt(totalCount));
			if(pageView.getPageNow()<=3)
			{
			    pageIndex.setStartindex(1);
			    if(Integer.parseInt(pageCount)>=5){
			    pageIndex.setEndindex(5);
			    }
			    else{
			    	pageIndex.setEndindex(Integer.parseInt(pageCount));
			    }
			pageView.setPageindex(pageIndex);
			}
			List<BalAccountBill> list  = (List<BalAccountBill>) mapper.readValue(jsonStr, mapper.getTypeFactory().constructParametricType(List.class, BalAccountBill.class));
				 log.info("��ѯ�û���ˮ��Ϣ����-----end");
				 return list;
		}
		 catch (Exception e) {
			e.printStackTrace();
			log.error("��ѯ�û���ˮ��Ϣ�����쳣----exception-----�쳣��ԭ����:" + e.getMessage());
			return null;
		}
	}
}
