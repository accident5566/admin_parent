package com.balance.service.impl;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.model.GlobalParameter;
import com.admin_base.model.WCRecords;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.AddressUtils;
import com.balance.dao.WCRecordsDao;
import com.balance.service.GlobalParameterService;
import com.balance.service.WCRecordsService;

/**
 * @see ���������¼service�ӿڶ���ʵ��
 * @author peiwei
 * @Date 2015-11-23
 */
@Service
public class WCRecordsServiceI implements WCRecordsService {

	@Autowired private WCRecordsDao  wCRecordsDaoI;

	@Autowired private GlobalParameterService globalParameterServiceI;
	
	@Override
	public List<WCRecords> getWCRecordsByPage(PageParameter pageView,WCRecords wCRecords) throws UnsupportedEncodingException {
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", wCRecords);
		parameterMap.put("page", pageView);
		List<WCRecords> wCRecordsList = wCRecordsDaoI.getByPage(parameterMap);
		for(WCRecords s:wCRecordsList){
			s.setIp(s.getProvince()+"=="+s.getCity());
		s.setDangerousLevel(setLevel(s));
		}
		return wCRecordsList;
	}

	@Override
	public boolean updateWCRecords(WCRecords wCRecords) {
		return wCRecordsDaoI.updateWCRecords(wCRecords) > 0 ? true : false;
	}

	@Override
	public boolean withdrawCheckIsFrst(WCRecords wCRecords) {//�Ƿ��״����
		List<WCRecords> wCRecordsList =  wCRecordsDaoI.getWCRecordsByUserAndCard(wCRecords);
		if(null != wCRecordsList && wCRecordsList.size() > 0){
			return false;
		}
		return true; 
	}

	@Override
	public boolean ipWhetherLike(WCRecords wCRecords) throws UnsupportedEncodingException {//ip�Ƚ�
		String ip = wCRecords.getIp();
		List<WCRecords> wCRecordsList =  wCRecordsDaoI.getWCRecordsByUser(wCRecords);
		if(null != wCRecordsList && wCRecordsList.size() > 0){
			for(WCRecords wcr:wCRecordsList){
				if(wcr.getIp().equals(ip)){
				  return false;
				}
			}
		}
		if(null == wCRecordsList || wCRecordsList.size() <= 0){
			return false;
		}
		return true;
	}

	@Override
	public boolean isGreaterThanAmount(WCRecords wCRecords) {//�Ƿ񳬹��޶�
		BigDecimal  applyAmount = wCRecords.getApplyAmount();
		BigDecimal  totalAmount = new BigDecimal(globalParameterServiceI.getGlobalParameterByOne(new GlobalParameter("withdraw_upperLimit")).getParameterValue());
		if(totalAmount.compareTo(applyAmount) < 0){
			return true;
		}
		return false;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean isVeryTime(WCRecords wCRecords) {//�����Ƿ�����0-5��
		int applyHour = wCRecords.getApplyDate().getHours();
		if(applyHour >=0 && applyHour<=5){
			return true;
		}
		return false;
	}

	@Override
	public boolean isThanNum(WCRecords wCRecords) {//�Ƿ񳬹�����������ִ�������
		int num1 =  wCRecordsDaoI.getWithdrawCount(wCRecords);
		int num2 = Integer.valueOf(globalParameterServiceI.getGlobalParameterByOne(new GlobalParameter("withdraw_freeTimes")).getParameterValue());
		if(num1 > num2){
			return true;
		}
		return false;
	}

	@Override
	public String setLevel(WCRecords wCRecords) throws UnsupportedEncodingException {
		boolean isFrstFlag = withdrawCheckIsFrst(wCRecords);
		boolean ipWhetherLikeFlag = ipWhetherLike(wCRecords);
		boolean isGreaterThanFlag = isGreaterThanAmount(wCRecords);
		boolean isVeryTimeFlag = isVeryTime(wCRecords);
		boolean isThanNumFlag = isThanNum(wCRecords);
		//S����
		if(isFrstFlag && ipWhetherLikeFlag && isGreaterThanFlag && isVeryTimeFlag && isThanNumFlag){
			return "S";
		}
		//A����
		int booleanCount = getFlagCount(isFrstFlag,ipWhetherLikeFlag,isGreaterThanFlag,isVeryTimeFlag,isThanNumFlag);
		if(booleanCount >= 4){
			return "A";
		}
		//B����
		if(booleanCount == 3 || (isFrstFlag && isGreaterThanFlag)){
			return "B";
		}
		//C����
		if(booleanCount == 2){
			if(isFrstFlag && isGreaterThanFlag){
				return "B";
			}
			return "C";
		}
		//D��
		if(booleanCount == 1){
			return "D";
		}
		return null;
	}
	
	public int getFlagCount(boolean isFrstFlag,boolean ipWhetherLikeFlag,boolean isGreaterThanFlag,boolean isVeryTimeFlag,boolean isThanNumFlag){
		int count =0;
		List<Boolean> booleanList = new ArrayList<Boolean>();
		booleanList.add(isFrstFlag);
		booleanList.add(ipWhetherLikeFlag);
		booleanList.add(isGreaterThanFlag);
		booleanList.add(isVeryTimeFlag);
		booleanList.add(isThanNumFlag);
		for(Boolean b : booleanList){
			if(b){
				count = count + 1;
			}
		}
		return count;
	}

	@Override
	public Integer totalGreaterCount(WCRecords wCRecords) {
		return wCRecordsDaoI.totalGreaterCount(wCRecords);
	}

	@Override
	public BigDecimal totalGreaterMoney(WCRecords wCRecords) {
		return wCRecordsDaoI.totalGreaterMoney(wCRecords);
	}

	@Override
	public Integer getWithdrawCount(WCRecords wCRecords) {
		return wCRecordsDaoI.getWithdrawCount(wCRecords);
	}
	
	
	
}
