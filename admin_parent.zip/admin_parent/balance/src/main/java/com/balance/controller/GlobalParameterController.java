package com.balance.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.GlobalParameter;
import com.admin_base.mybatis.plug.PageParameter;
import com.balance.service.GlobalParameterService;

/**
*  @see ȫ�ֲ���controller�ӿڶ���
 * @author peiwei
 * @Date 2015-11-23
 */
@Controller("GlobalParameterController")
@RequestMapping("/globalParameter")
public class GlobalParameterController {
	
	@Autowired private GlobalParameterService globalParameterServiceI;
	
	
	@RequestMapping(value="/getParamtersByPage",method = RequestMethod.GET)
	public ModelAndView getParamters(HttpServletRequest request, HttpServletResponse response,PageParameter pageView, GlobalParameter  globalParameter) throws IOException{
		if("".equals(pageView.getPageNow()) || pageView == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(pageView.getPageNow());
		}
		ModelAndView model = new ModelAndView();
		model.addObject("paramtersList",globalParameterServiceI.getGlobalParameterByPage(pageView, globalParameter));
		model.addObject("pageView",pageView);
		model.setViewName("balance/withdrawCheckManagement/withdrawConfigManager");
		return model;
	}
}
