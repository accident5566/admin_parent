package com.balance.mq;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;

import com.admin_base.constant.DateFormatConstant;
import com.admin_base.constant.MessageContent;
import com.admin_base.model.BalanceAmount;
import com.admin_base.model.WCRecords;
import com.admin_base.util.HttpUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

public class WithdrawcallListener {
	
	private static final Logger log = Logger.getLogger(WithdrawcallListener.class);
	
	public void listen(String wCRecordsList) throws Exception{
		
	   HttpUtil http = new HttpUtil();
	   log.info("������������Ϣ�ķ���------------ʱ����:"+new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS).format(new Date()));
	   System.out.println("������������Ϣ�ķ���------------ʱ����:"+new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS).format(new Date())+"��Ϣ������������:");
	   ObjectMapper mapper = new ObjectMapper();
	   List<WCRecords> list  = (List<WCRecords>) mapper.readValue(wCRecordsList, mapper.getTypeFactory().constructParametricType(List.class, WCRecords.class));
	   if(list.size() > 0 && list != null){
	   for(WCRecords w:list){
		   String bankCard = w.getBankCardNo().substring(w.getBankCardNo().length()-4,w.getBankCardNo().length());
		   String msgContent = String.format(MessageContent.verifyCodeTemplateyWithdraw,String.valueOf(w.getApplyAmount()),bankCard);
		   http.sendMsg(w.getCellphone(), msgContent);
	   }		
	 }
		
	
	
	}
	
}
