package com.balance.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.GlobalParameter;


/**
*  @see ȫ�ֲ������ݿ����DAO
 * @author peiwei
 * @Date 2015-11-23
 */
public interface GlobalParameterDao extends BaseMapper<GlobalParameter>{

  public GlobalParameter getGlobalParameterByOne(GlobalParameter globalParameter);
  
}
