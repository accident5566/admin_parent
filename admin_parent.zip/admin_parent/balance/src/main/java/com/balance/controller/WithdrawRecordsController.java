package com.balance.controller;

import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.admin_base.constant.WithdrawStatusConstant;
import com.admin_base.model.BalAccountBill;
import com.admin_base.mybatis.plug.PageParameter;
import com.balance.service.AccountBillService;

/***
 * ����˻�ϵͳ-����¼Controller
 * @author guxiaojun
 * @Date 2015-11-24
*/
@Controller("/withdrawRecordsController ")
@RequestMapping("/withdrawRecordsInfo")
public class WithdrawRecordsController {
	
	@Autowired private AccountBillService AccountBillServiceI;
	
	@RequestMapping(value="/getWithdrawRecordsInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getWithdrawRecordsInfo(HttpServletRequest request, HttpServletResponse response){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		String status  = request.getParameter("status");
		String cellphone  = request.getParameter("cellphone");
		String startAt  = request.getParameter("startAt");
		String endAt  = request.getParameter("endAt");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		//ƴװ��ѯ����
		HashMap<String,String> parms = new HashMap<String,String>();
		parms.put("pageNumber", String.valueOf(pageView.getPageNow()));
		parms.put("limitNum","10");
		parms.put("type","30");
		if(cellphone!=null){
		parms.put("cellphone",cellphone);
		}
		if(status!=null){
	    parms.put("status",status);
		}
		if(startAt!=null){
		    parms.put("startAt",startAt);
		}
		if(endAt!=null){
		    parms.put("endAt",endAt);
		}
		ModelAndView  model = new ModelAndView();
		model.addObject("statusList", WithdrawStatusConstant.getComUtil());
		model.addObject("resultList", AccountBillServiceI.getAccountBillInfo(parms,pageView));
		model.addObject("cellphone", cellphone);	
		model.addObject("pageView", pageView);	
		model.addObject("status", status);	
		model.addObject("startAt", startAt);	
		model.addObject("endAt", endAt);	
		model.setViewName("balance/withdrawCheckManagement/withdrawRecordsManager");
		return model;	
}
}
