package com.balance.service;

import java.util.List;

import com.admin_base.model.GlobalParameter;
import com.admin_base.mybatis.plug.PageParameter;

/**
*  @see ȫ�ֲ���service�ӿڶ���
 * @author peiwei
 * @Date 2015-11-23
 */
public interface GlobalParameterService {

	public List<GlobalParameter> getGlobalParameterByPage(PageParameter pageView, GlobalParameter orders);
	
	 public GlobalParameter getGlobalParameterByOne(GlobalParameter globalParameter);
	
}
