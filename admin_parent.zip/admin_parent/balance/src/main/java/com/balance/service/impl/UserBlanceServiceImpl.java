package com.balance.service.impl;

import com.admin_base.dto.balance.BalanceAddMoneyDTO;
import com.admin_base.util.HttpUtil;
import com.admin_base.util.MessageResult;
import com.admin_base.util.ServiceCode;
import com.balance.service.UserBalanceService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * �û�������ʵ��
 * @author Chengfei.Sun on 2015/12/1.
 */
@Service
public class UserBlanceServiceImpl implements UserBalanceService{
    @Override
    public MessageResult addMoney(BalanceAddMoneyDTO balanceAddMoneyDTO) {
        MessageResult messageResult = new MessageResult();
        try {
            HttpUtil httpUtil = new HttpUtil();
            Map<String, Object> responseResult = httpUtil.sendHttpRequestVersionTwo("pay.gateway", "balance.batch.addMoney", balanceAddMoneyDTO);
            String result = (String) responseResult.get("respContent");
            ObjectMapper mapper = new ObjectMapper();
            JsonNode json = mapper.readTree(result);
            messageResult.setResultCode(json.findValue("resultCode").textValue());
            messageResult.setMessage(json.findValue("message").textValue());
        } catch (Exception e) {
            messageResult.setResultCode(ServiceCode.BALANCE_ADD_MONEY_FAIL.getCode());
            messageResult.setMessage(ServiceCode.BALANCE_ADD_MONEY_FAIL.getText());
        }
        return messageResult;
    }
}
