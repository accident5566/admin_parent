package com.balance.service;

import java.util.List;

import com.admin_base.dto.request.WithdrawConfirmDTO;
import com.admin_base.model.WCRecords;
import com.admin_base.model.WithdrawConfirm;

public interface WithdrawConfirmService {

	public List<WCRecords> getWCRecords(WCRecords  wCRecords);
	
	public boolean updateWithdrawStatus(List<WCRecords> wCRecordsList);
	
	public boolean withdraw(List<WCRecords> wCRecordsList);
}
