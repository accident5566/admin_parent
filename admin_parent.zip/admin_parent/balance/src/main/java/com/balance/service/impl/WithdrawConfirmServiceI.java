package com.balance.service.impl;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.admin_base.dto.request.WithdrawConfirmDTO;
import com.admin_base.model.WCRecords;
import com.admin_base.model.WithdrawConfirm;
import com.admin_base.util.HttpUtil;
import com.balance.dao.WCRecordsDao;
import com.balance.service.WithdrawConfirmService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
@Service
public class WithdrawConfirmServiceI implements WithdrawConfirmService{
	
	@Autowired private WCRecordsDao  wCRecordsDaoI;

	@Override
	public List<WCRecords> getWCRecords(WCRecords  wCRecords) {
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", wCRecords);
		List<WCRecords> wCRecordsList =wCRecordsDaoI.getAllWithdraw(parameterMap);
		return wCRecordsList;
	}

	@Override
	public boolean updateWithdrawStatus(List<WCRecords> wCRecordsList) {
		WithdrawConfirmDTO requestDTO = new WithdrawConfirmDTO("TX"+ new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()),wCRecordsList);
		List<WithdrawConfirm> properties = requestDTO.getProperties();
		boolean flag = true;
		try {
			for(WithdrawConfirm w:properties){
			wCRecordsDaoI.updateWithdrawStatus(w);
			}
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean withdraw(List<WCRecords> wCRecordsList){
		boolean flag = true;
		//��װ����DTO
		WithdrawConfirmDTO requestDTO = new WithdrawConfirmDTO("TX"+ new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()),wCRecordsList);
		HttpUtil httpUtil = new HttpUtil();
		Map<String,Object> responseResult = null;
		responseResult = httpUtil.sendHttpRequestVersionTwo("pay.gateway", "withdrawconfirm.info.send", requestDTO);
		String result = responseResult.get("respContent").toString();
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode json = mapper.readTree(result);
			JsonNode jsonNode = json.path("resultCode");
			String jsonStr = jsonNode.toString().replaceAll("\"", "").replaceAll("\"", "");
			
			if(!jsonStr.equals("0000")&&!jsonStr.equals("00A4")){
				flag = false;
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	


}
