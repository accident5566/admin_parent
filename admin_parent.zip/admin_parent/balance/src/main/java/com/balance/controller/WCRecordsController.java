package com.balance.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.GlobalParameter;
import com.admin_base.model.WCRecords;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.DateUtil;
import com.balance.service.GlobalParameterService;
import com.balance.service.WCRecordsService;


/**
 * @see ���������¼controller�ӿڶ���
 * @author peiwei
 * @Date 2015-11-23
 */
@RequestMapping("/WCRecords")
@Controller
public class WCRecordsController {
	
	@Autowired private WCRecordsService wCRecordsServiceI;
	
	@Autowired private GlobalParameterService gls;
	
	@RequestMapping(value="/getWCRecordsByPage",method = RequestMethod.GET)
	public ModelAndView getWCRecords(HttpServletRequest request, HttpServletResponse response,PageParameter pageView, WCRecords  wCRecords) throws IOException{
		if("".equals(pageView.getPageNow()) || pageView == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(pageView.getPageNow());
		}
		if(null != wCRecords && wCRecords.getHours() != null){
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}
		if(null != wCRecords && wCRecords.getHours() == null && wCRecords.getCellphone() == null){
			wCRecords = new WCRecords();
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}else{
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("wcreordsList",wCRecordsServiceI.getWCRecordsByPage(pageView, wCRecords));
		System.out.println(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue());
		model.addObject("paramdate",gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue());
		model.addObject("wCRecords",wCRecords);
		model.addObject("pageView",pageView);
		WCRecords wCRecords2 = new WCRecords();
		wCRecords2.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		model.addObject("successtotalGreaterCount", wCRecordsServiceI.totalGreaterCount(new WCRecords(wCRecords2,0)));
		model.addObject("successtotalGreaterMoney", wCRecordsServiceI.totalGreaterMoney(new WCRecords(wCRecords2,0)));
		model.addObject("errortotalGreaterCount", wCRecordsServiceI.totalGreaterCount(new WCRecords(wCRecords2,2)));
		model.addObject("errortotalGreaterMoney", wCRecordsServiceI.totalGreaterMoney(new WCRecords(wCRecords2,2)));
		model.setViewName("balance/withdrawCheckManagement/withdrawCheckManager");
		return model;
	}
	
	@RequestMapping(value="/updateWCRecords",method = RequestMethod.GET)
	public String  updateWCRecords(HttpServletRequest request, HttpServletResponse response,WCRecords  wCRecords) throws IOException{
		boolean flag = wCRecordsServiceI.updateWCRecords(new WCRecords(wCRecords));
		if(flag){
		   return "redirect:/WCRecords/getWCRecordsByPage ";
		}else{
			return null;
		}
	}

}
