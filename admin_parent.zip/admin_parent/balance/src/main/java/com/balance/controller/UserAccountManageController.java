package com.balance.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.BalanceAmount;
import com.admin_base.mybatis.plug.PageParameter;
import com.balance.service.AccountBillService;
import com.balance.service.UserAccountManageService;

/***
 * ����˻�ϵͳ-�û�������Ϣ����Controller
 * @author guxiaojun
 * @Date 2015-11-18
*/
@Controller("/userAccountManageController ")
@RequestMapping("/userManageInfo")
public class UserAccountManageController {
	
	@Autowired private UserAccountManageService userAccountManageServiceI;
	@Autowired private AccountBillService accountBillServiceI;
	
	@RequestMapping(value="/getUserAccountInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getUserAccountInfo(HttpServletRequest request, HttpServletResponse response,BalanceAmount balance){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("pageView",pageView);
		model.addObject("balanceList",userAccountManageServiceI.getUserInfoByPage(pageView, balance));
		model.setViewName("balance/balanceManagement/balanceManager");
		return model;
	}

	//ͨ���û�UUID��ѯ�����˻��ʽ�
	@RequestMapping(value="/getBalanceByPerson",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getBalanceByPerson(HttpServletRequest request, HttpServletResponse response,BalanceAmount balanceAmount){
		ModelAndView model = new ModelAndView();
		BalanceAmount balance =userAccountManageServiceI.getUserBalance(balanceAmount);
	    model.addObject("balance",balance);
	    model.setViewName("balance/balanceManagement/balanceManagerDetail");
	    return model;	
	}
	
	

	//ͨ���û�UUID��ѯ������ˮ��Ϣ
	@RequestMapping(value="/getAccountBillByPerson",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getAccountBillByPerson(HttpServletRequest request, HttpServletResponse response, BalanceAmount balanceAmount){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		String userIdentifier = balanceAmount.getUserIdentifier().trim();
		//ƴװ��ѯ����
		HashMap<String,String> parms = new HashMap<String,String>();
		parms.put("pageNumber", String.valueOf(pageView.getPageNow()));
		parms.put("userIdentifier",userIdentifier);
		parms.put("limitNum","10");
		ModelAndView  model = new ModelAndView();
		model.addObject("resultList", accountBillServiceI.getAccountBillInfo(parms, pageView));
		parms.clear();
		model.addObject("pageView", pageView);	
		model.addObject("userIdentifier", userIdentifier);
		model.setViewName("balance/balanceManagement/balanceDetail");
		return model;	
	}
}
