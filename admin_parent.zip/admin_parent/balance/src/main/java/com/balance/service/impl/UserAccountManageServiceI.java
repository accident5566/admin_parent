package com.balance.service.impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.admin_base.model.BalanceAmount;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.HttpUtil;
import com.admin_base.util.UrlAttribute;
import com.balance.dao.UserAccountManageDao;
import com.balance.service.UserAccountManageService;

@Service
public class UserAccountManageServiceI  implements UserAccountManageService{
	
	private static final Logger log = Logger.getLogger(UserAccountManageServiceI.class);
	@Autowired private UserAccountManageDao userAccountManageDao;

	@Override@SuppressWarnings("unchecked")
	public BalanceAmount getUserBalanceInfo(HashMap<String,String> parms) {
		log.info("��ѯ�û��˻���Ϣ��ʼ-----start");
		Map<String, Object> responseResult = null;
		HttpUtil httpUtil = new HttpUtil();
		String paramsStrBase =UrlAttribute.getUrl(parms);
		responseResult = httpUtil.sendHttpRequest("pay.gateway", "useraccount.info.query", paramsStrBase, "GET");
		String resResult = responseResult.get("respContent").toString();
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode json = mapper.readTree(resResult);
			JsonNode jsonNode = json.path("properties");
			String jsonStr = jsonNode.toString().replaceAll("\\[", "").replaceAll("\\]", "");
			JSONObject jsona = JSONObject.fromObject(jsonStr);
			BalanceAmount balanceFromPay = (BalanceAmount) JSONObject.toBean(jsona, BalanceAmount.class);
			log.info("��ѯ�û��˻���Ϣ����-----end");
			return balanceFromPay;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("��ѯ�û��˻���Ϣ�����쳣----exception-----�쳣��ԭ����:" + e.getMessage());
			return null;
		} 
	}

	//��ѯʵ����֤�û���Ϣ
	public List<BalanceAmount> getUserInfoByPage(PageParameter pageView,
			BalanceAmount balance) {
		List<BalanceAmount> balanceList = null;
		try {
			Map<String,Object> parameterMap = new HashMap<String,Object>();
			parameterMap.put("t", balance);
			parameterMap.put("page", pageView);
			balanceList = userAccountManageDao.getByPage(parameterMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return balanceList;
	}
	
	//��ѯ�����˻��ʽ�
		public BalanceAmount getUserBalance(BalanceAmount balance) {
			Map<String,Object> parameterMap = new HashMap<String,Object>();
			parameterMap.put("t", balance);
			BalanceAmount balanceAmount =userAccountManageDao.getAccAmount(parameterMap);
			balanceAmount =userAccountManageDao.getDueInInfo(parameterMap);
			//ƴװ��ѯ����
			HashMap<String,String> parms = new HashMap<String,String>();
			parms.put("userIdentifier", balance.getUserIdentifier());
			if(balanceAmount!=null){
		    balanceAmount.setAvailableAmount(this.getUserBalanceInfo(parms).getAvailableAmount());
		    balanceAmount.setFreezeAmount(this.getUserBalanceInfo(parms).getFreezeAmount());
			}
			return balanceAmount;		
		}
}
