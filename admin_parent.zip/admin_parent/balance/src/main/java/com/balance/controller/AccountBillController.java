package com.balance.controller;

import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.admin_base.model.BalAccountBill;
import com.admin_base.mybatis.plug.PageParameter;
import com.balance.service.AccountBillService;

/***
 * ����˻�ϵͳ-��ˮ��ѯController
 * @author guxiaojun
 * @Date 2015-11-18
*/
@Controller("/accountBillController ")
@RequestMapping("/accountBillinfo")
public class AccountBillController {
	
	@Autowired private AccountBillService AccountBillServiceI;
	
	//��ѯ�û���ˮ��Ϣ
	@RequestMapping(value="/getAccountBillInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getAccountBillServiceInfo(HttpServletRequest request, HttpServletResponse response,BalAccountBill balAccountBill){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		//ƴװ��ѯ����
		HashMap<String,String> parms = new HashMap<String,String>();
		parms.put("pageNumber", String.valueOf(pageView.getPageNow()));
		parms.put("limitNum","10");
		if(balAccountBill.getCellphone()==null){
		parms.put("cellphone","");
		}
		ModelAndView  model = new ModelAndView();
		model.addObject("resultList", AccountBillServiceI.getAccountBillInfo(parms,pageView));
		model.addObject("pageView", pageView);
		model.addObject("cellphone", balAccountBill.getCellphone());
		model.setViewName("balance/accountBillManagement/accountBill");
		return model;
}
}
