package com.balance.controller;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.admin_base.constant.MessageContent;
import com.admin_base.dto.request.WithdrawConfirmDTO;
import com.admin_base.model.GlobalParameter;
import com.admin_base.model.WCRecords;
import com.admin_base.model.WithdrawConfirm;
import com.admin_base.mq.MessageSend;
import com.admin_base.util.DateUtil;
import com.admin_base.util.HttpUtil;
import com.balance.service.GlobalParameterService;
import com.balance.service.WithdrawConfirmService;

/***
 * ����˻�ϵͳ-����¼Controller
 * @author guxiaojun
 * @Date 2015-11-24
*/
@Controller
@RequestMapping("/withdrawConfirmInfo")
public class WithdrawConfirmController {
	
	@Autowired private WithdrawConfirmService withdrawConfirmServiceI;
	@Autowired private MessageSend messageSend;
	
	@Autowired private GlobalParameterService gls;
	
	@RequestMapping(value="/getWithdrawConfirmInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public String getWithdrawConfirmInfo(HttpServletRequest request, HttpServletResponse response, WCRecords  wCRecords) throws IOException{
		if(null != wCRecords && wCRecords.getHours() != null){
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}
		if(null != wCRecords && wCRecords.getHours() == null && wCRecords.getCellphone() == null){
			wCRecords = new WCRecords();
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}else{
			wCRecords.setApplyDate(DateUtil.updateHours(Integer.valueOf(gls.getGlobalParameterByOne(new GlobalParameter("withdraw_deadLine")).getParameterValue())));
		}
		//�����������״̬Ϊ�����е�����
		List<WCRecords> wCRecordsList = withdrawConfirmServiceI.getWCRecords(wCRecords);
		//�ύ֧���ӿ���Ҫ�������
		boolean flag = withdrawConfirmServiceI.withdraw(wCRecordsList);
		//�ύ������ݳɹ�
		if(flag == true){
			//�������������ύ���ݵ�����״̬
			withdrawConfirmServiceI.updateWithdrawStatus(wCRecordsList);
			//������		
			JSONArray jsonArray = JSONArray.fromObject(wCRecordsList);
			messageSend.sendMsg(MessageContent.SRECEIVEDPAYMENT_KEY_2,jsonArray.toString());
			
			}
		return "forward:/WCRecords/getWCRecordsByPage";  
		
	}
}
	
