package com.balance.service.impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.model.GlobalParameter;
import com.admin_base.model.Orders;
import com.admin_base.mybatis.plug.PageParameter;
import com.balance.dao.GlobalParameterDao;
import com.balance.service.GlobalParameterService;
/**
*  @see ȫ�ֲ���service�ӿڶ���ʵ��
 * @author peiwei
 * @Date 2015-11-23
 */

@Service
public class GlobalParameterServiceI implements GlobalParameterService {

	@Autowired private GlobalParameterDao globalParameterDaoI;
	
	@Override
	public List<GlobalParameter> getGlobalParameterByPage(PageParameter pageView, GlobalParameter globalParameter) {
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", globalParameter);
		parameterMap.put("page", pageView);
		List<GlobalParameter> globalParameterList = globalParameterDaoI.getByPage(parameterMap);
		return globalParameterList;
	}

	@Override
	public GlobalParameter getGlobalParameterByOne(GlobalParameter globalParameter) {
		return globalParameterDaoI.getGlobalParameterByOne(globalParameter);
	}

}
