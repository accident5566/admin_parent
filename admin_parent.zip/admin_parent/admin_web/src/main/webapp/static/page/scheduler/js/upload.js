$(document).ready( function() {
	$.formValidator.initConfig({
		submitButtonID:"usersAddSubmit",
	    errorfocus: false,
	    submitonce: true,
	    tipstyle: "both",
	    onSuccess:function(){
	    	usersAdd();
	    },
	    onerror: function () { 
	    	alert("failure");
	    }
	});
	
	//1.用户名称校验
	$("#username").formValidator({
		onShow: "", 
		onFocus: "",
		onCorrect: "&nbsp;" 
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	}).regexValidator({
	    regExp:"^([+-]?)\\d*\\.?\\d+$",
	    onError:"格式不正确,纯数字长度6-12位"}).ajaxValidator({
		type: "post",             
        url:sy.basePath+"/users/users_usersCheckUnique.action",      
        data:$("#username").val(),
        dataType:"json",
        success: function(data) {
                 if(data && data.success){
                	 return true;
                 }else{
                	 return false;
                 }
        },
        error: function(jqXHR, textStatus, errorThrown){
        },
        onError : "&nbsp;",
        onWait : "&nbsp;"
	});
	//2.用户年龄校验

	
	//3.用户描述信息校验
	$("#usersDesc").formValidator({
		onShow: "", 
		onFocus: "",
		onCorrect: "&nbsp;" 
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	})
});

	//添加用户信息Ajax请求
	function usersAdd(){
		var username = $("#username").val();
		var userDesc = $("#usersDesc").val();
//		var userAge = $("#userAge").val();
		var userStatus = $("input[name='userstatus']:checked").val();
		var userSex = $("input[name='userSex']:checked").val();
		 $("#tipUserAdd").fadeIn(200);//确认提示框
		 $("#tipUserAdd a").click(function(){//点击X图片按钮
			  $("#tipUserAdd").fadeOut(100);
		 });
		 $("#cancelUserAdd").click(function(){//关闭提交操作
			  $("#tipUserAdd").fadeOut(100);
		 });
		 $("#sureUserAdd").click(function(){//确认提交Ajax请求到后台
			    $.ajax({   
  	     	   	     type:"post",
  	     	   	     data: {
  	     	   	    	 "users.uname":username,
  	     	   	    	 "users.usex":userSex,
  	     	   	    	 "users.udesc":userDesc,
//  	     	   	      "users.uAge":userAge,
  	     	   	    	 "users.ustatus":userStatus
  	     	   	     },   
  	     	   	     url:sy.basePath+"/users/users_usersAdd.action",
  	     	    	 dataType:"json",
  	     	         success:function(result){
  	     	        	$("#tipUserAdd").fadeOut(100);
  	     	        	 if(result && result.success){
							 location.href = sy.basePath+"/users/users_usersManager.action";
  	     		         }else{
  	     		        	 $("#tiprightUserAddErrorp").text(result.msg);//填充后台的错误提示信息
  	     		        	 $("#tipUserAddError").fadeIn(200)//错误提示框弹出
  	     		        	 $("#tipUserAddError a").click(function(){//点击X图标关闭窗体
  	     		        		 $("#tipUserAddError").fadeOut(200);
  	     		        	 });
  	     		         }
  	     		     },
  	     		     error:function(){
  	     	    		 alert("Ajax出现异常");
  	     	    	 }
  	     		});
		 });
	}