package com.admin.service.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.BaseMapper;
import com.admin.service.BaseService;

@Service
public class BaseServiceI<T>  implements BaseService<T>{

	@Autowired private BaseMapper<T> baseMapperI;
	
	@Override
	public boolean update(T t) {
		boolean flag = true;
		try {
			Integer returnCode = baseMapperI.update(t);
			if(returnCode <= 0){
				flag = false;
			}
		} catch (Exception e) {
		    flag = false;
		}
		return flag;
	}

	@Override
	public boolean save(T t) {
		boolean flag = true;
		try {
			Integer returnCode = baseMapperI.save(t);
			if(returnCode <= 0){
				flag = false;
			}
		} catch (Exception e) {
		    flag = false;
		}
		return flag;
	}

	@Override
	public boolean delete(T t) {
		boolean flag = true;
		try {
			Integer returnCode = baseMapperI.delete(t);
			if(returnCode <= 0){
				flag = false;
			}
		} catch (Exception e) {
		    flag = false;
		}
		return flag;
	}

	@Override
	public T getInfo(T t) {
		T tt = null;
		try {
		   tt = baseMapperI.getInfo(t);
		} catch (Exception e) {
			
		}
		return tt;
	}

}
