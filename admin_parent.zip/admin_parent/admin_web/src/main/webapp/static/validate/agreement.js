/**
 *  协议模板校验js代码展示
 */
/***************模板添加的js*******************************/
//1.表单提交的函数
 function submits(){
	 //1.1调用非空校验的函数
	 var returnCode = isBlank();
	 //1.2调用格式校验的函数
	 var returnFormatCheck = formatCheck();
	 //1.3判断条件如果都为true表单提交如果有一个函数返回为false就组织表单提交
	 if(returnCode){
		  if(returnFormatCheck){
			  return true;
		  }else{
			  return false;
		  }
	 }else{
		 return false;
		 
	  }
 }
/***************模板修改的js*******************************/
//1.表单提交的函数

//2.非空校验的函数

function isBlank(){
	   var arrayObj = new Array("#agreementName","#agreementContent");
	   for(var i=0;i<arrayObj.length;i++){
		 var testvalue = $(arrayObj[i]).val();
		 if(testvalue== ""){
			 $(arrayObj[i]+"Span").html("不为空");
   			 $(arrayObj[i]+"Span").show();
			 return false;
		 }else{
			if(i == 1){
				return true;
			}
  			 $(arrayObj[i]+"Span").hide();

		 }
	   }
}
//3.格式校验的函数
function formatCheck(){
    	var  agreementNameValue=$("#agreementName").val();//获取模板名称的文本框的内容
    	var  agreementFormat = /[\u4E00-\u9FA5\uF900-\uFA2D]/;//文本名称校验的格式
    	var  fomratResult = agreementFormat.test(agreementNameValue);//文本内容校验的返回值
    	if(fomratResult){
 			 $("#agreementNameSpan").hide();
 			 return  true;
    	}else{
    		 $("#agreementNameSpan").html("只能输入中文");
   			 $("#agreementNameSpan").show();
    		return false;
    	}
}