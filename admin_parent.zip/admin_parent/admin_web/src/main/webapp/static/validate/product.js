
$(function(){
	$('#name').change(function(){
		var   name=$('#name').val();
		if(name==""){
			document.getElementById("nameSpan").innerHTML="产品名称不为空";
    		document.getElementById("nameSpan").style.display="block";
    	    return    false; 
    	  }else{
    		  var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]") ;
    		  if((pattern).test(name)){
    			  document.getElementById("nameSpan").innerHTML="产品名称不要为特殊字符串";
    	    		document.getElementById("nameSpan").style.display="block";
    	    	    return    false; 
    		  }
      		document.getElementById("nameSpan").style.display="none";
    	  }
		});
	
	//金额
	$('#amount').change(function(){
		var   amount=$('#amount').val();
		if(!(/^\+?[1-9][0-9]*$/.test( amount ))){
			document.getElementById("amountSpan").innerHTML="融资金融必须是正数,开头非零";
    		document.getElementById("amountSpan").style.display="block";
    	    return    false; 
    	  }else{
      		document.getElementById("amountSpan").style.display="none";
 
    	}	});
	
	//单价
	$('#unitPrice').change(function(){
		var   unitPrice=$('#unitPrice').val();
		if(!(/^\+?[1-9][0-9]*$/.test( unitPrice ))){
			document.getElementById("unitPriceSpan").innerHTML="产品单价必须是正数,开头非零";
    		document.getElementById("unitPriceSpan").style.display="block";
    	    return  false; 
    	  }else{
        		document.getElementById("unitPriceSpan").style.display="none";
 
    	  }	});
	
	//最小
	$('#minNum').change(function(){
		var  minNum=$('#minNum').val();
		if(!(/^\+?[1-9][0-9]*$/.test( minNum ))){
			document.getElementById("minNumSpan").innerHTML="最小购买份数必须是正数,开头非零";
    		document.getElementById("minNumSpan").style.display="block";
    	    return  false; 
    	  }else{
      		document.getElementById("minNumSpan").style.display="none";

    	  }	});
	
	//最大
	$('#maxNum').change(function(){
		var  maxNum=$('#maxNum').val();
		if(!(/^\+?[1-9][0-9]*$/.test( maxNum ))){
			document.getElementById("maxNumSpan").innerHTML="最大购买份数必须是正数,开头非零";
    		document.getElementById("maxNumSpan").style.display="block";
    	    return  false; 
    	  }else{
      		document.getElementById("maxNumSpan").style.display="none";

    	  }	});
	
	//期数
	$('#productNum').change(function(){
		var   productNum=$('#productNum').val();
		if(!(/^\+?[1-9][0-9]*$/.test( productNum ))){
			document.getElementById("productNumSpan").innerHTML="产品期数必须必须是正数,开头非零";
    		document.getElementById("productNumSpan").style.display="block";
    	    return  false; 
    	  }else{
      		document.getElementById("productNumSpan").style.display="none";

    	  }	});
	
	
	$('#yield').change(function(){
		var   yield=$('#yield').val();
		if(!isNaN(yield)){
			 var dot = yield.indexOf(".");
	            if(dot != -1){
	                var dotCnt = yield.substring(dot+1,yield.length);
	                if(dotCnt.length > 2){
	                    document.getElementById("yieldSpan").innerHTML="年化收益率小数位已超过2位";
	            		document.getElementById("yieldSpan").style.display="block";
	            		return  false;
	               }else{
	            	   if(dotCnt.length<=1){
	            		   document.getElementById("yieldSpan").innerHTML="年化收益率小数位必须为2位";
		            	   document.getElementById("yieldSpan").style.display="block"; 
		            	   return  false;
	            	   }
	            	   document.getElementById("yieldSpan").style.display="none";
	               }

	            }else{
	            	  document.getElementById("yieldSpan").innerHTML="年化收益率小数位必须为2位";
	            	   document.getElementById("yieldSpan").style.display="block"; 
	            	   return  false;
	            }
    	  }else{
    		  document.getElementById("yieldSpan").innerHTML="年化收益率不合法";
      		  document.getElementById("yieldSpan").style.display="block";
      		  return  false;

    	  }	});
	
	$('#extraYield').change(function(){
		var   extraYield=$('#extraYield').val();
		if(extraYield==""){
   		  document.getElementById("extraYieldSpan").style.display="none";

		}
		var dot = extraYield.indexOf("."); 
		if(!isNaN(extraYield)){
			var dotCnt = extraYield.indexOf(".");
            if(dotCnt != -1){
	                var dotCnt = extraYield.substring(dot+1,extraYield.length);
	                if(dotCnt.length > 2){
						document.getElementById("extraYieldSpan").innerHTML="额外收益率小数点已超过2位";
			    		document.getElementById("extraYieldSpan").style.display="block";
	    	            return  false; 
                }else{
	                if(dotCnt.length<=1){
		            	document.getElementById("extraYieldSpan").innerHTML="额外收益率小数位必须为2位";
			            document.getElementById("extraYieldSpan").style.display="block"; 
			            return  false;
		            }
		            	document.getElementById("extraYieldSpan").style.display="none"
                }
            }else{
	            	  document.getElementById("extraYieldSpan").innerHTML="额外收益率小数位必须为2位";
	            	   document.getElementById("extraYieldSpan").style.display="block"; 
	            	   return  false;
	            }
    	  }else{
      		  document.getElementById("extraYieldSpan").innerHTML="额外收益率不合法";
     		  document.getElementById("extraYieldSpan").style.display="block";
	          return  false; 

 
    	  }	});
	//表单提交时判断是否为空
    $("form").submit(function(){
    	/*接受判断表单文本域是否为空的函数值*/
    	var returnCode = isBlank();
//    	var returnCode1 = comparisonOfTime();
    	var returnCode2=xs();//小数
    	var returnCode3=amount();//金融/单价
    	var specialCharacter = ts();//检验产品的名称不能有特殊的字符
//    	var returnResult = checkNumber();//产品期数唯一性检查
    	/*如果接受到的函数值是true(说明表单都有值，执行下面函数)false(说明表单文本域有的为空校验不通过)*/
    	if(returnCode == true){
    		//判断name
    		if(!specialCharacter){
				 return  false;
			 }
    		if(returnCode3==false){
				 return  false;
    		}
			//判断正数
			if(zshu()==false){
				 return  false;
			 }
//			 if(returnCode1 == false){
//         		return false;
//     		}
			 if(returnCode2==false){
	         		return false;
 
			 }
//			 if(returnResult == false){
//				  return false;
//			 }
			 
      	 }
    	else if(returnCode == false){//函数值是false说明非空校验不通过阻止表单提交
      		 return false;
      	 }else{
      		 alert("js程序有问题");
      	 }
    	
    	
    	
   });
    
    //时间大小比较
//    function comparisonOfTime(){
//   	 var biginTime =  $("#beginTime").val();
//   	 var dateBigin = new Date(biginTime);//时间字符串date转换
//   	 var endTime =  $("#endTime").val();
//   	 alert(dateBigin.getDate());
//   	 var dateEnd = new Date(endTime);
//   	 if(dateBigin < dateEnd){//比较
//		 $("#endTimeSpan").hide();
//		 return true;
//   	 }else{
//   		 $("#endTimeSpan").text("产品开售结束时间应该大于产品开售开始时间");
//		 $("#endTimeSpan").show(); 
//   		return false;
//   	 }
//      }
    //非空校验
    function isBlank(){
 	   var arrayObj = new Array("#name","#amount","#unitPrice","#minNum","#maxNum","#yield","#productNum","#interestSetDate","#lastDueDate","#beginTime","#endTime");
 	   for(var i=0;i<arrayObj.length;i++){
 		 var testvalue = $(arrayObj[i]).val();
 		 if(testvalue== ""){
 			 $(arrayObj[i]+"Span").text("不能为空");
 			 $(arrayObj[i]+"Span").show(); 
 			 return false;
 		 }else{
 			 $(arrayObj[i]+"Span").hide(); 
 			 if(i == 10){
 				 return true;
 			 }
 		 }
 		 
 	   }
    }
    
    function  zshu(){
   	 var zshu=new Array("#amount","#unitPrice","#minNum","#maxNum","#productNum");
   	 //var zshu=new Array("#amount");
   	for(var i=0;i<zshu.length;i++){ 
   		 var  a=$(zshu[i]).val();
   	 if(!/^\+?[1-9][0-9]*$/.test(a)){
   			 $(zshu[i]+"Span").html("不为空，输入不合法");
   			 $(zshu[i]+"Span").show();
   			 return  false;
         }
             $(zshu[i]+"Span").hide();
   	 }
     }
    function   ts(){
   	 var  name=$("#name").val();
	  var regular = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]") ;
         if(!regular.test(name)){
             $("#nameSpan").hide();
             return true;
         }else{
             $("#nameSpan").html("请不要输入特殊字符");
             $("#nameSpan").show();
             return  false;

         }
   	  }
    
    function   xs(){
    	  var  yield=$("#yield").val();
		  if(/^\d+(\.\d{2})?$/.test(yield)){
			  var  a=yield.indexOf(".");
			  if(a==-1){
				  $("#yieldSpan").html("请输入数字精确到小数点两位"); 
				  $("#yieldSpan").show();
				  return  false;

			  }
		  }
		  var  extraYield=$("#extraYield").val();
		  if(extraYield==""){
			  $("#extraYieldSpan").hide();
		  }
		  if(/^\d+(\.\d{2})?$/.test(extraYield)){
			  var  a=extraYield.indexOf(".");
			  if(a==-1){
				  $("#extraYieldSpan").html("请输入数字精确到小数点两位"); 
				  $("#extraYieldSpan").show();
				  return  false;

			  }
		  }
		  return true;
    	
    }
    
    function   amount(){
    	var  amount=$("#amount").val();
    	var  unitPrice=$("#unitPrice").val();
    	if(parseInt(amount)%parseInt(unitPrice)!=0){
    		 $("#amountSpan").html("融资金融除必须是产品单价的整数倍"); 
			 $("#amountSpan").show();
    		 return  false;
    	}
		 $("#amountSpan").hide();
             return true;
    	
    };
    
});
