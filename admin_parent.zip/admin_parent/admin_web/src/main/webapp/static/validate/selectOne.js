/**
 * 
 */

$(function(){
	//demo01
	$("#city_1").citySelect({
		nodata:"none",
		required:false
	});
})