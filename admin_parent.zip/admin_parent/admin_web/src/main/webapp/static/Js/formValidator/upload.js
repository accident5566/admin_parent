/**
 * 文件上传
 * @param fileId  文本域id
 * @param moudle  模块名
 */

function ajaxFileUpload(fileId,moudle){
	var o = $("#"+fileId).offset();
	var t = o.top + 3;
	var l = o.left + $("#"+fileId).width()+10;
	var img = jQuery('<img id="Loading" src="'+sy.basePath+'/websource/images/loading.gif" width="20" height="20"/>').appendTo('body');
	$(img).css({
		"display": "black",
		"top": t,"left": l,
		"z-index":1987,
		"position": "absolute"
	});
	
	
	var file=$("#"+fileId).parent().find(':input[type="hidden"]');
	$(file).val("");
	$("#"+fileId).next().remove();
	
	$.ajaxFileUpload ( {
            url:sy.basePath+'/fileprocess/fileprocessUploadFile.action',//用于文件上传的服务器端请求地址
            secureuri:false,         //一般设置为false
            fileElementId:fileId,    //文件上传空间的id属性 
            dataType: 'json',        //返回值类型 一般设置为json
            data:{"moudle":moudle}, //加入的文本参数
            success: function (result) {    
            	$(img).remove();	
            	//服务器成功响应处理函数
				if (result && result.map) {
					if (result.map.success) {
						$(file).val(result.map.original);
						jQuery('<a href="'+result.map.original+'" target="_blank">&nbsp;查看</a>').insertAfter($("#"+fileId));
					}else{
						$.dialog({title:'提示框',width:200,content:result.map.error,lock :1});
						jQuery('<a href="">&nbsp;暂无</a>').insertAfter($("#"+fileId));
					}
				}
            },error: function (data,status,e) {
            	$(img).remove();
            	jQuery('<a href="">暂无</a>').insertAfter($("#"+fileId));
            	$.dialog({title:'提示框',width:200,content:'连接异常，请联系管理员。',lock :1});
            }
        }
    );
    
}

