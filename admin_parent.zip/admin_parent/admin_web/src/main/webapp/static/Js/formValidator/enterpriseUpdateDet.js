$(document).ready( function() {
	var bool=true;
	 
	$.formValidator.initConfig({
		submitButtonID:"Submit1",
	    errorfocus: false,
	    submitonce: true,
	    tipstyle: "both",
	    onSuccess:function(){
	    	if(bool){
	    		enterpriseUpt();
	    	}
	    	
	    }
	});
	
	$("#province1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#city1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#area1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#officeaddr").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 200,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	
	//企业名称
	$("#enterpriseName").bind({
		//获得焦点  
		focus: function(){
			$("#enterpriseNameTip").removeClass("onCorrect onError");
		},
		//失去焦点
		blur: function(){
			$("#enterpriseNameTip").removeClass().addClass("onLoad");
			var enterpriseName = this.value.replace(/\s*$/g, "");
			if(enterpriseName.length>0){
				$.ajax({
					type : "post",
					async:false,
					data:{"enterprise.enterprisename":enterpriseName},  
					dataType : "json",
					url : sy.basePath+"/enterprise/enterpriseCheckName.action",
					success : function(result){
						if(result && result.success){
							if(result.obj){
								var id=$("#enterpriseid").val();
								var eid=result.obj.enterpriseid;
								if(id==eid){
									$("#enterpriseNameTip").removeClass().addClass("onCorrect");
									return bool=true;
								}
								$("#enterpriseNameTip").removeClass().addClass("onError");
								return bool=false;
							}
							$("#enterpriseNameTip").removeClass().addClass("onError");
							return bool=false;
						}
						$("#enterpriseNameTip").removeClass().addClass("onCorrect");
						return bool=true;
					}
				});
			}else{
				$("#enterpriseNameTip").removeClass().addClass("onError");
				return bool=false;
			}
		}
	});
	
	$("#enterpriseLicense").bind({
		//获得焦点  
		focus: function(){
			  $("#enterpriseLicenseTip").removeClass("onCorrect onError");
		},
		//失去焦点
		blur: function(){
			    $("#enterpriseLicenseTip").removeClass().addClass("onLoad");
			    var enterpriselicense = this.value.replace(/\s*$/g, "");
		    	if(enterpriselicense.length>0){
		    		 $.ajax({
				        type : "post",
				        async:false,
				        data:{"enterprise.enterpriselicense":enterpriselicense},  
				        dataType : "json",
				        url : sy.basePath+"/enterprise/enterpriseGet.action",
				        success : function(result){
				        	 if(result && result.success){
				                  if(result.obj){
					            	  var id=$("#enterpriseid").val();
					            	  var eid=result.obj.enterpriseid;
					            	  if(id==eid){
					            		  $("#enterpriseLicenseTip").removeClass().addClass("onCorrect");
					            		  return bool=true;
					            	  }
					            	  $("#enterpriseLicenseTip").removeClass().addClass("onError");
					        		  return bool=false;
				                 }
				                  $("#enterpriseLicenseTip").removeClass().addClass("onError");
				    		     return bool=false;
				            }
				        	 $("#enterpriseLicenseTip").removeClass().addClass("onCorrect");
				        	return bool=true;
				         }
				     });
		    	}else{
		    		$("#enterpriseLicenseTip").removeClass().addClass("onError");
		    		return bool=false;
		    	}
	    		
		  }
	});
	
	
	
	$("#contactName").formValidator({
	
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#contactMobile").formValidator({
	
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#recAccount").formValidator({
	
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#recAccountName").formValidator({
	
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;"
	});
	
	$("#city2").formValidator({
		
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;"
	});
	
	$("#recBankName").formValidator({
	
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;"
	});
	
	
	
	
	
});



function enterpriseUpt(){
	
	var d = $.dialog({
        title : '提示框',
        width : 300,
        lock : 1,
        content : $('#detail').html()
    });
	
	$('#close').on('click', function(){
        d.close();
    });
	
	$('#submit').on('click', function(){
		var data= $("#enterpriseForm").serialize();
		$.ajax({   
	   	     type:"post",
	   	     data: data,   
	   	     url: sy.basePath+"/enterprise/enterpriseUpt.action",
	    	 dataType:"json", 
	    	 error:function(){
	    		 d.close();
	    		 $.dialog({title:'提示框',width:300,content:'网络连接超时',lock :1});
	    	 },
	         success:function(result){
	        	 d.close();
	        	 if(result && result.success){
		        	 location.href=sy.basePath+'/enterprise/enterpriseCreateOrUpt.action';
		         }else{
				    if(result.msg=='操作失败'){
    	        			var dd = $.dialog({title:'提示框',width:200,content:$('#DataUpdate').html(),lock :1});
    	        			var maindd = dd.dom.main;
    	        			var btndd = maindd.find('#dataupdate');
    	        			btndd.on('click',function(){
    	     	    	    	dd.close();
    	     	    	    	location.href=sy.basePath+'/enterprise/enterpriseCreateOrUpt.action';
    	        			});
 	        		}else{
     		        	$.dialog({title:'提示框',width:300,content:result.msg,lock :1});
 	        		}
		         }
		     }
		 });
    });
}


