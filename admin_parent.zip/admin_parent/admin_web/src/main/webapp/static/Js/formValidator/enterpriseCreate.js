$(document).ready( function() {
	$.formValidator.initConfig({
		 submitButtonID:"Submit1",
	     errorfocus: false,
	     submitonce: true,
	     tipstyle: "both",
	     onSuccess:function(){
	    	 enterpriseTemSave();
	     }
	});
	
	$("#enterpriseName").formValidator({
		onCorrect: "&nbsp;"
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	}).ajaxValidator({
        type : "post",
        async : true,
        dataType : "json",
        url : sy.basePath+"/enterprise/enterpriseCheckName.action",
        success : function(result){
        	if(result && result.success){
              return false;
            }
        	return true;
        },
        error: function(jqXHR, textStatus, errorThrown){
        },
        onError : "此名称已被注册",
        onWait : "&nbsp;"
    });
	
	$("#enterpriseLicense").formValidator({
		onCorrect: "&nbsp;" 
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	}).ajaxValidator({
        type : "post",
        async : true,
        dataType : "json",
        url : sy.basePath+"/enterprise/enterpriseGet.action",
        success : function(result){
        	if(result && result.success){
              return false;
            }
        	return true;
        },
        error: function(jqXHR, textStatus, errorThrown){
        },
        onError : "此号码已被注册",
        onWait : "&nbsp;"
    });
	
	$("#province1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#city1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#area1").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#officeaddr").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 200,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#contactName").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#contactMobile").formValidator({
		
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#recAccount").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	$("#city2").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#recAccountName").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
	
	$("#recBankName").formValidator({
	}).inputValidator({ 
		min: 1,
		max: 100,
		onErrorMin: "&nbsp;",
		onErrorMax: "&nbsp;" 
	});
});

function checkInput(){
	if($("#province1").val()==""||$("#city1").val()==""||$("#area1").val()==""||$("#officeaddr").val()==""){
		$.dialog({title:'提示框',width:300,content:"企业办公地址不能为空",lock :1});
		return false;
	}
	return true;
}



function enterpriseTemSave(){
	if(checkInput()){
	 var d = $.dialog({
         title : '提示框',
         width : 300,
         lock : 1,
         content : $('#detail').html()
      });
	 
	  $('#close').on('click', function(){
         d.close();
      });
     
      $('#submit').on('click', function(){
         	var data= $("#enterpriseForm").serialize();
 			$.ajax({   
     	   	     type:"post",
     	   	     data: data,   
     	   	     url:sy.basePath+"/enterprise/enterpriseTemSave.action",
     	    	 dataType:"json",
     	         success:function(result){
     	        	 d.close();
     	        	 if(result && result.success){
     		        	 location.href = sy.basePath+"/enterprise/enterpriseCreateOrUpt.action";
     		         }else{
     		        	 $.dialog({title:'提示框',width:300,content:result.msg,lock :1});
     		         }
     		     },
     		     error:function(){
     	    		 d.close();
     	    		 $.dialog({title:'提示框',width:300,content:'操作失败',lock :1});
     	    	 }
     		});
         
      });
	} 
}

