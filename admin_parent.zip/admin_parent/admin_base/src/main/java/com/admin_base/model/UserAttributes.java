package com.admin_base.model;

import java.io.Serializable;
/**
 * @see �û�����ʵ����
 * @author peiwei
 * @Date 2015-10-12
 */

public class UserAttributes implements Serializable{
	private static final long serialVersionUID = 1L;
	/*��ʶid*/
	private Integer id;
	/*������uuid*/
	private String userIdentifier;
	/*������uuid*/
	private String beInvitedUuid;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getBeInvitedUuid() {
		return beInvitedUuid;
	}
	public void setBeInvitedUuid(String beInvitedUuid) {
		this.beInvitedUuid = beInvitedUuid;
	}
	public UserAttributes(Integer id, String invitingUuid, String beInvitedUuid) {
		super();
		this.id = id;
		this.userIdentifier = invitingUuid;
		this.beInvitedUuid = beInvitedUuid;
	}
	public UserAttributes() {
		super();
	}
	@Override
	public String toString() {
		return "UserAttributes [id=" + id + ",userIdentifier=" + userIdentifier
				+ ", beInvitedUuid=" + beInvitedUuid + "]";
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	
}
