package com.admin_base.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;


public class App {

	public static void main(String[] args) {
//		ApplicationContext context = 
//	    		new ClassPathXmlApplicationContext("file:src/main/resources/applicationContext.xml");
//		Users user = new Users();
//		user.setCellphone("18616803173");
//		user.setUseridentifier("test");
		Jedis jedis = new Jedis("192.168.0.203");
		jedis.auth(SystemProperty.getProperty("redis.password"));
		System.out.println(jedis.hgetAll("product:007").toString());
		//�ر�����
		
	}
}
