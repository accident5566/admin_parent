package com.admin_base.util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

import com.admin_base.constant.ProductContent;
import com.admin_base.model.Product;

/***
 * java uuid ���� Ψһ��ʶ
 * @author qiupeiwei
 * @Date 2015-03-11
 */
public class CommonUtil {
	
	public CommonUtil() {
	
	}
	
    public static String WithHtmlUnderline(String value)
    {
        return "<u> " + value + " </u>";
    }
	
	public static String getSuffixOfBankCardNo(String bankCardNo) {
		int length = bankCardNo.length();
		return bankCardNo.substring(length - 4);
	}
	
	public static String getUUID() {
		UUID uuid = UUID.randomUUID();
		String str = uuid.toString();
		return str.replace("-", "");
	}
	
	public static String encryptCredentialNo(String credentialNo) {
		
		int length = credentialNo.length();
		
		if (length > 10) {
			String symbol = "";
			for(int i =0; i < length-10; i++) {
				symbol +="*";
			}
			
			return credentialNo.substring(0,6) + symbol + credentialNo.substring(length-4); 
		} else {
			return credentialNo;
		}
	}
	
	public static int getProductVirtualStatus(Product productDTO) 
	{
		switch(productDTO.getRaiseStatus())
		{
		case ProductContent.STATUS_CANSALE:
			//δ������ʱ�䣬�Ǵ���״̬
			if (new Date().before(productDTO.getBeginTime()))
				return ProductContent.VSTATUS_WAIT;

			//������������ʱ�䣬��ͣ��״̬
			if (new Date().after(productDTO.getEndTime()))
				return ProductContent.VSTATUS_STOP;
			//����������״̬
			return ProductContent.VSTATUS_SALE;
		case ProductContent.STATUS_OUT:
			//��δ����Ϣ���ڣ�������״̬
			if (new Date().before(productDTO.getInterestSetDate()))
				return ProductContent.VSTATUS_OUT;
			//�����ǻ�����״̬
			return ProductContent.VSTATUS_RETURNING;
		case ProductContent.STATUS_OVER:
			return ProductContent.VSTATUS_OVER;
		}
		return 0;
	}
	public static BigDecimal amountToFloor2(BigDecimal amount) {
		return amount.setScale(2, BigDecimal.ROUND_DOWN);
	}
	
	public static BigDecimal amountToFloor4(BigDecimal amount) {
		return amount.setScale(4, BigDecimal.ROUND_DOWN);
	}
	
	public static void main(String args[]){
		System.out.print(getUUID().length());
		System.out.print("\n");
		
		System.out.print(amountToFloor2(new BigDecimal(120.357)));
		System.out.print("\n");
		
		System.out.print(amountToFloor4(new BigDecimal(120.35736)));
		System.out.print("\n");
	}
}