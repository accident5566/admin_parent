package com.admin_base.dto.response;

import java.math.BigDecimal;
import java.util.Date;

/**
 * ���ݴ�����������Ƕ�������
 * @author ted.chen
 * @Date 2015-04-03
 */
public class OrderDetailDTOResult extends OrderInfoDTOResult{

    //Ͷ�����ֻ�����
    private String cellphone;
    
    //Ͷ����uuid
    private String uuid;
    
    //Ͷ��������֤������
    private String credentialNo;
    
    //Ͷ��������
    private String realName;
    
    //���п��ź�4λ
    private String suffixbankCardNo;
    
    //��������
    private String bankName;
    
    //֧������ʱ��
    private Date resultTime;

    //����Ӧ��ʡ��
    private String provice;
    
    //����Ӧ�ĳ���
    private String city;
    
    //��Ʒ��identifier
    private String productIdentifier;
    
    //���п���
    private String bankCardNo;
    
    //���Ȿ��
    private BigDecimal virtualAmount ;
 
    public BigDecimal getVirtualAmount() {
		return virtualAmount;
	}

	public void setVirtualAmount(BigDecimal virtualAmount) {
		this.virtualAmount = virtualAmount;
	}

	private String appUser;
    
    public String getAppUser() {
		return appUser;
	}

	public void setAppUser(String appUser) {
		this.appUser = appUser;
	}

	/**��Ϣ����**/
    private Date interestSetDate;
    private Integer paySource;

	public Integer getPaySource() {
		return paySource;
	}

	public void setPaySource(Integer paySource) {
		this.paySource = paySource;
	}

	public Date getInterestSetDate() {
		return interestSetDate;
	}

	public void setInterestSetDate(Date interestSetDate) {
		this.interestSetDate = interestSetDate;
	}

	public String getBankCardNo() {
		return bankCardNo;
	}

	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public String getProvice() {
		return provice;
	}

	public void setProvice(String provice) {
		this.provice = provice;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public String getCredentialNo() {
//		return 	CommonUtil.encryptCredentialNo(credentialNo);
		return credentialNo;
	}

	public void setCredentialNo(String credentialNo) {
		this.credentialNo = credentialNo;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getSuffixbankCardNo() {
		return suffixbankCardNo;
	}

	public void setSuffixbankCardNo(String suffixbankCardNo) {
		this.suffixbankCardNo = suffixbankCardNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Date getResultTime() {
		return resultTime;
	}

	public void setResultTime(Date resultTime) {
		this.resultTime = resultTime;
	}

	public OrderDetailDTOResult() {
		super();
	}
	public OrderDetailDTOResult(int orderStatus,String orderNo){
		super.setOrderStatus(orderStatus);
		super.setOrderNo(orderNo);
	}
	
	public BigDecimal getRealAmount() {
		return this.getAmount().subtract(this.virtualAmount);
	}
}
