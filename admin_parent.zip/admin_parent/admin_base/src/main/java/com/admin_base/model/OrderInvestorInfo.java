package com.admin_base.model;
/***
 * Ͷ����Ϣʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class OrderInvestorInfo{
	
	/*������ʶID*/
    private Integer id;

    /*UUID*/
    private String orderIdentifier;

    /*�ֻ�����*/
    private String cellphone;

    /*֤������*/
    private Integer credential;

    /*֤������*/
    private String credentialno;

    /*��ʵ����*/
    private String realname;

    /*Ͷ���û�UUID*/
    private String useridentifier;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderidentifier() {
        return orderIdentifier;
    }

    public void setOrderidentifier(String orderidentifier) {
        this.orderIdentifier = orderidentifier == null ? null : orderidentifier.trim();
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone == null ? null : cellphone.trim();
    }

    public Integer getCredential() {
        return credential;
    }

    public void setCredential(Integer credential) {
        this.credential = credential;
    }

    public String getCredentialno() {
        return credentialno;
    }

    public void setCredentialno(String credentialno) {
        this.credentialno = credentialno == null ? null : credentialno.trim();
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

	public OrderInvestorInfo(Integer id, String orderidentifier,
			String cellphone, Integer credential, String credentialno,
			String realname, String useridentifier) {
		super();
		this.id = id;
		this.orderIdentifier = orderidentifier;
		this.cellphone = cellphone;
		this.credential = credential;
		this.credentialno = credentialno;
		this.realname = realname;
		this.useridentifier = useridentifier;
	}

	public OrderInvestorInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "OrderInvestorinfo [id=" + id + ", orderidentifier="
				+ orderIdentifier + ", cellphone=" + cellphone
				+ ", credential=" + credential + ", credentialno="
				+ credentialno + ", realname=" + realname + ", useridentifier="
				+ useridentifier + "]";
	}
    
    
}