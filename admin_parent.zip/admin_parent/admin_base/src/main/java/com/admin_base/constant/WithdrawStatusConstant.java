package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * ���״ֵ̬��װ
 * */
public class WithdrawStatusConstant {
	
	private  Integer  id;
	private  String   value;
	public WithdrawStatusConstant(Integer id, String value) {
		super();
		this.id = id;
		this.value = value;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public   static  List<WithdrawStatusConstant>   getComUtil(){
		 List<WithdrawStatusConstant>  comList=new  ArrayList<>();
		  comList.add(new WithdrawStatusConstant(10, "������"));
		  comList.add(new WithdrawStatusConstant(20, "�����"));
		  comList.add(new WithdrawStatusConstant(30, "��˳ɹ�"));
		  comList.add(new WithdrawStatusConstant(40, "���ʧ��"));
		  comList.add(new WithdrawStatusConstant(50, "�ɹ�"));
		  comList.add(new WithdrawStatusConstant(60, "ʧ��"));
		  return  comList;
	}
}
