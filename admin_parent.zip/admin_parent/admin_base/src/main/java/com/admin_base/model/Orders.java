package com.admin_base.model;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.admin_base.dto.response.ReconciliationQueryYiJiaDTOMsg;
import com.admin_base.dto.response.UserPaymentQueryMessage;
import com.admin_base.dto.yl.CommonMsg;
/***
 * ����ʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class Orders {
	
	/*������ʶid*/
    private Integer id;
    
    /*��������*/
    private BigDecimal extraInterest;
    
    /*��Ʒ���*/
    private String productIdentifier;
    
    /*��������*/
    private BigDecimal interest;
    
    /*�������*/
    private String orderNo;
    
    /*�µ�ʱ��*/
    private Date createdAt;

    /*��������(��Ʊ,��Ʊ)*/
    private Integer orderType;

    /*Ͷ�ʽ��*/
    private BigDecimal amount;

    /*��Ϣʱ��*/
    private Date settleDate;

    /*Ͷ�ʷ���*/
    private Integer shareCount;

    /*Ͷ���û�UUID*/
    private String userIdentifier;

    /*��Ϣ����*/
    private Date valueDate;

    /*������*/
    private BigDecimal yield;

    
    private Integer orderStatus;
    
    /**�����*/
    private  BigDecimal  activityInterest;
    
    /**��Ϣ����**/
    private Date interestSetDate;

    private Date orderTime;
	
    private Integer paySource;

    /*��ѯ�������û�����*/
    private String realname;

    /*��ѯ�������û��绰*/
    private String cellphone;
    
    /*���Ȿ��*/
    private BigDecimal virtualAmount;
    
    /*ʵ�����*/
    private BigDecimal realPayAmount;
    
    /*ÿ�ն������� */
    private int orderQuantity;
    
    /*ÿ�ն����ܶ� */
    private BigDecimal orderAmount;

    public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public BigDecimal getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(BigDecimal orderAmount) {
		this.orderAmount = orderAmount;
	}

	public BigDecimal getRealPayAmount() {
		return realPayAmount;
	}

	public void setRealPayAmount(BigDecimal realPayAmount) {
		this.realPayAmount = realPayAmount;
	}

	public Orders(String productIdentifier, Integer paySource) {
		this.productIdentifier = productIdentifier;
		this.paySource = paySource;
	}

	public Integer getPaySource() {
		return paySource;
	}

	public void setPaySource(Integer paySource) {
		this.paySource = paySource;
	}

	public Date getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}

	public Date getInterestSetDate() {
		return interestSetDate;
	}

	public void setInterestSetDate(Date interestSetDate) {
		this.interestSetDate = interestSetDate;
	}

	public BigDecimal getActivityInterest() {
		return activityInterest;
	}

	public void setActivityInterest(BigDecimal activityInterest) {
		this.activityInterest = activityInterest;
	}

	public Orders(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BigDecimal getExtraInterest() {
		return extraInterest;
	}

	public void setExtraInterest(BigDecimal extraInterest) {
		this.extraInterest = extraInterest;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public Integer getShareCount() {
		return shareCount;
	}

	public void setShareCount(Integer shareCount) {
		this.shareCount = shareCount;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public BigDecimal getYield() {
		return yield;
	}

	public void setYield(BigDecimal yield) {
		this.yield = yield;
	}

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public Orders(Integer id, BigDecimal extraInterest,
			String productIdentifier, BigDecimal interest, String orderNo,
			Date createdAt, Integer orderType, BigDecimal amount, Date settleDate,
			Integer shareCount, String userIdentifier, Date valueDate,
			BigDecimal yield) {
		super();
		this.id = id;
		this.extraInterest = extraInterest;
		this.productIdentifier = productIdentifier;
		this.interest = interest;
		this.orderNo = orderNo;
		this.createdAt = createdAt;
		this.orderType = orderType;
		this.amount = amount;
		this.settleDate = settleDate;
		this.shareCount = shareCount;
		this.userIdentifier = userIdentifier;
		this.valueDate = valueDate;
		this.yield = yield;
	}

	public Orders getOrders(CommonMsg com) {
		Orders order = new Orders();
		order.setOrderNo(com.getSn());
		if(com.getPayState().equals("0000")){
			order.setOrderStatus(60);	
		}else if(com.getPayState().equals("00A4")){
			order.setOrderStatus(50);	
		}else{
			order.setOrderStatus(50);
		}
		return order;
	}
	
	public Orders getOrders(UserPaymentQueryMessage com) {
		Orders order = new Orders();
		order.setOrderNo(com.getLogno());
		if(com.getStatus() == 2){
			order.setOrderStatus(60);	
		}else if(com.getStatus() == 1){
			order.setOrderStatus(50);	
		}else{
			order.setOrderStatus(50);
		}
		return order;
	}
	
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}
	public static BigDecimal getAmount(List<Orders> OrdersListYinJia,String orderNo){
		for(Orders o : OrdersListYinJia){
			if(o.getOrderNo().equals(orderNo)){
				return o.getAmount();
			}
		}
		return null;
	}
	
	public static BigDecimal getAmountYJ(List<ReconciliationQueryYiJiaDTOMsg> comOrderList,String orderNo){
		for(ReconciliationQueryYiJiaDTOMsg  msg : comOrderList){
		   if(msg.getOrderno().equals(orderNo)){
			   return msg.getAmount();
		   }
		}
		return null;
	}
	
	public static BigDecimal getAmountYL(List<CommonMsg>  comListYiLian,String orderNo){
		for(CommonMsg  msg : comListYiLian){
			   if(msg.getSn().equals(orderNo)){
				   return msg.getAmount();
			   }
			}
			return null;
	}


	public BigDecimal getVirtualAmount() {
		return virtualAmount;
	}

	public void setVirtualAmount(BigDecimal virtualAmount) {
		this.virtualAmount = virtualAmount;
	}
	
	public BigDecimal getRealAmount() {
		return this.amount.subtract(this.virtualAmount);
	}
}