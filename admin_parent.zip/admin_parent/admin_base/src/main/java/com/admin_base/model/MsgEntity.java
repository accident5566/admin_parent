package com.admin_base.model;

import com.admin_base.util.CommonMsg;
/***
 * ���ŷ���ʵ����
 * @author qiupeiwei
 * @Date 2015-03-23
 */
public class MsgEntity extends CommonMsg{
	private static final long serialVersionUID = 1L;
	
	/*�˺�*/
	private String name;
	/*����*/
	private String password;
	/*�ֻ���*/
	private String mobs;
	/*��Ϣ�������������塿*/
	private String msg;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobs() {
		return mobs;
	}
	public void setMobs(String mobs) {
		this.mobs = mobs;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public MsgEntity(String mobs, String msg) {
		super();
		this.name = "yj";
		this.password = "berekyj!";
		this.mobs = mobs;
		this.msg = msg;
		
	}
	
	public MsgEntity() {
		super();
	}
}
