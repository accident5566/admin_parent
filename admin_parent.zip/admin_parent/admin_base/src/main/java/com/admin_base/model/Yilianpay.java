package com.admin_base.model;

import java.math.BigDecimal;

import com.admin_base.util.CommonMsg;

/***
 * ʵ����֤-�����������ʵ����
 * @author qiupeiwei
 * @date 2015-03-18
 */
public class Yilianpay {

	/*��ʶid*/
	private Integer id;
	
	/*��Ʒ���κ�*/
	private String batchNo;
	
	/*�˺�����*/
	private Integer accType;
	
	/*�˺�*/
	private String accNo;
	
	/*�˺�����*/
	private String accName;
	
	/*���*/
	private BigDecimal amount;
	
	/*����*/
	private String cny;
	
	/*��������*/
	private String bankName;
	
	/*�ֻ�����*/
	private String mobileNo;
	
	/*����֤������*/
	private String idNo;
	
	/*����֤������*/
	private Integer idType;
	
	/*�̻�������*/
	private String merOrderNo;
	
	/*�û���uuid*/
	private String userUuid;
	
	/*��������ʡ��*/
	private String accProvince;
	
	/*�������ڳ���*/
	private String accCity;
	
	/*�ص��ӿ�*/
	private String merchantUrl;
	
	/*���͡�1.ʵ����֤,2.�¶�����*/
	private Integer type;

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Integer getAccType() {
		return accType;
	}

	public void setAccType(Integer accType) {
		this.accType = accType;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCny() {
		return cny;
	}

	public void setCny(String cny) {
		this.cny = cny;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public Integer getIdType() {
		return idType;
	}

	public void setIdType(Integer idType) {
		this.idType = idType;
	}

	public String getMerOrderNo() {
		return merOrderNo;
	}

	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	public String getAccProvince() {
		return accProvince;
	}

	public void setAccProvince(String accProvince) {
		this.accProvince = accProvince;
	}

	public String getAccCity() {
		return accCity;
	}

	public void setAccCity(String accCity) {
		this.accCity = accCity;
	}

	public String getMerchantUrl() {
		return merchantUrl;
	}

	public void setMerchantUrl(String merchantUrl) {
		this.merchantUrl = merchantUrl;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Yilianpay(String batchNo, Integer accType, String accNo,
			String accName, BigDecimal amount, String cny, String bankName,
			String mobileNo, String idNo, Integer idType, String merOrderNo,
			String userUuid, String accProvince, String accCity,
			String merchantUrl, Integer type) {
		super();
		this.batchNo = batchNo;
		this.accType = accType;
		this.accNo = accNo;
		this.accName = accName;
		this.amount = amount;
		this.cny = cny;
		this.bankName = bankName;
		this.mobileNo = mobileNo;
		this.idNo = idNo;
		this.idType = idType;
		this.merOrderNo = merOrderNo;
		this.userUuid = userUuid;
		this.accProvince = accProvince;
		this.accCity = accCity;
		this.merchantUrl = merchantUrl;
		this.type = type;
	}

	public Yilianpay() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Yilianpay [id=" + id + ", batchNo=" + batchNo + ", accType="
				+ accType + ", accNo=" + accNo + ", accName=" + accName
				+ ", amount=" + amount + ", cny=" + cny + ", bankName="
				+ bankName + ", mobileNo=" + mobileNo + ", idNo=" + idNo
				+ ", idType=" + idType + ", merOrderNo=" + merOrderNo
				+ ", userUuid=" + userUuid + ", accProvince=" + accProvince
				+ ", accCity=" + accCity + ", merchantUrl=" + merchantUrl
				+ ", type=" + type + "]";
	}
	

	
}
