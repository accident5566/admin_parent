package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * ���ڲ�Ʒ��װֵ
 * */
public class ComConstant {
	private  Integer  id;
	private  String   value;
	public ComConstant(Integer id, String value) {
		super();
		this.id = id;
		this.value = value;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public   static  List<ComConstant>   getComUtil(){
		 List<ComConstant>  comList=new  ArrayList<>();
		  comList.add(new ComConstant(10, "����"));
		  comList.add(new ComConstant(20, "������"));
		  comList.add(new ComConstant(30, "ͣ��"));
		  comList.add(new ComConstant(50, "����"));
		  comList.add(new ComConstant(60, "������"));
		  comList.add(new ComConstant(80, "����"));
		  comList.add(new ComConstant(90, "δ�������"));
		  return  comList;
	}
	  public static void main(String[] args) {
		  List<ComConstant>  c=ComConstant.getComUtil();
		  System.out.println(c.get(0).getId());
	}

}
