package com.admin_base.model;
/***
 * ����ʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
import java.util.Date;

public class UsersBankCards {
	
	/*������ʶid*/
    private Integer id;

    /*UUID*/
    private String useridentifier;

    /*���п���*/
    private String bankcardno;

    /*��������*/
    private String bankname;

    /*��������*/
    private String cityname;

    /*������ַ*/
    private String cardaddress;

    /*�Ƿ���Ĭ�Ͽ�(0,1)*/
    private Integer isdefault;

    /*�󿨳ɹ�ʱ��*/
    private Date verifiedtime;

    /*�Ƿ�ɾ����0,1��*/
    private Integer isdeleted;

    
    public UsersBankCards(UsersBankCardRecords usersBankCardRecords){
    	this.useridentifier = usersBankCardRecords.getUseridentifier();
    	this.bankname = usersBankCardRecords.getBankname();
    	this.bankcardno = usersBankCardRecords.getBankcardno();
    	this.cityname = usersBankCardRecords.getCityname();
    	this.cardaddress = usersBankCardRecords.getCardaddress();
    	this.verifiedtime = new Date();
    }
    
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

    public String getBankcardno() {
        return bankcardno;
    }

    public void setBankcardno(String bankcardno) {
        this.bankcardno = bankcardno == null ? null : bankcardno.trim();
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname == null ? null : bankname.trim();
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname == null ? null : cityname.trim();
    }

    public String getCardaddress() {
        return cardaddress;
    }

    public void setCardaddress(String cardaddress) {
        this.cardaddress = cardaddress == null ? null : cardaddress.trim();
    }

    public Integer getIsdefault() {
        return isdefault;
    }

    public void setIsdefault(Integer isdefault) {
        this.isdefault = isdefault;
    }

    public Date getVerifiedtime() {
        return verifiedtime;
    }

    public void setVerifiedtime(Date verifiedtime) {
        this.verifiedtime = verifiedtime;
    }

    public Integer getIsdeleted() {
        return isdeleted;
    }

    public void setIsdeleted(Integer isdeleted) {
        this.isdeleted = isdeleted;
    }

	public UsersBankCards(Integer id, String useridentifier, String bankcardno,
			String bankname, String cityname, String cardaddress,
			Integer isdefault, Date verifiedtime, Integer isdeleted) {
		super();
		this.id = id;
		this.useridentifier = useridentifier;
		this.bankcardno = bankcardno;
		this.bankname = bankname;
		this.cityname = cityname;
		this.cardaddress = cardaddress;
		this.isdefault = isdefault;
		this.verifiedtime = verifiedtime;
		this.isdeleted = isdeleted;
	}

	public UsersBankCards() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UsersBankCards [id=" + id + ", useridentifier="
				+ useridentifier + ", bankcardno=" + bankcardno + ", bankname="
				+ bankname + ", cityname=" + cityname + ", cardaddress="
				+ cardaddress + ", isdefault=" + isdefault + ", verifiedtime="
				+ verifiedtime + ", isdeleted=" + isdeleted + "]";
	}
    
	
	
}