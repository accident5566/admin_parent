package com.admin_base.model;
import java.util.Date;
/***
 * �û�������Ϣʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class Users {
	
	/*������ʶid*/
    private Integer id;

    /*UUID*/
    private String useridentifier;

    /*�ֻ�����*/
    private String cellphone;

    /*���ܹ��ĵ�¼����*/
    private String encryptedpassword;

    /*���һ�ε�¼ʧ��ʱ��*/
    private Date lastfailedsignintime;

    /*��¼ʧ�ܴ���*/
    private Integer loginfailedcount;

    /*��½����*/
    private String loginname;

    /*��¼����ļ��ܴ�*/
    private String salt;

    /*ע��ʱ��*/
    private Date signuptime;

    /*���һ�γɹ���¼ʱ��*/
    private Date lastsuccesssignintime;
    
    /*ע���û���Դ*/
    private int status;
    
    /*ע���û���Դ*/
    private String sourceType;
    
    /*ÿ��ע���û�����*/
    private int dailyUserQuantity;
    
    /*ÿ����֤ע���û�����*/
    private Integer authUserQuantity;

    public Integer getAuthUserQuantity() {
		return authUserQuantity;
	}

	public void setAuthUserQuantity(Integer authUserQuantity) {
		this.authUserQuantity = authUserQuantity;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getDailyUserQuantity() {
		return dailyUserQuantity;
	}

	public void setDailyUserQuantity(int dailyUserQuantity) {
		this.dailyUserQuantity = dailyUserQuantity;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone == null ? null : cellphone.trim();
    }

    public String getEncryptedpassword() {
        return encryptedpassword;
    }

    public void setEncryptedpassword(String encryptedpassword) {
        this.encryptedpassword = encryptedpassword == null ? null : encryptedpassword.trim();
    }

    public Date getLastfailedsignintime() {
        return lastfailedsignintime;
    }

    public void setLastfailedsignintime(Date lastfailedsignintime) {
        this.lastfailedsignintime = lastfailedsignintime;
    }

    public Integer getLoginfailedcount() {
        return loginfailedcount;
    }

    public void setLoginfailedcount(Integer loginfailedcount) {
        this.loginfailedcount = loginfailedcount;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname == null ? null : loginname.trim();
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt == null ? null : salt.trim();
    }

    public Date getSignuptime() {
        return signuptime;
    }

    public void setSignuptime(Date signuptime) {
        this.signuptime = signuptime;
    }

    public Date getLastsuccesssignintime() {
        return lastsuccesssignintime;
    }

    public void setLastsuccesssignintime(Date lastsuccesssignintime) {
        this.lastsuccesssignintime = lastsuccesssignintime;
    }

	public Users(Integer id, String useridentifier, String cellphone,
			String encryptedpassword, Date lastfailedsignintime,
			Integer loginfailedcount, String loginname, String salt,
			Date signuptime, Date lastsuccesssignintime) {
		super();
		this.id = id;
		this.useridentifier = useridentifier;
		this.cellphone = cellphone;
		this.encryptedpassword = encryptedpassword;
		this.lastfailedsignintime = lastfailedsignintime;
		this.loginfailedcount = loginfailedcount;
		this.loginname = loginname;
		this.salt = salt;
		this.signuptime = signuptime;
		this.lastsuccesssignintime = lastsuccesssignintime;
	}

	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Users(String useridentifier) {
		super();
		this.useridentifier = useridentifier;
	}

	@Override
	public String toString() {
		return "Users [id=" + id + ", useridentifier=" + useridentifier
				+ ", cellphone=" + cellphone + ", encryptedpassword="
				+ encryptedpassword + ", lastfailedsignintime="
				+ lastfailedsignintime + ", loginfailedcount="
				+ loginfailedcount + ", loginname=" + loginname + ", salt="
				+ salt + ", signuptime=" + signuptime
				+ ", lastsuccesssignintime=" + lastsuccesssignintime + "]";
	}

	public Users(String useridentifier, String cellphone,
			String encryptedpassword, String loginname, String salt,
			Date signuptime) {
		super();
		this.useridentifier = useridentifier;
		this.cellphone = cellphone;
		this.encryptedpassword = encryptedpassword;
		this.loginname = loginname;
		this.salt = salt;
		this.signuptime = signuptime;
	}

	public Users(String cellphone, String encryptedpassword) {
		super();
		this.cellphone = cellphone;
		this.encryptedpassword = encryptedpassword;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
}