package com.admin_base.dto.yl;
import java.util.ArrayList;
import java.util.List;

import com.admin_base.model.UsersBankCardRecords;

/***
 * �����ӿڵ���json����
 * @author qiupeiwei
 * @Date 2015-03-18
 */
public class CommonModel{
	protected String batchNo = "";
	protected List<CommonMsg> transDetails = new ArrayList<CommonMsg>();
	
	public String getBatchNo() {
		return batchNo;
	}

	public CommonModel() {
		super();
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public List<CommonMsg> getTransDetails() {
		return transDetails;
	}

	public void setTransDetails(List<CommonMsg> transDetails) {
		this.transDetails = transDetails;
	}

	public CommonModel(String batchNo, List<CommonMsg> transDetails) {
		super();
		this.batchNo = batchNo;
		this.transDetails = transDetails;
	}
    public CommonModel(UsersBankCardRecords usersBankCardRecords){
    	this.batchNo = usersBankCardRecords.getSequenceno();
    }

}
