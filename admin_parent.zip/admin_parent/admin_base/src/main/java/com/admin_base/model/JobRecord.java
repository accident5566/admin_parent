package com.admin_base.model;

import java.util.Date;

/**
 * @author qiupeiwei
 */
public class JobRecord {
	
	/**
	 */
	private long execresultId;
	
	/**
	 */
	private String jvmNum;
	
	/**
	 */
	private String jobName;
	
	/**
	 */
	private Date execTime;
	
	/**
	 */
	private String execMessage;
	
	/**
	 */
	private short execFlag;


	public long getExecresultId() {
		return execresultId;
	}

	public void setExecresultId(long execresultId) {
		this.execresultId = execresultId;
	}

	public String getJvmNum() {
		return jvmNum;
	}

	public void setJvmNum(String jvmNum) {
		this.jvmNum = jvmNum;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Date getExecTime() {
		return execTime;
	}

	public void setExecTime(Date execTime) {
		this.execTime = execTime;
	}

	public String getExecMessage() {
		return execMessage;
	}

	public void setExecMessage(String execMessage) {
		this.execMessage = execMessage;
	}

	public short getExecFlag() {
		return execFlag;
	}

	public void setExecFlag(short execFlag) {
		this.execFlag = execFlag;
	}
}
