package com.admin_base.mybatis.plug;
import java.util.List;

import com.admin_base.util.PageIndex;
import com.admin_base.util.WebTool;
@SuppressWarnings("unchecked")
public class PageParameter {
	private List records;
	
	private PageIndex pageindex;
	
	private long pageCount;

	private int pageSize = 10;

	private int pageNow = 1;

	private long rowCount;
	
	private int startPage;

	private int pagecode = 5;
	public PageParameter() {
	}

	public int getFirstResult(){
		return (this.pageNow-1)* this.pageSize;
	}
	
	public int getPagecode() {
		return pagecode;
	}

	public void setPagecode(int pagecode) {
		this.pagecode = pagecode;
	}
	
	public PageParameter(int pageSize, int pageNow){
		this.pageSize = pageSize;
		this.pageNow = pageNow;
	}
	public PageParameter(int pageNow){
		this.pageNow = pageNow;
		startPage = (this.pageNow - 1) * this.pageSize;
	}

	public void setQueryResult(long rowCount, List records){
		setRowCount(rowCount);
		setRecords(records);
	}

	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
		setPageCount(this.rowCount % this.pageSize == 0?
					this.rowCount/this.pageSize :
					this.rowCount/this.pageSize+1
		);
	}
	
	public List getRecords() {
		return records;
	}

	public void setRecords(List records) {
		this.records = records;
	}


	public PageIndex getPageindex() {
		return pageindex;
	}

	public void setPageindex(PageIndex pageindex) {
		this.pageindex = pageindex;
	}


	public void setPageCount(long pageCount) {
		this.pageCount = pageCount;
		this.pageindex = WebTool.getPageIndex(pagecode, pageNow, pageCount);
	}

	public int getPageNow() {
		return pageNow;
	}

	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}

	public long getPageCount() {
		return pageCount;
	}
	
	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public long getRowCount() {
		return rowCount;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}


}
