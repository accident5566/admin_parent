package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

public class SelectConstant {

	private Integer value;
	private String text;
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public SelectConstant(Integer value, String text) {
		super();
		this.value = value;
		this.text = text;
	}
	public SelectConstant() {
		super();
	}
	public static List<SelectConstant> getCABillSelectList(){
		List<SelectConstant> CABillList = new ArrayList<SelectConstant>();
		CABillList.add(new SelectConstant(12,"ȫ��"));
		CABillList.add(new SelectConstant(10,"���"));
		CABillList.add(new SelectConstant(20,"����"));
		return CABillList;
	}
}
