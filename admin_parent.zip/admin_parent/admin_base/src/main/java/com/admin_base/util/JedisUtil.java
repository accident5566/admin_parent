package com.admin_base.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;


@Component
public class JedisUtil {
	private static final Logger log = Logger.getLogger(JedisUtil.class);
	
	@Resource
    private JedisPool jedisPool;
	/*
	 * ��ʼ���û����Ʒ����
	 * sign : product:[��Ʒ���] | user:[userIdentifier]
	 * 
	 */
	public boolean initBaseData( String sign, Map<String, String> baseDataHash) {
		Jedis jedis = null;
		try{
		 jedis = jedisPool.getResource();
		 jedis.auth(SystemProperty.getProperty("redis.password"));
		List<Object> allResults;
		int i = 5;
		do {
			Transaction t  = jedis.multi();
			t.hmset(sign, baseDataHash);
			allResults = t.exec();
			t.save();
			i--;
			//�ر�����
			jedisPool.returnResource(jedis);
		}while(allResults == null && i > 0);
		return true;
		}catch(Exception e){
			e.printStackTrace();
			log.error("Redis exception: "+ e.toString());
			return false;
		}finally{
			jedisPool.returnResource(jedis);
		}
	}
	

	public Map<String, String> getObjectHash(String sign) {
		Jedis jedis = null;
		Map<String, String> hash = null;
		try {
			jedis = jedisPool.getResource();
			jedis.auth(SystemProperty.getProperty("redis.password"));
			hash = jedis.hgetAll(sign);
            jedisPool.returnResource(jedis);
            return hash;
		}catch(Exception e) {
			log.error("Redis get connection: " + e.toString());
		}finally{
			jedisPool.returnResource(jedis);
			return hash;
        }
	}

    public boolean payProduct(Integer amount){
		Jedis jedis = jedisPool.getResource();
		//�û�����ݶ�
		Integer remainingNum;
		List<Object> allResults;
		do {
			//��ȡ��Ʒ�ݶ�
			List<String> nums = jedis.hmget("product:007", "remainingNum", "payingNum");
			remainingNum = Integer.parseInt(nums.get(0));
			Integer payingNum = Integer.parseInt(nums.get(1));
			System.out.println("remainingNum: " + remainingNum + "payingNum: " + payingNum);
			if (remainingNum >= amount) {
				//��ز�Ʒ�ݶ�
				jedis.watch("product:007");
				Transaction t  = jedis.multi();
				//�������շݶ�
				Integer nowRemainingNum = remainingNum - amount;
				Integer nowPayingNum = payingNum + amount;
				Map<String, String> hash = new HashMap<String, String>();
				hash.put("payingNum", nowPayingNum.toString());
				hash.put("remainingNum", nowRemainingNum.toString());
				//���÷ݶ�
				t.hmset("product:007", hash);
				allResults = t.exec();
				t.save();
				System.out.println("result: " + allResults + "payingNum:" + nowPayingNum.toString() + " remainingNum: " + nowRemainingNum.toString());
				//�ر�����
				jedisPool.returnResource(jedis);
				//TODO ȡ������discard()
				//TODO �־û�
				System.out.println("����ɹ�");
				return true;
			}else{
				System.out.println("����ʧ��");
				return false;
				
			}
		}while(allResults == null && amount <= remainingNum);
	}
	
}
