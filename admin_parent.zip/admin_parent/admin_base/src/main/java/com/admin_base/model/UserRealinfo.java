package com.admin_base.model;
import java.util.Date;
/***
 * ������Ϣʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class UserRealinfo {
	
	/*������ʶid*/
    private Integer id;

    /*UUID*/
    private String useridentifier;

    /*֤������(0:����֤)*/
    private Integer credential;

    /*֤������*/
    private String credentialno;

    /*��ʵ����*/
    private String realname;

    /*��֤����ʱ��*/
    private Date verifingtime;

    /*�Ƿ���֤�ɹ�(0:�ɹ�,1ʧ��)*/
    private Integer verified;

    /*��֤��ʱ��*/
    private Date verifiedtime;
    
    /*ÿ����֤ע���û�����*/
    private Integer authUserQuantity;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

    public Integer getCredential() {
        return credential;
    }

    public void setCredential(Integer credential) {
        this.credential = credential;
    }

    public String getCredentialno() {
        return credentialno;
    }

    public void setCredentialno(String credentialno) {
        this.credentialno = credentialno == null ? null : credentialno.trim();
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public Date getVerifingtime() {
        return verifingtime;
    }

    public void setVerifingtime(Date verifingtime) {
        this.verifingtime = verifingtime;
    }

    public Integer getVerified() {
        return verified;
    }

    public void setVerified(Integer verified) {
        this.verified = verified;
    }

    public Date getVerifiedtime() {
        return verifiedtime;
    }

    public void setVerifiedtime(Date verifiedtime) {
        this.verifiedtime = verifiedtime;
    }

	public UserRealinfo(Integer id, String useridentifier, Integer credential,
			String credentialno, String realname, Date verifingtime,
			Integer verified, Date verifiedtime) {
		super();
		this.id = id;
		this.useridentifier = useridentifier;
		this.credential = credential;
		this.credentialno = credentialno;
		this.realname = realname;
		this.verifingtime = verifingtime;
		this.verified = verified;
		this.verifiedtime = verifiedtime;
	}

	public UserRealinfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserRealinfo [id=" + id + ", useridentifier=" + useridentifier
				+ ", credential=" + credential + ", credentialno="
				+ credentialno + ", realname=" + realname + ", verifingtime="
				+ verifingtime + ", verified=" + verified + ", verifiedtime="
				+ verifiedtime + "]";
	}
    
    
}