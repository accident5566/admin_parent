package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

import com.admin_base.util.SystemProperty;


public class ProductType {

	private String  firstname;
	private Integer typeid;
	private String name;
	private String nameAndfirstName;
	
	public String getNameAndfirstName() {
		return nameAndfirstName;
	}
	public void setNameAndfirstName(String nameAndfirstName) {
		this.nameAndfirstName = nameAndfirstName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public Integer getTypeid() {
		return typeid;
	}
	public void setTypeid(Integer typeid) {
		this.typeid = typeid;
	}
	public ProductType(String name, Integer typeid) {
		super();
		this.name = name;
		this.typeid = typeid;
	}
	public ProductType(String name, String nameAndfirstName) {
		super();
		this.name = name;
		this.nameAndfirstName = nameAndfirstName;
	}
	public ProductType() {
		super();
	}
	public static List<ProductType>  getProList(){
		String[] listTypeid = SystemProperty.getProperty("product.type.typeid").split(",");
		String[] listname = SystemProperty.getProperty("product.type.name").split(",");
		String[] listfirstname = SystemProperty.getProperty("product.type.firstname").split(",");
		List<ProductType> list = new ArrayList<ProductType>();
		for(int i = 0;i<listTypeid.length;i++){
			list.add(new ProductType(listname[i], String.valueOf(Integer.valueOf(listTypeid[i])+","+listfirstname[i])));
		}
		return list;
	}
	public static String returnFirstName(List<ProductType> plist,String ptype){
		String firstName = "K";
		for(ProductType p :plist){
			if(String.valueOf(p.getTypeid()).equals(ptype)){
				firstName = p.getFirstname();
			}
		}
		return firstName;
	}
	public static void main(String[] args) {
		for(ProductType p :getProList()){
			System.out.println(p.name);
		}
	}
}
