package com.admin_base.dto.request;

import java.math.BigDecimal;

public class EnPayMoneyDTO {
	private Integer paySource;//֧����Դ  
	private String bankName;//��������
	private String bankCard;//����
	private String enterpriseName;//������֧��
	private String productIdentifier;//��Ʒ���
	private String province;//������ʡ��
	private String city;//�����г���
	private BigDecimal TotalSuccessOrderMoney;//�ɹ������ܽ��
	private Integer productType;//��Ʒ������
	private String batchNo;//��Ʒ�����κ�
	private Integer payStatus;//��ҵ���״̬
	private Integer characteristic;//��ť�Ƿ�����ʶ
	private String productNo;
	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	public Integer getCharacteristic() {
		return characteristic;
	}
	public void setCharacteristic(Integer characteristic) {
		this.characteristic = characteristic;
	}
	public Integer getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public Integer getProductType() {
		return productType;
	}
	public void setProductType(Integer productType) {
		this.productType = productType;
	}
	
	
	public EnPayMoneyDTO() {
	}
	public EnPayMoneyDTO(Integer paySource, String productIdentifier) {
		this.paySource = paySource;
		this.productIdentifier = productIdentifier;
	}
	public Integer getPaySource() {
		return paySource;
	}
	public void setPaySource(Integer paySource) {
		this.paySource = paySource;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getEnterpriseName() {
		return enterpriseName;
	}
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	public String getProductIdentifier() {
		return productIdentifier;
	}
	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public BigDecimal getTotalSuccessOrderMoney() {
		return TotalSuccessOrderMoney;
	}
	public void setTotalSuccessOrderMoney(BigDecimal totalSuccessOrderMoney) {
		TotalSuccessOrderMoney = totalSuccessOrderMoney;
	}
	@Override
	public String toString() {
		return "������: [֧����Դ=" + paySource + ", ������֧������="
				+ bankName + ", ����=" + bankCard + ", ������="
				+ enterpriseName + ", ��Ʒ��uuid=" + productIdentifier
				+ ", ������ʡ��=" + province + ", �����г���=" + city
				+ ", �ɹ������ܽ��=" + TotalSuccessOrderMoney + "]";
	}
	
	
}
