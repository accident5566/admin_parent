package com.admin_base.dto.response;

import java.math.BigDecimal;

public class SreceivedPayDTO {

	private Integer payFrom;
	private Integer totalSuceessOrder;
	private BigDecimal totalMoney;
	private String productIdentifier;
	private Integer buttonOk;
	
	public Integer getButtonOk() {
		return buttonOk;
	}
	public void setButtonOk(Integer buttonOk) {
		this.buttonOk = buttonOk;
	}
	public Integer getPayFrom() {
		return payFrom;
	}
	public void setPayFrom(Integer payFrom) {
		this.payFrom = payFrom;
	}
	public Integer getTotalSuceessOrder() {
		return totalSuceessOrder;
	}
	public void setTotalSuceessOrder(Integer totalSuceessOrder) {
		this.totalSuceessOrder = totalSuceessOrder;
	}
	public BigDecimal getTotalMoney() {
		return totalMoney;
	}
	public void setTotalMoney(BigDecimal totalMoney) {
		this.totalMoney = totalMoney;
	}
	public String getProductIdentifier() {
		return productIdentifier;
	}
	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public SreceivedPayDTO(Integer payFrom, Integer totalSuceessOrder,
			BigDecimal totalMoney, String productIdentifier,Integer buttonOk) {
		this.payFrom = payFrom;
		this.totalSuceessOrder = totalSuceessOrder;
		this.totalMoney = totalMoney;
		this.productIdentifier = productIdentifier;
		this.buttonOk = buttonOk;
	}
	public SreceivedPayDTO() {
	}
	
	
}
