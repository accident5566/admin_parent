package com.admin_base.util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Sping ������
 * @author zhao.dongsheng
 *
 */
public class SpringContextListener implements ServletContextListener {

	public void contextDestroyed(ServletContextEvent sce) {
		SpringBeanFactory.clear();
	}

	public void contextInitialized(ServletContextEvent sce) {
		SpringBeanFactory.init(sce.getServletContext());
	}

}
