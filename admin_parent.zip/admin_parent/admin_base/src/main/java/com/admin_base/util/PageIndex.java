package com.admin_base.util;
/***
 * ��ҳ������PageIndex
 * @author qiupeiwei
 */
public class PageIndex {
	private long startindex;//��ʼ����
	private long endindex;//��������
	
	public PageIndex(long startindex, long endindex) {
		this.startindex = startindex;
		this.endindex = endindex;
	}
	public long getStartindex() {
		return startindex;
	}
	public void setStartindex(long startindex) {
		this.startindex = startindex;
	}
	public long getEndindex() {
		return endindex;
	}
	public void setEndindex(long endindex) {
		this.endindex = endindex;
	}
	
}
