package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

public class OrderStatus {

	private Integer orderConstatnt;
	private String orderDesc;
	
	public Integer getOrderConstatnt() {
		return orderConstatnt;
	}
	public void setOrderConstatnt(Integer orderConstatnt) {
		this.orderConstatnt = orderConstatnt;
	}
	public String getOrderDesc() {
		return orderDesc;
	}
	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}
	
	public OrderStatus() {
		super();
	}
	public OrderStatus(Integer orderConstatnt, String orderDesc) {
		this.orderConstatnt = orderConstatnt;
		this.orderDesc = orderDesc;
	}
	public static List<OrderStatus> getOrderStatusList(){
		List<OrderStatus> orderList = new ArrayList<OrderStatus>();
		orderList.add(new OrderStatus(10,"���ڸ���"));
		orderList.add(new OrderStatus(20,"����ɹ�"));
		orderList.add(new OrderStatus(30,"����ʧ��"));
		orderList.add(new OrderStatus(40,"�ѽ�Ϣ"));
		orderList.add(new OrderStatus(50,"�Ѳ�������"));
		orderList.add(new OrderStatus(60,"����ɹ�"));
		orderList.add(new OrderStatus(90,"�ȴ�֧��"));
		return orderList;
	}
	public static List<OrderStatus> getOrderPaySourceList(){
		List<OrderStatus> orderPaySourceList = new ArrayList<OrderStatus>();
		orderPaySourceList.add(new OrderStatus(10,"����"));
		orderPaySourceList.add(new OrderStatus(20,"����"));
		return orderPaySourceList;
	}
}