package com.admin_base.dto.response;

import java.math.BigDecimal;
/***
 * 10���ƹ�  ��Ӫ��ϢDTO
 * @author guxiaojun
 * @Date 2015-10-15
 */
public class ActivityOCTStatisticDTOResult{
	

	/*�����׹�������ܶ�*/
	private BigDecimal dailyTotalAmount;
	/*���ղ����׹�����*/
	private Integer firstPurchaser;
	/*���շ��Ŵ���ȯ��*/
	private Integer dailyVoucherNum;
	/*����ʹ�ô���ȯ��*/
	private Integer dailyUsedVoucherNum;
	/*��ʷ�׹�������ܶ�*/
	private BigDecimal hisTotalAmount;
	/*��ʷ�����׹�����*/
	private Integer hisPurchaser;
	/*��ʷ���Ŵ���ȯ��*/
	private Integer hisVoucherNum;
	/*��ʷ�����׹�����*/
	private Integer hisUsedVoucherNum;
	
	public BigDecimal getDailyTotalAmount() {
		return dailyTotalAmount;
	}
	public void setDailyTotalAmount(BigDecimal dailyTotalAmount) {
		this.dailyTotalAmount = dailyTotalAmount;
	}
	public Integer getFirstPurchaser() {
		return firstPurchaser;
	}
	public void setFirstPurchaser(Integer firstPurchaser) {
		this.firstPurchaser = firstPurchaser;
	}
	public Integer getDailyVoucherNum() {
		return dailyVoucherNum;
	}
	public void setDailyVoucherNum(Integer dailyVoucherNum) {
		this.dailyVoucherNum = dailyVoucherNum;
	}
	public Integer getDailyUsedVoucherNum() {
		return dailyUsedVoucherNum;
	}
	public void setDailyUsedVoucherNum(Integer dailyUsedVoucherNum) {
		this.dailyUsedVoucherNum = dailyUsedVoucherNum;
	}
	public BigDecimal getHisTotalAmount() {
		return hisTotalAmount;
	}
	public void setHisTotalAmount(BigDecimal hisTotalAmount) {
		this.hisTotalAmount = hisTotalAmount;
	}
	public Integer getHisPurchaser() {
		return hisPurchaser;
	}
	public void setHisPurchaser(Integer hisPurchaser) {
		this.hisPurchaser = hisPurchaser;
	}
	public Integer getHisVoucherNum() {
		return hisVoucherNum;
	}
	public void setHisVoucherNum(Integer hisVoucherNum) {
		this.hisVoucherNum = hisVoucherNum;
	}
	public Integer getHisUsedVoucherNum() {
		return hisUsedVoucherNum;
	}
	public void setHisUsedVoucherNum(Integer hisUsedVoucherNum) {
		this.hisUsedVoucherNum = hisUsedVoucherNum;
	}
}
