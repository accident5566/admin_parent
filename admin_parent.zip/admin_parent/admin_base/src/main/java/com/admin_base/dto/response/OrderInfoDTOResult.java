package com.admin_base.dto.response;

import java.math.BigDecimal;
import java.util.Date;

import com.admin_base.util.CommonMsg;
/**
 * ���ݴ�����󡾶�Ӧ��controller��UsersController������signIn���������û���½
 * @author qiupeiwei
 * @Date 2015-03-13
 */
public class OrderInfoDTOResult extends CommonMsg{

    /*��������*/
    private BigDecimal extraInterest;
    
    /*��������*/
    private BigDecimal interest;
    
    /*�����*/
    private BigDecimal activityInterest;
    
    //����������Ϣ
    private String transDesc;
    
    //��ٻ�����
    private Date  lastDueDate;
    
    /*�������*/
    private String orderNo;
    
    /*�µ�ʱ��*/
    private Date orderTime;
    
    /*Ͷ�ʽ��*/
    private BigDecimal amount;
    
    /*��Ʒȫ��(ǰ̨:��Ʒ������+����)*/
    private String productName;
    
    // ��Ʒ���
    private String productNo;

    // ��Ʒ����
    private String productNum;
    
    // ��Ʒ������
    private Integer productType;
    
    /*��Ʒ�Ķ���������*/
    private BigDecimal extraYield;
    
    /*��Ϣʱ��*/
    private Date settleDate;

    /*Ͷ�ʷ���*/
    private Integer shareCount;
    
    //����״̬
    private int orderStatus;
    
    //�����ܽ��
    private BigDecimal totalAmount;

    /*��Ϣ����*/
    private Date valueDate;

    /*������*/
    private BigDecimal yield;

    //������ʱ��
    private Date serverTime;
    
    //��ٻ�������
    private Date repaymentDeadline;
    
    //�����
    private BigDecimal paymentAmount;

	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Date getLastDueDate() {
		return lastDueDate;
	}

	public void setLastDueDate(Date lastDueDate) {
		this.lastDueDate = lastDueDate;
	}

	public BigDecimal getExtraInterest() {
		if (extraInterest == null) {
			extraInterest = new BigDecimal("0");
		}
		return extraInterest;
	}

	public void setExtraInterest(BigDecimal extraInterest) {
		this.extraInterest = extraInterest;
	}

	public BigDecimal getInterest() {
		if (interest == null) {
			interest = new BigDecimal("0");
		}
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}
	
	public BigDecimal getActivityInterest() {
		if (activityInterest == null) {
			activityInterest = new BigDecimal("0");
		}
		return activityInterest;
	}

	public void setActivityInterest(BigDecimal activityInterest) {
		this.activityInterest = activityInterest;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public Integer getShareCount() {
		return shareCount;
	}

	public void setShareCount(Integer shareCount) {
		this.shareCount = shareCount;
	}

	public int getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(int orderStatus) {
		this.orderStatus = orderStatus;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public BigDecimal getYield() {
		return yield;
	}

	public void setYield(BigDecimal yield) {
		this.yield = yield;
	}

	public Date getServerTime() {
		return serverTime;
	}

	public void setServerTime(Date serverTime) {
		this.serverTime = serverTime;
	}

	public Date getRepaymentDeadline() {
		return repaymentDeadline;
	}

	public void setRepaymentDeadline(Date repaymentDeadline) {
		this.repaymentDeadline = repaymentDeadline;
	}
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

    public String getProductNum() {
        return productNum;
    }

    public void setProductNum(String productNum) {
        this.productNum = productNum;
    }

    public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public BigDecimal getExtraYield() {
		return extraYield;
	}
	
	public void setExtraYield(BigDecimal extraYield) {
		this.extraYield = extraYield;
	}

	public OrderInfoDTOResult() {
		super();
	}
}
