package com.admin_base.dao;

import java.util.List;
import java.util.Map;


public interface BaseMapper<T> {
    
	public Integer update(T t);
	
	public Integer save(T t);
	
	public Integer delete(T t);
	
	public T getInfo(T t);
	
	public List<T> getByPage(Map<String,Object> parametersMap);
	
	public List<T> getAll();
	
	public List<T> getAll(T t);
}
