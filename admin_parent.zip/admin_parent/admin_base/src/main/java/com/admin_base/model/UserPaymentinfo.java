package com.admin_base.model;

import java.util.Date;
/***
 * ֧����Ϣʵ����(��������)
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class UserPaymentinfo {
	
	/*��������ʶid*/
    private Integer id;

    /*���ܹ���֧������*/
    private String encryptedpassword;

    /*UUID*/
    private String useridentifier;

    /*��֤ʧ�ܴ���*/
    private Integer failedcount;

    /*���һ����֤ʧ��ʱ��*/
    private Date lastfailedtime;

    /*֧������ļ��ܴ�*/
    private String salt;

    /*������������ʱ��*/
    private Date settime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEncryptedpassword() {
        return encryptedpassword;
    }

    public void setEncryptedpassword(String encryptedpassword) {
        this.encryptedpassword = encryptedpassword == null ? null : encryptedpassword.trim();
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

    public Integer getFailedcount() {
        return failedcount;
    }

    public void setFailedcount(Integer failedcount) {
        this.failedcount = failedcount;
    }

    public Date getLastfailedtime() {
        return lastfailedtime;
    }

    public void setLastfailedtime(Date lastfailedtime) {
        this.lastfailedtime = lastfailedtime;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt == null ? null : salt.trim();
    }

    public Date getSettime() {
        return settime;
    }

    public void setSettime(Date settime) {
        this.settime = settime;
    }

	public UserPaymentinfo(Integer id, String encryptedpassword,
			String useridentifier, Integer failedcount, Date lastfailedtime,
			String salt, Date settime) {
		super();
		this.id = id;
		this.encryptedpassword = encryptedpassword;
		this.useridentifier = useridentifier;
		this.failedcount = failedcount;
		this.lastfailedtime = lastfailedtime;
		this.salt = salt;
		this.settime = settime;
	}

	public UserPaymentinfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserPaymentinfo [id=" + id + ", encryptedpassword="
				+ encryptedpassword + ", useridentifier=" + useridentifier
				+ ", failedcount=" + failedcount + ", lastfailedtime="
				+ lastfailedtime + ", salt=" + salt + ", settime=" + settime
				+ "]";
	}
    
    
}