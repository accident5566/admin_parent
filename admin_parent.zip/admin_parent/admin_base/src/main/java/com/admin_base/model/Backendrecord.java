package com.admin_base.model;

import java.math.BigDecimal;
import java.util.Date;

import com.admin_base.dto.request.PaymentsBackYinJiaDTO;
import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.dto.response.UserPaymentQueryMessage;
import com.admin_base.dto.yl.CommonMsg;
import org.apache.commons.lang3.StringUtils;

/***
 * ��̨�����ؿ��¼��
 * @author qiupeiwei
 * @Date 2015-05-07
 */
public class Backendrecord {

	/*��ʶid*/
	private Integer id;
	
	/*�������*/
	private String sn;
	
	/*����֤����*/
	private String accNo;
	
	/*�û�����ʵ����*/
	private String accName;
	
	/*�ؿ���*/
	private BigDecimal amount;
	
	/*��������*/
	private String bankName;
	
	/*�û����ֻ�����*/
	private String mobileNo;
	
	/*�������*/
	private String merOrderNo;
	
	/*�û���uuid*/
	private String useruuid;
	
	/*����ʱ��*/
	private Date createTime;
	
	/*�޸�ʱ��*/
	private Date updateTime;
	
	/*��Ʒ�Ļؿ��¼״̬(1.�ؿ���2.ʧ��,3.�ɹ�)*/
	private Integer status;

	/*���κ�*/
	private String batchNo;
	
	/*�����ؿ�״̬(00A4�����ڴ���ֱ�ӷ���)*/
	private String payStatus; 
	
	/*�����ؿ�������Ϣ*/
	private String payMsg;
	
	/*�����ؿ���˶�ʱ����ִ��ʱ��*/
	private  Date quartzExcuteTime;
	
	private String idNo;
	
	private String accType;
	
	private String accProvince;
	
	private String accCity;
	
	private String idType;
	
	private String merchantUrl;
	
	/*֧����Դ*/
	private Integer payFrom;
	
	
	
	public Integer getPayFrom() {
		return payFrom;
	}
	public void setPayFrom(Integer payFrom) {
		this.payFrom = payFrom;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccProvince() {
		return accProvince;
	}
	public void setAccProvince(String accProvince) {
		this.accProvince = accProvince;
	}
	public String getAccCity() {
		return accCity;
	}
	public void setAccCity(String accCity) {
		this.accCity = accCity;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getMerchantUrl() {
		return merchantUrl;
	}
	public void setMerchantUrl(String merchantUrl) {
		this.merchantUrl = merchantUrl;
	}
	public  Backendrecord getBackend(CommonMsg com,String batchNo){
		Backendrecord back = new Backendrecord();
		back.setPayStatus(com.getPayState());
		back.setSn(com.getSn());
		back.setBatchNo(batchNo);
		back.setPayMsg(com.getRemark());
		if(com.getPayState().equals("0000")){
			back.setStatus(3);	
		}else if(com.getPayState().equals("00A4")){
			back.setStatus(1);	
		}else{
			back.setStatus(2);
		}
		return back;
	}
	
	 public  Backendrecord getBackend(UserPaymentQueryMessage com,String batchNo){
		Backendrecord back = new Backendrecord();
		String remark = null;
		back.setPayStatus(String.valueOf(com.getStatus()));
		back.setSn(com.getLogno());
		back.setBatchNo(batchNo);
		switch (com.getStatus()) {
		case 1:
			remark = "������";
			break;
        case 2:
        	remark = "�ɹ�";
			break;
		default:
			remark = "ʧ��";
			break;
		}
		back.setPayMsg(remark);
		if(com.getStatus().equals(2)){
			back.setStatus(3);	
		}else if(com.getStatus().equals(1)){
			back.setStatus(1);	
		}else{
			back.setStatus(2);
		}
		return back;
	}
	
	 public static String UserPaymentYJMessage(UserPaymentQueryMessage com){
		 String remark = null;
		 switch (com.getStatus()) {
			case 1:
				remark = "������";
				break;
	        case 2:
	        	remark = "�ɹ�";
				break;
			default:
				remark = "ʧ��";
				break;
			}
		 return remark;
	 }
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSn() {
		return sn;
	}

	public Date getQuartzExcuteTime() {
		return quartzExcuteTime;
	}
	public void setQuartzExcuteTime(Date quartzExcuteTime) {
		this.quartzExcuteTime = quartzExcuteTime;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMerOrderNo() {
		return merOrderNo;
	}

	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}

	public String getUseruuid() {
		return useruuid;
	}

	public void setUseruuid(String useruuid) {
		this.useruuid = useruuid;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Backendrecord(Integer id, String sn, String accNo, String accName,
			BigDecimal amount, String bankName, String mobileNo, String merOrderNo,
			String useruuid, Date createTime, Date updateTime, Integer status,
			String batchNo) {
		super();
		this.id = id;
		this.sn = sn;
		this.accNo = accNo;
		this.accName = accName;
		this.amount = amount;
		this.bankName = bankName;
		this.mobileNo = mobileNo;
		this.merOrderNo = merOrderNo;
		this.useruuid = useruuid;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.status = status;
		this.batchNo = batchNo;
	}

	public Backendrecord(CommonMsg co,String batchNo,Integer payFrom) {
		this.batchNo = batchNo;
		this.sn = co.getSn();
		this.accNo = co.getAccNo();
		this.accName = co.getAccName();
		this.amount = co.getAmount();
		this.bankName = co.getBankName();
		this.mobileNo = co.getMobileNo();
		this.merOrderNo = co.getMerOrderNo();
		this.useruuid = co.getUserUuid();
		this.idNo = co.getIdNo();
		this.idType = co.getIdType();
		this.accProvince = co.getAccProvince();
		this.accCity = co.getAccCity();
		this.merchantUrl = co.getMerchantUrl();
		this.payFrom = payFrom;
	}

	public Backendrecord(OrderDetailDTOResult co, String batchNo, Integer payFrom) {
		String province = null;
		String city = null;

		if (StringUtils.isNotEmpty(co.getCity())) {
			if (!co.getCity().contains("|")) {
				province = co.getCity();
				city = co.getCity();
			} else {
				int caharIndex = co.getCity().indexOf("|");
				province = co.getCity().substring(0, caharIndex);
				city = co.getCity().substring(caharIndex + 1);
			}
		}

		this.batchNo = batchNo;
		this.sn = co.getOrderNo();
		this.accNo = co.getBankCardNo();
		this.accName = co.getRealName();
		this.amount = co.getPaymentAmount();
		this.bankName = co.getBankName();
		this.mobileNo = co.getCellphone();
		this.merOrderNo = co.getProductNo();
		this.useruuid = co.getUuid();
		this.idNo = co.getCredentialNo();
		this.idType = "0";
		this.accProvince = province;
		this.accCity = city;
		this.merchantUrl = "";
		this.payFrom = payFrom;
	}
	
	public Backendrecord(PaymentsBackYinJiaDTO co,String batchNo,Integer payFrom){
		this.batchNo = batchNo;
		this.amount = co.getAmount();
		this.sn = co.getLogno();
		this.payFrom = payFrom;
		
	}
	
	public Backendrecord() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getPayMsg() {
		return payMsg;
	}

	public void setPayMsg(String payMsg) {
		this.payMsg = payMsg;
	}
	
}
