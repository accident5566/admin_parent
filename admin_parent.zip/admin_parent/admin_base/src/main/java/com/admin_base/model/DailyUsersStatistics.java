package com.admin_base.model;

import java.math.BigDecimal;
import java.util.Date;


/***
 * ÿ���û�ͳ��ʵ����
 * @author guxiaojun
 * @Date 2015-11-11
 */
public class DailyUsersStatistics {
	
	/*��ʶid*/
	private Integer id;
	
	/*ͳ������ */
	private Date date;
	
	/*֧����Դ */
	private int source;
	
	/*�׹��û����� */
	private int firstPurchase;
	
	/*��֤�û��� */
	private int authUserQuantity;
	
	/*ע���û��� */
	private int registerQuantity;
	
	/*������ */
	private int ordersQuantity;
	
	/*�����ܶ� */
	private BigDecimal ordersAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}



	public int getSource() {
		return source;
	}

	public void setSource(int source) {
		this.source = source;
	}

	public int getAuthUserQuantity() {
		return authUserQuantity;
	}

	public void setAuthUserQuantity(int authUserQuantity) {
		this.authUserQuantity = authUserQuantity;
	}

	public int getRegisterQuantity() {
		return registerQuantity;
	}

	public void setRegisterQuantity(int registerQuantity) {
		this.registerQuantity = registerQuantity;
	}

	public int getOrdersQuantity() {
		return ordersQuantity;
	}

	public void setOrdersQuantity(int ordersQuantity) {
		this.ordersQuantity = ordersQuantity;
	}

	public BigDecimal getOrdersAmount() {
		return ordersAmount;
	}

	public void setOrdersAmount(BigDecimal ordersAmount) {
		this.ordersAmount = ordersAmount;
	}

	public int getFirstPurchase() {
		return firstPurchase;
	}

	public void setFirstPurchase(int firstPurchase) {
		this.firstPurchase = firstPurchase;
	}	
}
