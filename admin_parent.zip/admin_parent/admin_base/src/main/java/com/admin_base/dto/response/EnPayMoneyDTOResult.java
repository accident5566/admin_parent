package com.admin_base.dto.response;

import java.math.BigDecimal;

public class EnPayMoneyDTOResult{
	private String  channel;
	private Integer successOrder;
	private BigDecimal toSuccessMoney;
	private Integer payStatus;
	private Integer characteristic;
	
	public Integer getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}
	public Integer getCharacteristic() {
		return characteristic;
	}
	public void setCharacteristic(Integer characteristic) {
		this.characteristic = characteristic;
	}
	public EnPayMoneyDTOResult() {
	}
	public EnPayMoneyDTOResult(String channel, Integer successOrder,
			BigDecimal toSuccessMoney,Integer payStatus,Integer characteristic) {
		this.channel = channel;
		this.successOrder = successOrder;
		this.toSuccessMoney = toSuccessMoney;
		this.payStatus = payStatus;
		this.characteristic = characteristic;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getSuccessOrder() {
		return successOrder;
	}
	public void setSuccessOrder(Integer successOrder) {
		this.successOrder = successOrder;
	}
	public BigDecimal getToSuccessMoney() {
		return toSuccessMoney;
	}
	public void setToSuccessMoney(BigDecimal toSuccessMoney) {
		this.toSuccessMoney = toSuccessMoney;
	}
	
}
