package com.admin_base.model;

public class ProductEnterprise {

	private Integer id;
	private String bankName;
	private String bankCard;
	private String enterpriseName;
	private String productIdentifier;
	private String province;
	private String city;
	
	
	
	
	public  ProductEnterprise getProductEnterprise(Product pp) {
		ProductEnterprise p = new ProductEnterprise();
		p.setBankName(pp.getBankName());
		p.setBankCard(pp.getBankCard());
		p.setEnterpriseName(pp.getEnterpriseName());
		p.setProductIdentifier(pp.getProductIdentifier());
		p.setProvince(pp.getProvince());
		p.setCity(pp.getCity());
		return p;
	}
	public String getProductIdentifier() {
		return productIdentifier;
	}
	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getEnterpriseName() {
		return enterpriseName;
	}
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	
	
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public ProductEnterprise() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductEnterprise(Integer id, String bankName, String bankCard,
			String enterpriseName, String productIdentifier, String province,
			String city) {
		super();
		this.id = id;
		this.bankName = bankName;
		this.bankCard = bankCard;
		this.enterpriseName = enterpriseName;
		this.productIdentifier = productIdentifier;
		this.province = province;
		this.city = city;
	}
	@Override
	public String toString() {
		return "ProductEnterprise [id=" + id + ", bankName=" + bankName
				+ ", bankCard=" + bankCard + ", enterpriseName="
				+ enterpriseName + ", productIdentifier=" + productIdentifier
				+ ", province=" + province + ", city=" + city + "]";
	}
}
