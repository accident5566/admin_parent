package com.admin_base.constant;
/**
 * @author qiupeiwei
 * @Date 2015-03-12
 */
public class DateFormatConstant {
	public  static final String MINUTES_FORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";
	public  static final String MINUTES_FORMAT_YMDHM = "yyyy-MM-dd HH:mm";
	public  static final String MINUTES_FORMAT_YMD = "yyyy-MM-dd";
	public  static final String MINUTES_FORMAT_YMDMS = "yyyyMMddmmss";
}
