package com.admin_base.dto.request;

import java.util.ArrayList;
import java.util.List;

import com.admin_base.model.WCRecords;
import com.admin_base.model.WithdrawConfirm;


public class WithdrawConfirmDTO{
	
	//֧����Դ  
	private String batchNo;
	
	//����ʵ��
	private List<WithdrawConfirm> properties;

	
	public WithdrawConfirmDTO(String batchNo,List<WCRecords> wCRecordsList){
		List<WithdrawConfirm> temp = new ArrayList<WithdrawConfirm>();
		for(WCRecords w:wCRecordsList){
			WithdrawConfirm wc = new WithdrawConfirm();
			wc.setAmount(w.getApplyAmount());
	        wc.setBankName(w.getBankName());
	        wc.setCardNo(w.getBankCardNo());
	        wc.setCellphone(w.getCellphone());
	        wc.setFee(w.getFee());
	        wc.setIdCard(w.getIdCard());
	        wc.setOrderNo(w.getOrderNo());
	        wc.setUserIdentifier(w.getUserIdentifier());
	        wc.setUserName(w.getRealName());
	        wc.setCheckStatus(w.getCheckStatus());
	        temp.add(wc);
		}
		properties = temp;
		this.batchNo = batchNo;
		
	}
	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public List<WithdrawConfirm> getProperties() {
		return properties;
	}

	public void setProperties(List<WithdrawConfirm> properties) {
		this.properties = properties;
	}	
	
}
