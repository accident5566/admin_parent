package com.admin_base.mq;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.admin_base.constant.DateFormatConstant;
/***
 * ʵ����֤��Ϣ����
 * @author qiupeiwei
 * @Date 2015-03-17
 * 
 */

@Component
public class MessageSend {
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	public  void sendMsg(String directExchangeName,String jsonStr){
		System.out.println("��Ϣ����---------��ʼ----------ʱ����:"+new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS).format(new Date()));
//		rabbitTemplate.convertAndSend("realNameAuthQueue",jsonStr);
		rabbitTemplate.convertAndSend(directExchangeName,jsonStr);
//		rabbitTemplate.convertSendAndReceive(jsonStr);
//		rabbitTemplate.convertSendAndReceive(routingKey, message, messagePostProcessor)
		System.out.println("��Ϣ����---------����----------ʱ����:"+new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS).format(new Date()));
	}
}
