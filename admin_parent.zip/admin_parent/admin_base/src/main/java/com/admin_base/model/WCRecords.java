package com.admin_base.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @see ���������¼ʵ������Ϣ
 * @author peiwei
 * @Date 2015-11-23
 */

public class WCRecords implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4644930639424411992L;
	//������ʶid
	private Integer id;
	//������ˮ��
	private String orderNo;
	//�û�UUID
	private String userIdentifier;
	//������������
	@JsonIgnore
	private Date applyDate;
	//�����������
	@JsonIgnore
	private Date checkDate;
	//10 => ����, 20 => ����
	private Integer paySource;
	//��������
	private String bankName;
	//���п���
	private String bankCardNo;
	//�������ֽ��
	private BigDecimal applyAmount;
	//������
	private BigDecimal fee;
	//ʵ�����ֽ��
	private BigDecimal actualAmout;
	//0 => ������, 1 => �����ɹ�, 2 => ����ʧ�� 3=>������ 4=>���ɹ� 5=>���ʧ��
	private Integer checkStatus;
	//ip
	private String ip;
	private String province;
	private String city;
	//�������������
	private String idCard;
	//ҳ��չʾʹ��
	private String cellphone;
	private String realName;
	private String dangerousLevel;//Σ�յȼ�
	private Integer hours;//Сʱ
	@JsonIgnore
	private Date verifiedTime;
	
	
	public Date getVerifiedTime() {
		return verifiedTime;
	}
	public void setVerifiedTime(Date verifiedTime) {
		this.verifiedTime = verifiedTime;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getHours() {
		return hours;
	}
	public void setHours(Integer hours) {
		this.hours = hours;
	}
	public String getDangerousLevel() {
		return dangerousLevel;
	}
	public void setDangerousLevel(String dangerousLevel) {
		this.dangerousLevel = dangerousLevel;
	}
	public WCRecords() {
		super();
		// TODO Auto-generated constructor stub
	}
	public WCRecords(Integer id, String orderNo, String userIdentifier,
			Date applyDate, Date checkDate, Integer paySource, String bankName,
			String bankCardNo, BigDecimal applyAmount, BigDecimal fee,
			BigDecimal actualAmout, Integer checkStatus, String ip,
			String cellphone, String realName) {
		super();
		this.id = id;
		this.orderNo = orderNo;
		this.userIdentifier = userIdentifier;
		this.applyDate = applyDate;
		this.checkDate = checkDate;
		this.paySource = paySource;
		this.bankName = bankName;
		this.bankCardNo = bankCardNo;
		this.applyAmount = applyAmount;
		this.fee = fee;
		this.actualAmout = actualAmout;
		this.checkStatus = checkStatus;
		this.ip = ip;
		this.cellphone = cellphone;
		this.realName = realName;
	}
	public WCRecords(WCRecords wCRecords){
		this.orderNo = wCRecords.getOrderNo();
		this.checkDate = new Date();
		this.checkStatus = 2;
	}
	
	public WCRecords(WCRecords wCRecords,Integer status){
		this.applyDate = wCRecords.getApplyDate();
		this.checkStatus = status;
	}
	public String getCellphone() {
		return cellphone;
	}
	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	public Date getApplyDate() {
		return applyDate;
	}
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}
	public Date getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}
	public Integer getPaySource() {
		return paySource;
	}
	public void setPaySource(Integer paySource) {
		this.paySource = paySource;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCardNo() {
		return bankCardNo;
	}
	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}
	public BigDecimal getApplyAmount() {
		return applyAmount;
	}
	public void setApplyAmount(BigDecimal applyAmount) {
		this.applyAmount = applyAmount;
	}
	public BigDecimal getFee() {
		return fee;
	}
	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}
	public BigDecimal getActualAmout() {
		return actualAmout;
	}
	public void setActualAmout(BigDecimal actualAmout) {
		this.actualAmout = actualAmout;
	}
	public Integer getCheckStatus() {
		return checkStatus;
	}
	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	
}
