package com.admin_base.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author qiupeiwei
 */
public class ScheduleCtrl implements Serializable {
	
	/**
	 * 
	 * 
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 */
	private int scheduleId;
	
	/**
	 */
	private String jvmNum;
	
	/**
	 */
	private String jobName;
	
	/**
	 */
	private Integer jobStatus; 
	
	/**
	 */
	private String jobDetail;
	
	/**
	 */
	private Integer execFlag;
	
	/**
	 */
	private Integer lastExecFlag;
	
	/**
	 */
	private Date lastExecTime;

	public int getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	
	public String getJvmNum() {
		return jvmNum;
	}

	public void setJvmNum(String jvmNum) {
		this.jvmNum = jvmNum;
	}

	public String getJobDetail() {
		return jobDetail;
	}

	public void setJobDetail(String jobDetail) {
		this.jobDetail = jobDetail;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
	public Integer getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(Integer jobStatus) {
		this.jobStatus = jobStatus;
	}

	public Integer getExecFlag() {
		return execFlag;
	}

	public void setExecFlag(Integer execFlag) {
		this.execFlag = execFlag;
	}

	public Integer getLastExecFlag() {
		return lastExecFlag;
	}

	public void setLastExecFlag(Integer lastExecFlag) {
		this.lastExecFlag = lastExecFlag;
	}

	public Date getLastExecTime() {
		return lastExecTime;
	}

	public void setLastExecTime(Date lastExecTime) {
		this.lastExecTime = lastExecTime;
	}
}
