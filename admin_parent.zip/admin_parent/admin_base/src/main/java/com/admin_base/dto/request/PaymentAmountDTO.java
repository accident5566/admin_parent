package com.admin_base.dto.request;

import com.admin_base.dto.yl.CommonModel;


public class PaymentAmountDTO extends CommonModel{

	
}
