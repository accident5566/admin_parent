package com.admin_base.model;

import java.math.BigDecimal;

/**
 * ���ڲ�Ʒ��
 * @author peiwei
 * @Date 2015-05-20
 */
public class CAproducts {

	/*��ʶid*/
	private Integer id;
	
	/*��Ʒ��uuid*/
	private String productIdentifier;
	
	/*�Ƿ���*/
	private Integer enableSale;
	
	/*�ۼ��������*/
	private BigDecimal totalSaleAmount;
	
	/*�ۼ�������*/
	private BigDecimal totalInterest;
	
	/*�ۼ����ֽ��*/
	private BigDecimal totalRedeemAmount;
	
	/*�ۼ���������*/
	private BigDecimal totalRedeemInterest;
	
	/*�����ӱ��*/
	private String subProductNo;
	
	/*�������ֶ��*/
	private BigDecimal perRemainRedeemAmount;
	
	/*�ж�Э������*/
	private String accName;
	
	/*ί��Э������*/
	private String conName;
	
	public CAproducts(String productIdentifier) {
		super();
		this.productIdentifier = productIdentifier;
	}

	
	public CAproducts() {
		super();
		// TODO Auto-generated constructor stub
	}


	public CAproducts getCAproducts(CAProdcutpackage caProdcutpackage){
		CAproducts caproducts = new CAproducts();
		caproducts.setProductIdentifier("CA1505290118");//��Ʒ���
		caproducts.setEnableSale(1);//�Ƿ���
		caproducts.setSubProductNo(caProdcutpackage.getPackageNo());//�����ӱ��
		caproducts.setPerRemainRedeemAmount(new BigDecimal(100000000));//�������ֽ��
		caproducts.setAccName("��ʱΪ��");//�ж�Э��
		caproducts.setConName("��ʱΪ��");//ί��Э��
		return caproducts;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public Integer getEnableSale() {
		return enableSale;
	}

	public void setEnableSale(Integer enableSale) {
		this.enableSale = enableSale;
	}

	public BigDecimal getTotalSaleAmount() {
		return totalSaleAmount;
	}

	public void setTotalSaleAmount(BigDecimal totalSaleAmount) {
		this.totalSaleAmount = totalSaleAmount;
	}

	public BigDecimal getTotalInterest() {
		return totalInterest;
	}

	public void setTotalInterest(BigDecimal totalInterest) {
		this.totalInterest = totalInterest;
	}

	public BigDecimal getTotalRedeemAmount() {
		return totalRedeemAmount;
	}

	public void setTotalRedeemAmount(BigDecimal totalRedeemAmount) {
		this.totalRedeemAmount = totalRedeemAmount;
	}

	public BigDecimal getTotalRedeemInterest() {
		return totalRedeemInterest;
	}

	public void setTotalRedeemInterest(BigDecimal totalRedeemInterest) {
		this.totalRedeemInterest = totalRedeemInterest;
	}

	public String getSubProductNo() {
		return subProductNo;
	}

	public void setSubProductNo(String subProductNo) {
		this.subProductNo = subProductNo;
	}

	public BigDecimal getPerRemainRedeemAmount() {
		return perRemainRedeemAmount;
	}

	public void setPerRemainRedeemAmount(BigDecimal perRemainRedeemAmount) {
		this.perRemainRedeemAmount = perRemainRedeemAmount;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}
}
