package com.admin_base.util;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.admin_base.model.MsgEntity;

/***
 * http�ӿڵ��ø�����
 * @author qiupeiwei
 * @Date 2015-03-17
 */
public class HttpUtil {
	private static final Logger log = Logger.getLogger(HttpUtil.class.getName());
	private static Map<String,String> httpCfgParamMap = null;
	
	@SuppressWarnings("unchecked")
	public  Map sendHttpRequest(String targetSys,String targetService,String paramsStr,String sendType){
		if(null == httpCfgParamMap){
			//��ʼ��http����map
			loadHttpCfgParamMap();
		}
		Map map = new HashMap();
		String responseString = null;
		//��ȡĿ��ϵͳ��Ŀ����� ��װ����url
		String targetSysStr = httpCfgParamMap.get(targetSys);
		String targetServiceStr = httpCfgParamMap.get(targetService);
		String url = targetSysStr + targetServiceStr;
		
		DefaultHttpRequestRetryHandler dhr = new DefaultHttpRequestRetryHandler(5,true);//�������Ĭ���ط�5��
		HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
		CloseableHttpClient httpClient = httpClientBuilder.setRetryHandler(dhr).build();

		if(null != sendType && sendType.equals("GET")){
			paramsStr = paramsStr.toString().replaceAll("\"", "%22").replaceAll("\\{", "%7b").replaceAll("\\}", "%7d");
//			paramsStr = paramsStr.toString();
			url = url + "?" + paramsStr;
			log.info("http����ӿ� urlget:"+url);
			HttpGet httpget = new HttpGet(url);
			httpget.addHeader(new BasicHeader("", ""));
			log.info("http����ӿ� httpgetURI:"+httpget.getURI());
			System.out.println("======================================"+httpget.getAllHeaders());
			CloseableHttpResponse httpResponse = null;
			try {
				httpResponse = httpClient.execute(httpget);
				StatusLine statusLine = httpResponse.getStatusLine();
				HttpEntity entity = httpResponse.getEntity();
				if(entity != null){
					responseString = EntityUtils.toString(entity);
				}
				map.put("respStatus", statusLine.getStatusCode());
				map.put("respContent", responseString);
				log.info("http����ӿ� statusLine_get:"+statusLine.toString());
				log.info("http����ӿ� statusLineCode_get:"+statusLine.getStatusCode());
				log.info("http����ӿ� responseContent_get:"+responseString);
				
			} catch (ClientProtocolException e) {
				log.error("http����ӿ� http�����쳣��");
				e.printStackTrace();
			} catch (IOException e) {
				log.error("http����ӿ� http���ӷ��������쳣��");
				e.printStackTrace();
			} finally{
				try {
					httpResponse.close();
				} catch (IOException e) {
					log.error("http����ӿ� �Ͽ�http�����쳣��");
					e.printStackTrace();
				}
			}
		}else if(null != sendType && sendType.equals("POST")){
			CloseableHttpResponse httpResponse = null;
			try {
				HttpPost httpPost = new HttpPost(url);
				System.out.println("httpPostURI111:"+httpPost.getURI());
				
				//��������ʹ��䳬ʱʱ��
//				RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(600000).setConnectTimeout(50000).build();
				RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(900000).setConnectTimeout(900000).build();
				httpPost.setConfig(requestConfig);
				if(targetSys.equals("sms.server.host")){
					httpPost.addHeader("Content-Type", "application/json");
				}else if(targetSys.equals("pay.gateway")){
					httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
				}else if(targetSys.equals("pay.gateway")){
					httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
				}
				
				
				//ʹ��Url����ı��Ĳ���
//				params = URLEncoder.encode(params,"UTF-8");
//				List<NameValuePair> list = new ArrayList<NameValuePair>();
//				list.add(new BasicNameValuePair(paramsName, params));
//				UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(list,"UTF-8");
//				System.out.println("formEntity:"+EntityUtils.toString(formEntity));
//				httpPost.setEntity(formEntity);
				
				//��ʹ��Url����ı��Ĳ���
				String params_noEncode = paramsStr;
				log.info("http����ӿ� params_noEncode:"+params_noEncode);
				HttpEntity httpEntity = new StringEntity(params_noEncode,"UTF-8");
				log.info("http����ӿ� HttpEntityStr:"+EntityUtils.toString(httpEntity));
				httpPost.setEntity(httpEntity);
				
				httpResponse = httpClient.execute(httpPost); 
				StatusLine statusLine = httpResponse.getStatusLine();
				HttpEntity entity = httpResponse.getEntity();
				if(entity != null){
//					byte[] bs = EntityUtils.toString(entity).getBytes();
//					responseString = new String(bs, "UTF-8");
					responseString = EntityUtils.toString(entity);
				}
				map.put("respStatus", statusLine.getStatusCode());
				map.put("respContent", responseString);
				log.info("http����ӿ� statusLine_post:"+statusLine.toString());
				log.info("http����ӿ� statusLineCode_post:"+statusLine.getStatusCode());
				log.info("http����ӿ� responseFlag_post:"+String.valueOf(statusLine.getStatusCode()).equals("200"));
				log.info("http����ӿ� responseContent_post:"+responseString);
				
				System.out.println("http����ӿ� statusLine_post:"+statusLine.toString());
				System.out.println("http����ӿ� statusLineCode_post:"+statusLine.getStatusCode());
				System.out.println("http����ӿ� responseFlag_post:"+String.valueOf(statusLine.getStatusCode()).equals("200"));
				System.out.println("http����ӿ� responseContent_post:"+responseString);
								
			} catch (ClientProtocolException e) {
				log.error("http����ӿ� http�����쳣��");
				e.printStackTrace();
			} catch (IOException e) {
				log.error("http����ӿ� http���ӷ��������쳣��");
				e.printStackTrace();
			} finally{
				try {
					if(httpResponse != null){
						httpResponse.close();
					}
				} catch (IOException e) {
					log.error("http����ӿ� �Ͽ�http�����쳣��");
					e.printStackTrace();
				}
			}
		}
		
		return map;
	}
	
	private  void loadHttpCfgParamMap(){
		Properties prop = new Properties();
		try {
			InputStream in = this.getClass().getClassLoader().getResourceAsStream("yj_admin.properties");
			prop.load(in);
			Set set = prop.stringPropertyNames();
			Iterator<String> it = set.iterator();
			httpCfgParamMap = new HashMap();
			while(it.hasNext()){
				String key = it.next();
				log.info("http����ӿ� httpCfgParamMap key:"+key);
				httpCfgParamMap.put(key, prop.getProperty(key).trim());
			}
			log.info("http����ӿ� httpCfgParamMap:"+httpCfgParamMap.toString());
			
		} catch (IOException e) {
			log.error("http����ӿ� ��ʼ��http����map�쳣��");
			e.printStackTrace();
		}
		
//		httpCfgParamMap = new HashMap();
//////		httpCfgParamMap.put("userAuthRequestService", "/paycore/services/userAuthRequestService");
//		httpCfgParamMap.put("easyLinkPayQueryRequestService", "/paycore/services/easyLinkPayQueryRequestService");
//		httpCfgParamMap.put("easyLinkGatherQueryRequestService", "/paycore/services/easyLinkGatherQueryRequestService");
////		httpCfgParamMap.put("paycore", "http://10.1.10.119:10006");
//		httpCfgParamMap.put("paycore", "http://10.1.9.6:10000");
//		httpCfgParamMap.put("test", "http://10.1.10.140:8080/EOperation");
//		httpCfgParamMap.put("testservice", "/BAbillPool/BAbillPoolCheckSuccess.action");

//		httpCfgParamMap.put("paycore", "http://10.1.10.140:8080/EOperation");
//		httpCfgParamMap.put("easyLinkGatherRequestService", "/BAbillPool/BAbillPoolCheckSuccess.action");
	}
	
	
	/***
	 * ���ŷ��ͷ���
	 * @return ���ض��ŷ��͵��óɹ���ʧ�ܵı�ʶ
	 * @throws Exception 
	 */
	public  boolean sendMsg(String phone,String msgContent) throws Exception{
		//1. �Ƿ�ȷʵ���Ͷ���
				String smsEnable = SystemProperty.getProperty("sms.enable");
				if (smsEnable == null || smsEnable.isEmpty() || !smsEnable.equalsIgnoreCase("true")) {
					log.info("SMS���ͱ��رգ�����򿪣�������sms.enable=true(yj_admin.properties)");
					return true;
				}
				
				boolean flag = true;
				try {
					 MsgEntity msg = new MsgEntity(phone, msgContent);
					  System.out.println(msg.toJson());
					  log.info("���ŷ���json��:"+msg.toJson());
					  Map<String,Object> result =  sendHttpRequest("sms.server.host","sms.server.url",msg.toJson(),"POST");
					  String returnStatus = result.get("respStatus").toString();
					  log.info("���ŷ���״̬:"+returnStatus);
					  String returnContent = result.get("respContent").toString();
					  log.info("���ŷ��͵���������:"+returnContent);
					  System.out.println(returnStatus);
					  System.out.println(returnContent);
				} catch (Exception e) {
					flag = false;
					log.error("���ŷ���ʧ��---ԭ����:"+e.getMessage()+"ʱ����:"+"�ֻ�����:"+phone);
				}
				  return flag;
	}
	/**
	 * ����UrlEncodedFormEntity(post��ʽ)
	 * @param targetSys urlhost
	 * @param targetService ����ӿ�
	 * @param paramsObject ����
	 * @return
	 */
	public  Map<String,Object> sendHttpRequestVersionTwo(String targetSys, String targetService, Object paramEntity){
	
		
		List<BasicNameValuePair> postPairs = this.add("", paramEntity, null);
		
		if(null == httpCfgParamMap){
	//��ʼ��http����map
	loadHttpCfgParamMap();
	}
	Map<String,Object> map = new HashMap<String,Object>();
	String responseString = null;
	//��ȡĿ��ϵͳ��Ŀ����� ��װ����url
	String targetSysStr = httpCfgParamMap.get(targetSys);
	String targetServiceStr = httpCfgParamMap.get(targetService);
	String url = targetSysStr + targetServiceStr;

	DefaultHttpRequestRetryHandler dhr = new DefaultHttpRequestRetryHandler(5,true);//�������Ĭ���ط�5��
	HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
	CloseableHttpClient httpClient = httpClientBuilder.setRetryHandler(dhr).build();

	CloseableHttpResponse httpResponse = null;
	try {
	HttpPost httpPost = new HttpPost(url);
	log.info("httpPostURI:"+httpPost.getURI());

	//��������ʹ��䳬ʱʱ��
	RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(900000).setConnectTimeout(900000).build();
	httpPost.setConfig(requestConfig);
	if(targetSys.equals("sms.server.host")){
	httpPost.addHeader("Content-Type", "application/json");
	}else if(targetSys.equals("paycore")){
	httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
	}else if(targetSys.equals("pay.gateway")){
	httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
	}

	UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(postPairs,"UTF-8");
	log.info("formEntity:"+EntityUtils.toString(formEntity));
	httpPost.setEntity(formEntity);

	httpResponse = httpClient.execute(httpPost); 
	StatusLine statusLine = httpResponse.getStatusLine();
	HttpEntity entity = httpResponse.getEntity();
	if(entity != null){
	responseString = EntityUtils.toString(entity);
	}

	map.put("respStatus", statusLine.getStatusCode());
	map.put("respContent", responseString);
	log.info("http����ӿ� statusLine_post:"+statusLine.toString());
	log.info("http����ӿ� statusLineCode_post:"+statusLine.getStatusCode());
	log.info("http����ӿ� responseFlag_post:"+String.valueOf(statusLine.getStatusCode()).equals("200"));
	log.info("http����ӿ� responseContent_post:"+responseString);
	} catch (ClientProtocolException e) {
	log.error("http����ӿ� http�����쳣��");
	e.printStackTrace();
	} catch (IOException e) {
	log.error("http����ӿ� http���ӷ��������쳣��");
	e.printStackTrace();
	} finally{
	try {
	if(httpResponse != null){
	httpResponse.close();
	}
	} catch (IOException e) {
	log.error("http����ӿ� �Ͽ�http�����쳣��");
	e.printStackTrace();
	}
	}
	return map;
	}

	private List<BasicNameValuePair> addListEveryFieldsToMap(String prefix, List listObject, List<BasicNameValuePair> list){
		if (listObject == null) {
			return list;
		}
		if (list == null) {
			list = new ArrayList<BasicNameValuePair>();
		}
		for (int i = 0; i < listObject.size(); i++) {
			Object o = listObject.get(i);
			list = add(prefix+"["+i+"].", o, list);
		}
		
		return list;
	}
	
	/**
	 * ��������ת��Ϊ��ֵ��,��list�����ȡ
	 * @param prefix
	 * @param object
	 * @param list
	 * @return
	 */
	private List<BasicNameValuePair> add(String prefix, Object object, List<BasicNameValuePair> list){
		if (list == null) {
			list = new ArrayList<BasicNameValuePair>();
		}
		int num = 0;
		Class clazz = object.getClass();
		while (num < 3) {
			//��ֹ��ѭ�� �Ӷ��ص�������
			if(num >= 3 || clazz == Object.class){
				break;
			}
			Field[] fields = clazz.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				try {
					Object tem = field.get(object);
					if (tem == null) {
						continue;
					}
					if (tem instanceof List && !((List) tem).isEmpty()) {
						list = addListEveryFieldsToMap(field.getName(),(List)tem, list);
					}else {
						list.add(new BasicNameValuePair(prefix + field.getName(), tem.toString()));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			num ++;
			clazz = clazz.getSuperclass();
		}
		return list;
	}

	
  public static void main(String[] args) throws Exception {
	try {
		new HttpUtil().sendMsg("13616218253","������ı�1���Ѳ��������Ϣ��4.00Ԫ���黹���������п���");
	} catch (Exception e) {
		e.printStackTrace();
	}
}	
}
