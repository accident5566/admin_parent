package com.admin_base.model;

import java.math.BigDecimal;

public class OrdersEx extends Orders{
  
	private BigDecimal suminterest;
	
	private BigDecimal sumextraInterest;
	
	private BigDecimal sumamount;
	
	private BigDecimal activityInterest;
	
	private BigDecimal sumMoney;
	
	private Integer countSize;
	
	public Integer getCountSize() {
		return countSize;
	}

	public void setCountSize(Integer countSize) {
		this.countSize = countSize;
	}

	public BigDecimal getSuminterest() {
		return suminterest;
	}

	public void setSuminterest(BigDecimal suminterest) {
		this.suminterest = suminterest;
	}

	public BigDecimal getSumextraInterest() {
		return sumextraInterest;
	}

	public void setSumextraInterest(BigDecimal sumextraInterest) {
		this.sumextraInterest = sumextraInterest;
	}

	public BigDecimal getSumamount() {
		return sumamount;
	}

	public void setSumamount(BigDecimal sumamount) {
		this.sumamount = sumamount;
	}

	public BigDecimal getActivityInterest() {
		return activityInterest;
	}

	public void setActivityInterest(BigDecimal activityInterest) {
		this.activityInterest = activityInterest;
	}

	public BigDecimal getSumMoney() {
		return sumMoney;
	}

	public void setSumMoney(BigDecimal sumMoney) {
		this.sumMoney = sumMoney;
	}
	
	
}
