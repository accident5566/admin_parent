package com.admin_base.model;

import java.util.Date;

/***
 * �󿨼�¼ʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class UsersBankCardRecords {
	
	/*������ʶid*/
    private Integer id;

    /*UUID*/
    private String useridentifier;

    /*�����*/
    private String bankcardno;

    /*����������*/
    private String bankname;

    /*����������*/
    private String cityname;

    /*����ַ*/
    private String cardaddress;

    /*��ע*/
    private String remark;

    /*������֧����ˮ��*/
    private String sequenceno;

    /*�Ƿ�󶨳ɹ�(0���ɹ�,1ʧ��)*/
    private String verified;

    /*�󿨳ɹ�ʱ��*/
    private Date verifiedtime;

    /*�����ʱ��*/
    private Date verifingtime;

    /*�ӿڻص�����������Ϣ*/
    private String transDesc;
    
    public UsersBankCardRecords(String userId,String batchNo, String verified,
			Date verifiedtime) {
		this.useridentifier = userId;
		this.sequenceno = batchNo;
		this.verified = verified;
		this.verifiedtime = verifiedtime;
	}

    
	public UsersBankCardRecords(String useridentifier, String sequenceno,
			String verified, Date verifiedtime, String transDesc) {
		super();
		this.useridentifier = useridentifier;
		this.sequenceno = sequenceno;
		this.verified = verified;
		this.verifiedtime = verifiedtime;
		this.transDesc = transDesc;
	}
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUseridentifier() {
        return useridentifier;
    }

    public void setUseridentifier(String useridentifier) {
        this.useridentifier = useridentifier == null ? null : useridentifier.trim();
    }

    public String getBankcardno() {
        return bankcardno;
    }

    public void setBankcardno(String bankcardno) {
        this.bankcardno = bankcardno == null ? null : bankcardno.trim();
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname == null ? null : bankname.trim();
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname == null ? null : cityname.trim();
    }

    public String getCardaddress() {
        return cardaddress;
    }

    public void setCardaddress(String cardaddress) {
        this.cardaddress = cardaddress == null ? null : cardaddress.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(String sequenceno) {
        this.sequenceno = sequenceno == null ? null : sequenceno.trim();
    }

    public String getVerified() {
        return verified;
    }

    public void setVerified(String verified) {
        this.verified = verified;
    }

    public Date getVerifiedtime() {
        return verifiedtime;
    }

    public void setVerifiedtime(Date verifiedtime) {
        this.verifiedtime = verifiedtime;
    }

    public Date getVerifingtime() {
        return verifingtime;
    }

    public void setVerifingtime(Date verifingtime) {
        this.verifingtime = verifingtime;
    }

	public UsersBankCardRecords(Integer id, String useridentifier,
			String bankcardno, String bankname, String cityname,
			String cardaddress, String remark, String sequenceno,
			String verified, Date verifiedtime, Date verifingtime) {
		super();
		this.id = id;
		this.useridentifier = useridentifier;
		this.bankcardno = bankcardno;
		this.bankname = bankname;
		this.cityname = cityname;
		this.cardaddress = cardaddress;
		this.remark = remark;
		this.sequenceno = sequenceno;
		this.verified = verified;
		this.verifiedtime = verifiedtime;
		this.verifingtime = verifingtime;
	}

	public UsersBankCardRecords() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UsersBankCardRecords(String useridentifier, String sequenceno) {
		super();
		this.useridentifier = useridentifier;
		this.sequenceno = sequenceno;
	}
	@Override
	public String toString() {
		return "UsersBankCardRecords [id=" + id + ", useridentifier="
				+ useridentifier + ", bankcardno=" + bankcardno + ", bankname="
				+ bankname + ", cityname=" + cityname + ", cardaddress="
				+ cardaddress + ", remark=" + remark + ", sequenceno="
				+ sequenceno + ", verified=" + verified + ", verifiedtime="
				+ verifiedtime + ", verifingtime=" + verifingtime + "]";
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
}