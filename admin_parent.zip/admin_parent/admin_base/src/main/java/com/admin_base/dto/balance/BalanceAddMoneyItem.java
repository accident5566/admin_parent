package com.admin_base.dto.balance;

import com.admin_base.dto.response.OrderDetailDTOResult;

import java.math.BigDecimal;

/**
 * ���ϵͳ�Ӽ���
 * @author Chengfei.Sun on 2015/12/1.
 */
public class BalanceAddMoneyItem {
    //���
    private BigDecimal amount;

    //�û�UUID
    private String userIdentifier;

    //�û���
    private String userName;

    //�ֻ�����
    private String cellphone;

    //������
    private String orderNo;

    public BalanceAddMoneyItem() {
        super();
    }

    public BalanceAddMoneyItem(OrderDetailDTOResult orderDetailDTOResult) {
        super();
        this.amount = orderDetailDTOResult.getPaymentAmount();
        this.userIdentifier = orderDetailDTOResult.getUuid();
        this.userName = orderDetailDTOResult.getRealName();
        this.cellphone = orderDetailDTOResult.getCellphone();
        this.orderNo = orderDetailDTOResult.getOrderNo();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
