package com.admin_base.dto.response;

import java.math.BigDecimal;

public class ReconciliationQueryYiJiaDTOMsg {

	private BigDecimal amount;
	private String status;
	private String orderno;
	private String mobile;
	/**
	 * ���˽��
	 * @return
	 */
	private String msg;
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrderno() {
		return orderno;
	}
	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
