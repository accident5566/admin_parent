package com.admin_base.dto.balance;

import java.util.List;

/**
 * ���ϵͳ�Ӽ�������DTO
 * @author Chengfei.Sun on 2015/12/1.
 */
public class BalanceAddMoneyDTO {
    //���κ�
    private String batchNo;

    //��������(��ֵ10;����20;����30;�ؿ�40;�50;ϵͳ����60)
    private int type;

    private List<BalanceAddMoneyItem> properties;

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public List<BalanceAddMoneyItem> getProperties() {
        return properties;
    }

    public void setProperties(List<BalanceAddMoneyItem> properties) {
        this.properties = properties;
    }
}
