package com.admin_base.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * ���ڴ���ȯ״̬��װֵ
 * */
public class ActivityOCTConstant {
	
	private  Integer  id;
	private  String   value;
	public ActivityOCTConstant(Integer id, String value) {
		super();
		this.id = id;
		this.value = value;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public   static  List<ComConstant>   getComUtil(){
		 List<ComConstant>  comList=new  ArrayList<>();
		  comList.add(new ComConstant(1, "δʹ��"));
		  comList.add(new ComConstant(2, "ʹ����"));
		  comList.add(new ComConstant(3, "��ʹ��"));
		  return  comList;
	}
}
