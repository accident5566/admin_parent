package com.admin_base.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/***
 * �ӿڽ����Ӧjsonʵ�����װ
 * @author qiupeiwei
 *
 */

@Component("messageResult")
@Scope("prototype")
public class MessageResult {
	private static final Logger log = Logger.getLogger(MessageResult.class);
	// ������
	protected String resultCode = ServiceCode.SUCCESS.getCode();

	/* ������Ϣ���� */
	protected String message = ServiceCode.SUCCESS.getText();

	/* ����ֵ */
	private List<Object> properties = new ArrayList<Object>();

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Object> getProperties() {
		return properties;
	}

	public void setProperties(List<Object> properties) {
		this.properties = properties;
	}

	public void addProperty(Object property) {
		this.properties.add(property);
	}

	public void setMsg(ServiceCode code) {
		this.resultCode = code.getCode();
		this.message = code.getText();
	}

	@JsonIgnore
	public String getAsJSON() {
		String json = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			json = mapper.writeValueAsString(this);

		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	public void setResultMessage(ServiceCode serviceCode) {
		this.setMessage(serviceCode.getText());
		this.setResultCode(serviceCode.getCode());
	}
	
	//TODO ��json�ַ���ת����json����
	private Object getObjectFromJSONStr(Class<?> clazz){
		Object jsonStr = getProperties().get(0);
		JSONObject jsonObject = JSONObject.fromObject(jsonStr);
		System.out.print(JSONObject.toBean(jsonObject, clazz));
		return JSONObject.toBean(jsonObject, clazz);
	}
	
	public Object getDTO(Class<?> clazz) {
		 Object classObject = null;
		try {
			classObject = getObjectFromJSONStr(clazz);
		} catch (Exception e) {
			log.error("����ָ�������ͻ�ȡָ���Ķ�����Ϣʧ��---------ERROR�����ԭ����:"+e.getMessage());
		}
		return classObject;
	}
}
