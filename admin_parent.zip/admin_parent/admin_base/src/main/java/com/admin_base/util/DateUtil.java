package com.admin_base.util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.admin_base.constant.DateConstant;
import com.admin_base.constant.DateFormatConstant;
/***
 * ʱ�丨����
 * @author qiupeiwei
 * @Date 2015-03-12
 */
public class DateUtil {
	/**
	 * ��һ���ƶ�ʱ��ķ�������������
	 * @param nowDate �����ʱ��ֵ
	 * @param subData ����
	 * @return 
	 * @throws ParseException 
	 */
	public static Date dateMinutesSub(Date nowDate,int subData) throws ParseException{
		SimpleDateFormat  sdf = new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS);
		Calendar ca = Calendar.getInstance();
		ca.setTime(nowDate);
		ca.set(Calendar.MINUTE, ca.get(Calendar.MINUTE)-30);
		System.out.println(sdf.format(ca.getTime()));
		sdf.parse(sdf.format(ca.getTime()));
		return ca.getTime();
	}
	
	public static String dateMinutesAdd(Date nowDate,int subData) throws ParseException{
		SimpleDateFormat  sdf = new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS);
		Calendar ca = Calendar.getInstance();
		ca.setTime(nowDate);
		ca.set(Calendar.MINUTE, ca.get(Calendar.MINUTE)+30);
		System.out.println(sdf.format(ca.getTime()));
		return sdf.format(ca.getTime());
	}
	public static Date returnDateTime(String dateTimeStr,String format) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.parse(dateTimeStr);
	}
	public static Date GetDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try	{
			Date formatDate = sdf.parse(sdf.format(date));
			return formatDate;
		} catch(ParseException e) {
			return date;
		}
	}
	public static Date GetDate(Date date,String formatStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatStr);
		try	{
			Date formatDate = sdf.parse(sdf.format(date));
			return formatDate;
		} catch(ParseException e) {
			return date;
		}
	}

	public static String GetStringDate(Date nowDate) throws ParseException{
		SimpleDateFormat  sdf = new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHMS);
		Calendar ca = Calendar.getInstance();
		ca.setTime(nowDate);
		return sdf.format(ca.getTime());
	}
	
	public static Date  GetStringDatePin(Date nowDate,String hm) throws ParseException{
		SimpleDateFormat  sdf = new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMD);
		Calendar ca = Calendar.getInstance();
		ca.setTime(nowDate);
		String dateStr = sdf.format(ca.getTime())+" "+hm;
		SimpleDateFormat  sdf2 = new SimpleDateFormat(DateFormatConstant.MINUTES_FORMAT_YMDHM);
		sdf2.parse(dateStr);
		return sdf2.parse(dateStr);
	}
	public static String GetStringDate(Date nowDate,String formatStr) throws ParseException{
		SimpleDateFormat  sdf = new SimpleDateFormat(formatStr);
		Calendar ca = Calendar.getInstance();
		ca.setTime(nowDate);
//		return sdf.format(ca.getTime()).substring(2);
		return sdf.format(ca.getTime());
	}
	
//	public static void main(String[] args) throws ParseException {
//		System.out.println(GetStringDate(new Date(), DateFormatConstant.MINUTES_FORMAT_YMDHMS));
//	}
	
	public static Long getDatedif(Date date1,Date date2) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Long date3 = (date1.getTime() - date2.getTime()) / 1000 / 3600 / 24 + 1 ;
		return date3;
	}
	public static Long getDatedifs(Date date1,Date date2) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr = sdf.format(date2);
		Date date22 = sdf.parse(dateStr);
		Long date3 = (date1.getTime() - date22.getTime()) / 1000 / 3600 / 24 ;
		return date3;
	}
	public static String GetChineseYMD(Date date) {
		Calendar ca = Calendar.getInstance();
		ca.setTime(date);
		return ca.get(Calendar.YEAR) + "��" + ((ca.get(Calendar.MONTH) + 1) + "") + "��" + ca.get(Calendar.DAY_OF_MONTH) + "��";
	}
	
	public static Date  updateHours(Integer hours){
//		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");    
		Calendar cal = Calendar.getInstance();
		cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) , cal.get(Calendar.DAY_OF_MONTH), hours,0,0);
		return cal.getTime();
	}
	
	public static void main(String[] args) throws ParseException {
	}
	
	
}
