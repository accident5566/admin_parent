package com.admin_base.redis;

import java.util.Map;

import javax.annotation.Resource;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Component;

import com.admin_base.model.Product;
import com.admin_base.util.JedisUtil;

@Component
public class ProductNum {
	
	@Resource
	JedisUtil jedisUtil;
	
	public ProductNum(){
		
	}
	
	public ProductNum(Product product){
		this.totalNum = String.valueOf(product.getWholeNum());
		this.remainingNum = String.valueOf(product.getWholeNum());
		this.purchasedNum = "0";
		this.payingNum = "0";
	}
	
	private String remainingNum;
	
	private String payingNum;
	
	private String totalNum;
	
	private String purchasedNum;

	public String getRemainingNum() {
		return remainingNum;
	}

	public void setRemainingNum(String remainingNum) {
		this.remainingNum = remainingNum;
	}

	public String getPayingNum() {
		return payingNum;
	}

	public void setPayingNum(String payingNum) {
		this.payingNum = payingNum;
	}

	public String getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(String totalNum) {
		this.totalNum = totalNum;
	}

	public String getPurchasedNum() {
		return purchasedNum;
	}

	public void setPurchasedNum(String purchasedNum) {
		this.purchasedNum = purchasedNum;
	}
	
	//��ʼ����Ʒ�ݶ���Ϣ������
	public boolean initProduct(Product product) {
		ProductNum productNum = new ProductNum(product);
		String sign = getSign(product.getProductNo());
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> hash = mapper.convertValue(productNum, Map.class);
		return jedisUtil.initBaseData(sign, hash);
	}
	
	//TODO���ݶ���ͳ�����·ݶ�
	public void initProductNumFromDatabase(String productNo) {
	}
	
	private String getSign(String productNo){
		return "product:" + productNo;
	}
	
	//�ӻ����л�ȡ��Ʒ����
	public ProductNum getProductNum(String productNo) {
		String sign = getSign(productNo);
		Map<String, String> hash = jedisUtil.getObjectHash(sign);
		if (hash.isEmpty()) {
			initProductNumFromDatabase(productNo);
		}
		ObjectMapper mapper = new ObjectMapper();
		ProductNum productNum = mapper.convertValue(hash, ProductNum.class);
		return productNum;
		
		
	}
	
}
