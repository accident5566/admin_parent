package com.admin_base.model;
/***
 * ��Ʒ������Ϣʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.util.StringUtils;

import com.admin_base.util.DateUtil;
import com.admin_base.util.ProductNoGenerateUtil;

public class Product{
	
	/*������ʶid*/
    private Integer id;

    /*��Ʒȫ��(ǰ̨:��Ʒ������+����)*/
    private String fullName;

    /*�����ܽ��*/
    private Integer amount;

    /*��Ʒ����*/
    private Integer unitPrice;

    /*��С�������*/
    private Integer minNum;

    /*��������*/
    private Integer maxNum;

    /*�껪������*/
    private BigDecimal yield;

    /*��ĿͶ������*/
    private Long period;

    /*��Ʒ���*/
    private String productNo;

    /*��Ʒļ��״̬*/
    private Integer raiseStatus;

    /*��Ʒ�����״̬(1.δ��ˣ�2���������)*/
    private Integer checkStatus;

    /*��Ʒ������*/
    private Integer productType;

    /*��Ʒʵ��ļ���ܷ���*/
    private Integer realAmount;

    /*��Ʒ�ܷ���*/
    private Integer wholeNum;
    
    /*��Ʒ����ʱ��*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdAt;

    
    /*��Ʒ�޸�ʱ��*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date updatedAt;

    /*�ж�Э����*/
    private Integer accAgreementNo;

    /*ί��Э����*/
    private Integer conAgreementNo;

    /*��Ϣ��ʽ*/
    private Integer tMode;

    /*��Ʒ����*/
    private Integer productNum;

    /*��Ʒ������(��̨¼��)*/
    private String name;

    /*��Ʒ�ܷ���*/
//    private Integer totalNum;

    /*��Ϣ����*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date payoutDate;

    /*��Ϣ����*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date interestSetDate;

    private String interestSetDateStr;
    
    /*��ٻ�����*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date lastDueDate;

    private String lastDueDateStr;
    
    /*��Ʒ���ۿ�ʼʱ��*/
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date beginTime;

    private String beginTimeStr;
    
    /*��Ʒ���۽���ʱ��*/
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

    private String endTimeStr;
    
    /*��Ʒ�Ķ���������*/
    private BigDecimal extraYield;
    
    /*��Ʒ��identifier*/
    private String productIdentifier;
    
    /*��Ʒ����ʱ��*/
    private Date onlineTime;

    
    private String accNo;//�ж�
    private String conNo;//ί��
    
    private Integer productNums;//����У��ʹ��
    private String productMessage;//��Ʒ��������������Ϣ����
    

	private String feature;//�ص�
	private String borrowType;//�������
	private String purpose;//�ʽ���;
	private String association;//����������
	private String assure;//����
	private String riskControl;//���
    
	private String bankName;
	
	private String bankCard;
	
	private String enterpriseName;
	
	private String province;
	private String city;
	
	public String getProvince() {
		return province;
	}


	public void setProvince(String province) {
		this.province = province;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public Product(String productIdentifier) {
		this.productIdentifier = productIdentifier;
		
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankCard() {
		return bankCard;
	}


	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}


	public String getEnterpriseName() {
		return enterpriseName;
	}


	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}


	public Product getProduct(CAProdcutpackage proPackage) throws ParseException{
		Product product = new Product();
//		product.setAccAgreementNo(proPackage.getEntrustId());//Ͷ��
//		product.setConAgreementNo(proPackage.getPledgeId());//��Ȩί��
		product.setYield(proPackage.getInterestRate());
		product.setAccAgreementNo(35);//Ͷ��
		product.setConAgreementNo(34);//��Ȩί��
		product.setAmount(proPackage.getPackageMoney().intValue());//���ʽ��
		product.setUnitPrice(proPackage.getInvestmentProportion());//��Ʒ����
		product.setProductNo(proPackage.getPackageNo());//��Ʒ���
		product.setRaiseStatus(10);//����
		product.setCheckStatus(2);//�������
		product.setProductType(proPackage.getPackageType());//��Ʒ������
		Integer portion = proPackage.getPackageMoney().divide(new BigDecimal(proPackage.getInvestmentProportion())).intValue();
		product.setWholeNum(portion);//��Ʒ�ܷ���
		product.setCreatedAt(new Date());//��Ʒ�Ĵ���ʱ��
		product.setUpdatedAt(new Date());//��Ʒ���޸�ʱ��
		product.settMode(1);//��Ʒ����Ϣ��ʽ
		product.setProductNum(1);//��Ʒ������
		product.setName(proPackage.getPackageName());//��Ʒ������
		product.setPayoutDate(new Date());//��Ʒ��Ϣ����
		product.setInterestSetDate(new Date());//��Ʒ��Ϣ����
		product.setLastDueDate(new Date());//��ٻ�����
		product.setBeginTime(DateUtil.GetStringDatePin(proPackage.getPackageSendDate(),proPackage.getPackageApplyStartData()));//��Ʒ���ۿ�ʼʱ��
		product.setEndTime(DateUtil.GetStringDatePin(proPackage.getPackageSendDate(),proPackage.getPackageApplyEndData()));//��Ʒ���۽���ʱ��
		product.setExtraYield(new BigDecimal(0));//��Ʒ�Ķ�������
		product.setProductIdentifier("CA1505290118");//��Ʒ��uuid
		product.setLaunchTime(new Date());//������ʱ��
		product.setProductTypeStr(proPackage.getProductType()+",CA001");
		product.setMinNum(1);
		product.setMaxNum(2000000);
		return product;
	}
	
    
    private void setLaunchTime(Date date) {
		// TODO Auto-generated method stub
		
	}


	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public String getBorrowType() {
		return borrowType;
	}

	public void setBorrowType(String borrowType) {
		this.borrowType = borrowType;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getAssociation() {
		return association;
	}

	public void setAssociation(String association) {
		this.association = association;
	}

	public String getAssure() {
		return assure;
	}

	public void setAssure(String assure) {
		this.assure = assure;
	}

	public String getRiskControl() {
		return riskControl;
	}

	public void setRiskControl(String riskControl) {
		this.riskControl = riskControl;
	}

	public String getProductMessage() {
		return productMessage;
	}

	public void setProductMessage(String productMessage) {
		this.productMessage = productMessage;
	}

	private String productTypeStr;//ҳ��ʹ�����Բ���Ӧ���ݿ��ֶ�ֻ����Ϊһ��ֵ�Ĵ���
    
	public Integer getProductNums() {
		return productNums;
	}

	public void setProductNums(Integer productNums) {
		this.productNums = productNums;
	}

	public String getProductTypeStr() {
		return productTypeStr;
	}

	public void setProductTypeStr(String productTypeStr) {
		this.productTypeStr = productTypeStr;
	}

	public String getInterestSetDateStr() {
		return interestSetDateStr;
	}

	public void setInterestSetDateStr(String interestSetDateStr) {
		this.interestSetDateStr = interestSetDateStr;
	}

	public String getLastDueDateStr() {
		return lastDueDateStr;
	}

	public void setLastDueDateStr(String lastDueDateStr) {
		this.lastDueDateStr = lastDueDateStr;
	}

	public String getBeginTimeStr() {
		return beginTimeStr;
	}

	public void setBeginTimeStr(String beginTimeStr) {
		this.beginTimeStr = beginTimeStr;
	}

	public String getEndTimeStr() {
		return endTimeStr;
	}

	public void setEndTimeStr(String endTimeStr) {
		this.endTimeStr = endTimeStr;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getConNo() {
		return conNo;
	}

	public void setConNo(String conNo) {
		this.conNo = conNo;
	}

	public Date getOnlineTime() {
		return onlineTime;
	}

	public void setOnlineTime(Date onlineTime) {
		this.onlineTime = onlineTime;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Integer getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Integer unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Integer getMinNum() {
		return minNum;
	}

	public void setMinNum(Integer minNum) {
		this.minNum = minNum;
	}

	public Integer getMaxNum() {
		return maxNum;
	}

	public void setMaxNum(Integer maxNum) {
		this.maxNum = maxNum;
	}

	public BigDecimal getYield() {
		return yield;
	}

	public void setYield(BigDecimal yield) {
		this.yield = yield;
	}

	

	public Long getPeriod() {
		return period;
	}

	public void setPeriod(Long period) {
		this.period = period;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public Integer getRaiseStatus() {
		return raiseStatus;
	}

	public void setRaiseStatus(Integer raiseStatus) {
		this.raiseStatus = raiseStatus;
	}

	public Integer getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public Integer getRealAmount() {
		return realAmount;
	}

	public void setRealAmount(Integer realAmount) {
		this.realAmount = realAmount;
	}

	public Integer getWholeNum() {
		return wholeNum;
	}

	public void setWholeNum(Integer wholeNum) {
		this.wholeNum = wholeNum;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Integer getAccAgreementNo() {
		return accAgreementNo;
	}

	public void setAccAgreementNo(Integer accAgreementNo) {
		this.accAgreementNo = accAgreementNo;
	}

	public Integer getConAgreementNo() {
		return conAgreementNo;
	}

	public void setConAgreementNo(Integer conAgreementNo) {
		this.conAgreementNo = conAgreementNo;
	}

	public Integer gettMode() {
		return tMode;
	}

	public void settMode(Integer tMode) {
		this.tMode = tMode;
	}

	public Integer getProductNum() {
		return productNum;
	}

	public void setProductNum(Integer productNum) {
		this.productNum = productNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getPayoutDate() {
		return payoutDate;
	}

	public void setPayoutDate(Date payoutDate) {
		this.payoutDate = payoutDate;
	}

	public Date getInterestSetDate() {
		return interestSetDate;
	}

	public void setInterestSetDate(Date interestSetDate) {
		this.interestSetDate = interestSetDate;
	}

	

	public Date getLastDueDate() {
		return lastDueDate;
	}

	public void setLastDueDate(Date lastDueDate) {
		this.lastDueDate = lastDueDate;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public BigDecimal getExtraYield() {
		return extraYield;
	}

	public void setExtraYield(BigDecimal extraYield) {
		this.extraYield = extraYield;
	}

	public Product getProduct(Product product,String productIdentifier) throws ParseException{
		  product.setProductNo(ProductNoGenerateUtil.getProductNo(String.valueOf(product.getProductNo())));
          product.setCheckStatus(1);
		  product.setWholeNum(product.getAmount()/product.getUnitPrice());
		  product.setFullName(product.getName()+"��"+product.getProductNum()+"��");
		  product.setProductIdentifier(productIdentifier);//���uuid��Ψһ�Ի�û����
		  return product;
	}
	
	public Product getProduct(Product product) throws ParseException{
		  product.setWholeNum(product.getAmount()/product.getUnitPrice());
	      product.setPeriod(DateUtil.getDatedif(product.getInterestSetDate(), product.getBeginTime()));
	      product.setProductType(10);
	      product.setFullName(product.getName()+""+product.getProductNum()+"��");
	      product.setUpdatedAt(new Date());
	      return product;
	}
	
	public Product(Integer id, String fullName, Integer amount,
			Integer unitPrice, Integer minNum, Integer maxNum,
			BigDecimal yield, Long period, String productNo,
			Integer raiseStatus, Integer checkStatus, Integer productType,
			Integer realAmount, Integer wholeNum, Date createdAt,
			Date updatedAt, Integer accAgreementNo, Integer conAgreementNo,
			Integer tMode, Integer productNum, String name, Date payoutDate,
			Date interestSetDate, Date lastDueDate, Date beginTime,
			Date endTime, BigDecimal extraYield) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.amount = amount;
		this.unitPrice = unitPrice;
		this.minNum = minNum;
		this.maxNum = maxNum;
		this.yield = yield;
		this.period = period;
		this.productNo = productNo;
		this.raiseStatus = raiseStatus;
		this.checkStatus = checkStatus;
		this.productType = productType;
		this.realAmount = realAmount;
		this.wholeNum = wholeNum;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.accAgreementNo = accAgreementNo;
		this.conAgreementNo = conAgreementNo;
		this.tMode = tMode;
		this.productNum = productNum;
		this.name = name;
		this.payoutDate = payoutDate;
		this.interestSetDate = interestSetDate;
		this.lastDueDate = lastDueDate;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.extraYield = extraYield;
	}

	
	
	public Product(Integer checkStatus, String productIdentifier) {
		this.checkStatus = checkStatus;
		this.productIdentifier = productIdentifier;
	}


	public Product() {
		super();
	}
	public Product getProduct(String productIdentifier){
		Product p = new Product();
		p.setProductIdentifier(productIdentifier);
		p.setRaiseStatus(80);
		return p;
	}
	public Product(String productNo, Integer checkStatus) {
		super();
		this.productNo = productNo;
		this.checkStatus = checkStatus;
	}

	public Product(String productNo, Integer checkStatus,Integer raiseStatus) {
		super();
		this.productNo = productNo;
		this.checkStatus = checkStatus;
		this.raiseStatus = raiseStatus;
	}

	


	public Product(Integer id) {
		super();
		this.id = id;
	}
	

	@Override
	public String toString() {
		return "Product [id=" + id + ", fullName=" + fullName + ", amount="
				+ amount + ", unitPrice=" + unitPrice + ", minNum=" + minNum
				+ ", maxNum=" + maxNum + ", yield=" + yield + ", period="
				+ period + ", productNo=" + productNo + ", raiseStatus="
				+ raiseStatus + ", checkStatus=" + checkStatus
				+ ", productType=" + productType + ", realAmount=" + realAmount
				+ ", wholeNum=" + wholeNum + ", createdAt=" + createdAt
				+ ", updatedAt=" + updatedAt + ", accAgreementNo="
				+ accAgreementNo + ", conAgreementNo=" + conAgreementNo
				+ ", tMode=" + tMode + ", productNum=" + productNum + ", name="
				+ name + ", payoutDate=" + payoutDate + ", interestSetDate="
				+ interestSetDate + ", lastDueDate=" + lastDueDate
				+ ", beginTime=" + beginTime + ", endTime=" + endTime
				+ ", extraYield=" + extraYield + ", productIdentifier="
				+ productIdentifier + ", onlineTime=" + onlineTime + "]";
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

    /*��Ŀ����*/
//    private Integer projectDeadline;

	public static boolean  checkBlank(Product p){
		
		
		if(StringUtils.isEmpty(p)){  
		    return false;	
		}
		if(StringUtils.isEmpty(p.getBankName())){
			return false;
		}
		if(StringUtils.isEmpty(p.getBankCard())){
			return false;
		}
		if(StringUtils.isEmpty(p.getProvince())){
			return false;
		}
		if(StringUtils.isEmpty(p.getCity())){
			return false;
		}
		return true;
	}
}