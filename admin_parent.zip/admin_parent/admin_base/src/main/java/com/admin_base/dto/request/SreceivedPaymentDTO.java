package com.admin_base.dto.request;

public class SreceivedPaymentDTO {

	/*��Ʒ��uuid*/
	private String productIdentifier;
	
	/*֧����Դ*/
	private Integer payFrom;

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	

	public Integer getPayFrom() {
		return payFrom;
	}

	public void setPayFrom(Integer payFrom) {
		this.payFrom = payFrom;
	}

	public SreceivedPaymentDTO(String productIdentifier, Integer payFrom) {
		this.productIdentifier = productIdentifier;
		this.payFrom = payFrom;
	}

	public SreceivedPaymentDTO() {
	}
	
	
}
