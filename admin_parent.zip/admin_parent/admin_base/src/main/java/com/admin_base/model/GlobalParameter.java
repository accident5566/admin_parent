package com.admin_base.model;

import java.util.Date;

/**
 * ȫ�ֲ���ʵ������Ϣ
 * @author peiwei
 * @Date 2015-11-23
 */
public class GlobalParameter {

	//��ʶid
	private Integer id;
	//��������
	private String parameterKey;
	//��ֵ
	private String parameterValue;
	//��������
	private String remark;
	//����ʱ��
	private Date createAt;
	//�޸�ʱ��
	private Date updateAt;
	
	public GlobalParameter(String  parameterKey){
		this.parameterKey =  parameterKey;
	}
	public GlobalParameter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GlobalParameter(Integer id, String parameterKey,
			String parameterValue, String remark, Date createAt, Date updateAt) {
		super();
		this.id = id;
		this.parameterKey = parameterKey;
		this.parameterValue = parameterValue;
		this.remark = remark;
		this.createAt = createAt;
		this.updateAt = updateAt;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getParameterKey() {
		return parameterKey;
	}
	public void setParameterKey(String parameterKey) {
		this.parameterKey = parameterKey;
	}
	public String getParameterValue() {
		return parameterValue;
	}
	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	public Date getUpdateAt() {
		return updateAt;
	}
	public void setUpdateAt(Date updateAt) {
		this.updateAt = updateAt;
	}
	
}
