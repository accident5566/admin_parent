package com.admin_base.dto.yl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;

import org.codehaus.jackson.map.ObjectMapper;

import com.admin_base.constant.ProductContent;
import com.admin_base.dto.request.EnPayMoneyDTO;
import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.util.ProductNoGenerateUtil;
/***
 * �����ӿڵ���json����
 * @author qiupeiwei
 * @Date 2015-03-18
 */
@SuppressWarnings("serial")
public class CommonMsg implements Serializable{
    private String userUuid = "";
    private String sn = "";
    private String accNo = "";
    private String accName = "";
    private String accProvince = "";
    private String accCity = "";
    private BigDecimal  amount = new BigDecimal(1);
    private String payState = "";
    private String bankName = "";
    private String accType = "";
    private String accProp = "";//������0���߲�����ҵ��1
    private String idType = "";
    private String idNo = "";
    private String cny = "CNY";
    private String mobileNo = "";
    private String remark = "";
    private String merOrderNo = "";
    private String transDesc = "";
    private String merchantUrl = "";
    private String queryNoFlag = "";
    private String smsCode = "";
    
	public String getQueryNoFlag() {
		return queryNoFlag;
	}
	public void setQueryNoFlag(String queryNoFlag) {
		this.queryNoFlag = queryNoFlag;
	}
	public String getSmsCode() {
		return smsCode;
	}
	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}
	public String getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getAccProvince() {
		return accProvince;
	}
	public void setAccProvince(String accProvince) {
		this.accProvince = accProvince;
	}
	public String getAccCity() {
		return accCity;
	}
	public void setAccCity(String accCity) {
		this.accCity = accCity;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getPayState() {
		return payState;
	}
	public void setPayState(String payState) {
		this.payState = payState;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccProp() {
		return accProp;
	}
	public void setAccProp(String accProp) {
		this.accProp = accProp;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getCny() {
		return cny;
	}
	public void setCny(String cny) {
		this.cny = cny;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMerOrderNo() {
		return merOrderNo;
	}
	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
	public String getMerchantUrl() {
		return merchantUrl;
	}
	public void setMerchantUrl(String merchantUrl) {
		this.merchantUrl = merchantUrl;
	}
	
	public String toJson() throws Exception{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(this);
	}
	
	public CommonMsg(String userUuid, String sn, String accNo, String accName,
			String accProvince, String accCity, BigDecimal amount,
			String payState, String bankName, String accType, String accProp,
			String idType, String idNo, String cny, String mobileNo,
			String remark, String merOrderNo, String transDesc,
			String merchantUrl,String queryNoFlag,String smsCode) {
		super();
		this.userUuid = userUuid;
		this.sn = sn;
		this.accNo = accNo;
		this.accName = accName;
		this.accProvince = accProvince;
		this.accCity = accCity;
		this.amount = amount;
		this.payState = payState;
		this.bankName = bankName;
		this.accType = accType;
		this.accProp = accProp;
		this.idType = idType;
		this.idNo = idNo;
		this.cny = cny;
		this.mobileNo = mobileNo;
		this.remark = remark;
		this.merOrderNo = merOrderNo;
		this.transDesc = transDesc;
		this.merchantUrl = merchantUrl;
		this.queryNoFlag = queryNoFlag;
		this.smsCode = smsCode;
	}
	public CommonMsg() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CommonMsg(OrderDetailDTOResult order){
		String province = null;
		String city = null;
		if(!order.getCity().contains("|")){
			 province =  order.getCity();
			 city =  order.getCity();
		}else{
			int caharIndex = order.getCity().indexOf("|");
			province =  order.getCity().substring(0, caharIndex);
			city =  order.getCity().substring(caharIndex+1);
		}
		this.accType = "00";
		this.accProp = "0";
		this.sn = order.getOrderNo();
		this.accNo = order.getBankCardNo();
		this.accName = order.getRealName();
		this.amount = order.getPaymentAmount();
		this.bankName = order.getBankName();
		this.mobileNo = order.getCellphone();
		this.idNo = order.getCredentialNo();
		this.idType = "0";
		this.merOrderNo = order.getProductNo();
		this.userUuid = order.getUuid();
		this.accProvince = province;
		this.accCity = city;
		this.merchantUrl = "";
	}
	
	public CommonMsg(EnPayMoneyDTO enPayMoneydtol) throws ParseException{
		this.accType = "00";
		this.sn = ProductNoGenerateUtil.getBatchNo("P");
		this.accProp = "1";
		this.accNo = enPayMoneydtol.getBankCard();
		this.accName = enPayMoneydtol.getEnterpriseName();
		this.amount = enPayMoneydtol.getTotalSuccessOrderMoney();
		this.bankName = enPayMoneydtol.getBankName();
		this.mobileNo = "1300000000";
		this.idNo ="";
		this.idType = "0";
		this.merOrderNo = enPayMoneydtol.getProductNo();
		this.userUuid = String.valueOf(enPayMoneydtol.getId());
		this.accProvince = enPayMoneydtol.getProvince();
		this.accCity = enPayMoneydtol.getCity();
		this.merchantUrl = "";
	}
	public static void main(String[] args) {
		String address = "�Ϻ�a|�Ϻ�b";
		int addr = address.indexOf("|");
	    System.out.println(address.substring(addr+1));
	}
}

