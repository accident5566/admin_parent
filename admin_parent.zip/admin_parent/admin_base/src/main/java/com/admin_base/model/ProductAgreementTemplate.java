package com.admin_base.model;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
/***
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class ProductAgreementTemplate {
	
    private Integer id;
    
    private Integer agreementtype;
    
    private Integer agreementStatus;

    private Date createdat;

    private Date updatedat;

    private String agreementcontent;

    private String agreementName;

    
    


	public ProductAgreementTemplate(Integer id) {
		super();
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAgreementtype() {
		return agreementtype;
	}

	public void setAgreementtype(Integer agreementtype) {
		this.agreementtype = agreementtype;
	}

	
	public Date getCreatedat() {
		return createdat;
	}

	public void setCreatedat(Date createdat) {
		this.createdat = createdat;
	}

	public Date getUpdatedat() {
		return updatedat;
	}

	public void setUpdatedat(Date updatedat) {
		this.updatedat = updatedat;
	}

	public String getAgreementcontent() {
		return agreementcontent;
	}

	public void setAgreementcontent(String agreementcontent) {
		this.agreementcontent = agreementcontent;
	}

	public Integer getAgreementStatus() {
		return agreementStatus;
	}

	public void setAgreementStatus(Integer agreementStatus) {
		this.agreementStatus = agreementStatus;
	}

	public String getAgreementName() {
		return agreementName;
	}

	public void setAgreementName(String agreementName) {
		this.agreementName = agreementName;
	}

	public ProductAgreementTemplate(Integer id, Integer agreementtype,
			Integer agreementStatus, Date createdat, Date updatedat,
			String agreementcontent, String agreementName) {
		super();
		this.id = id;
		this.agreementtype = agreementtype;
		this.agreementStatus = agreementStatus;
		this.createdat = createdat;
		this.updatedat = updatedat;
		this.agreementcontent = agreementcontent;
		this.agreementName = agreementName;
	}

	public ProductAgreementTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ProductAgreementTemplate [id=" + id + ", agreementtype="
				+ agreementtype + ", agreementStatus=" + agreementStatus + ", createdat="
				+ createdat + ", updatedat=" + updatedat
				+ ", agreementcontent=" + agreementcontent + ", agreementName="
				+ agreementName + "]";
	}
    
    
   
    
    
}