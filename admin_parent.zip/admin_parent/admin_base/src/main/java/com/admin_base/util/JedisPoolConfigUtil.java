package com.admin_base.util;

import redis.clients.jedis.JedisPoolConfig;

public class JedisPoolConfigUtil extends JedisPoolConfig {
//	public JedisPoolConfigUtil() {
//		//defaults config
//	    setTestWhileIdle(true);
//	    setMinEvictableIdleTimeMillis(60000);
//	    setTimeBetweenEvictionRunsMillis(30000);
//	    setNumTestsPerEvictionRun(-1);
//	}
	

}
