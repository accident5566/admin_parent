package com.admin_base.model;

import java.math.BigDecimal;
import java.util.Date;

import com.admin_base.dto.request.EnPayMoneyDTO;

/***
 * ��ҵ���ʵ����
 * @author qiupeiwei
 * @date 2015-06-09
 */
public class EnterprisePayMoneyRecords {

	/*��ʶid*/
	private Integer id;
	
	/*�����Ĳ�Ʒ���*/
	private String productIdentifier;
	
	/*��ҵ�˻�����*/
	private String enterpriseName;
	
	/*������*/
	private String bankName;
	
	/*����*/
	private String bankCard;
	
	/*�����*/
	private BigDecimal payMoney;
	
	/*�����Դ*/
	private Integer payFrom;
	
	/*�����*/
	private String payResult;
	
	/*���ʱ��*/
	private Date payCreateTime;
	
	/*���ʱ��*/
	private Date resultTime;

	/*���κ�*/
	private String batchNo;
	
	private String productNo;//��Ʒ�ı��(ҳ��չʾʹ��)

	private Integer payStatus;//��ҵ���״̬
	
    private Integer characteristic;
    
	public Integer getCharacteristic() {
		return characteristic;
	}

	public void setCharacteristic(Integer characteristic) {
		this.characteristic = characteristic;
	}

	public Integer getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	public EnterprisePayMoneyRecords(String productIdentifier, Integer payFrom,
			String payResult) {
		this.productIdentifier = productIdentifier;
		this.payFrom = payFrom;
		this.payResult = payResult;
		this.resultTime = new Date();
	}

	public String getBatchNo() {
		return batchNo;
	}


	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}


	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCard() {
		return bankCard;
	}

	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}

	public BigDecimal getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(BigDecimal payMoney) {
		this.payMoney = payMoney;
	}

	public Integer getPayFrom() {
		return payFrom;
	}

	public void setPayFrom(Integer payFrom) {
		this.payFrom = payFrom;
	}

	public String getPayResult() {
		return payResult;
	}

	public void setPayResult(String payResult) {
		this.payResult = payResult;
	}

	public Date getPayCreateTime() {
		return payCreateTime;
	}

	public void setPayCreateTime(Date payCreateTime) {
		this.payCreateTime = payCreateTime;
	}

	public Date getResultTime() {
		return resultTime;
	}

	public void setResultTime(Date resultTime) {
		this.resultTime = resultTime;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public EnterprisePayMoneyRecords(String productIdentifier, Integer payFrom) {
		this.productIdentifier = productIdentifier;
		this.payFrom = payFrom;
	}

	public EnterprisePayMoneyRecords(Integer id, String productIdentifier,
			String enterpriseName, String bankName, String bankCard,
			BigDecimal payMoney, Integer payFrom, String payResult,
			Date payCreateTime, Date resultTime) {
		super();
		this.id = id;
		this.productIdentifier = productIdentifier;
		this.enterpriseName = enterpriseName;
		this.bankName = bankName;
		this.bankCard = bankCard;
		this.payMoney = payMoney;
		this.payFrom = payFrom;
		this.payResult = payResult;
		this.payCreateTime = payCreateTime;
		this.resultTime = resultTime;
	}

	
	public EnterprisePayMoneyRecords(String productIdentifier, Integer payFrom,
			String batchNo, Integer payStatus, Integer characteristic,String payResult) {
		this.productIdentifier = productIdentifier;
		this.payFrom = payFrom;
		this.batchNo = batchNo;
		this.payStatus = payStatus;
		this.characteristic = characteristic;
		this.payResult = payResult;
	}

	public EnterprisePayMoneyRecords() {
	}
	public EnterprisePayMoneyRecords(EnPayMoneyDTO enPayMoneyDTO){
		this.bankCard = enPayMoneyDTO.getBankCard();
		this.bankName = enPayMoneyDTO.getBankName();
		this.enterpriseName = enPayMoneyDTO.getEnterpriseName();
		this.productIdentifier = enPayMoneyDTO.getProductIdentifier();
		this.payMoney = enPayMoneyDTO.getTotalSuccessOrderMoney();
        this.payCreateTime = new Date();
        this.batchNo = enPayMoneyDTO.getBatchNo();
        this.payStatus = enPayMoneyDTO.getPayStatus();
        this.payFrom = enPayMoneyDTO.getPaySource();
	}
}
