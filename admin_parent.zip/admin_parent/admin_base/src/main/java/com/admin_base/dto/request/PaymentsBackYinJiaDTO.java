package com.admin_base.dto.request;

import java.math.BigDecimal;

import com.admin_base.dto.response.OrderDetailDTOResult;

public class PaymentsBackYinJiaDTO {

	private String mobile;
	private BigDecimal amount;
	private String logno;
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getLogno() {
		return logno;
	}
	public void setLogno(String logno) {
		this.logno = logno;
	}
	public PaymentsBackYinJiaDTO(OrderDetailDTOResult order){
		this.mobile = order.getCellphone();
		this.amount = order.getPaymentAmount();
		this.logno = order.getOrderNo();
	}
	public PaymentsBackYinJiaDTO(String mobile, BigDecimal amount, String logno) {
		this.mobile = mobile;
		this.amount = amount;
		this.logno = logno;
	}
	public PaymentsBackYinJiaDTO() {
	}
	
}
