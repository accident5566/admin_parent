package com.admin_base.util;

/***
 * ����ö�����Ͳ�����ȡ��Ӧ��ֵ
 * 
 * @author qiupeiwei
 * @Date 2015-03-11
 */
public class VeriCodeNum {

	public static Integer ToCodeType(VeriCode.VeriCodeType vericodeType) {
		Integer codetype = 0;
		switch (vericodeType) {
		case SignUp:
			codetype = 2;
			break;
		case ResetLoginPassword:
			codetype = 3;
			break;
		case ResetPaymentPassword:
			codetype = 4;
			break;
		case VeriImage:
			codetype = 1;
			break;
		}
		return codetype;
	}
}
