package com.admin_base.model;
import java.util.Date;
/***
 * ��֤��ʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class Vericodes{
	private static final long serialVersionUID = 1L;

	/*������ʶid*/
    private Integer id;

    /*UUID*/
    private String identifier;

    /*�ֻ�����*/
    private String cellphone;

    /*��֤��*/
    private String code;

    /*��֤����*/
    private Integer type;

    /*�Ƿ�����֤*/
    private Integer verified;

    /*�Ƿ���ʹ��*/
    private Integer used;

    /*�������*/
    private Integer errorcount;

    /*�ۼ�ʹ�ô���(һ��֮��)*/
    private Integer times;

    /*����ʱ��*/
    private Date buildat;

    /*�ƶ��豸ID*/
    private String clientid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier == null ? null : identifier.trim();
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone == null ? null : cellphone.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim().toLowerCase();
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getVerified() {
        return verified;
    }

    public void setVerified(Integer verified) {
        this.verified = verified;
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }

    public Integer getErrorcount() {
        return errorcount;
    }

    public void setErrorcount(Integer errorcount) {
        this.errorcount = errorcount;
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

    public Date getBuildat() {
        return buildat;
    }

    public void setBuildat(Date buildat) {
        this.buildat = buildat;
    }

    public String getClientid() {
        return clientid;
    }

    
    public Vericodes(String identifier,Integer type,
			Date buildat) {
		super();
		this.identifier = identifier;
		this.type = type;
		this.buildat = buildat;
	}
    
    public Vericodes(String identifier,Integer type,String cellphone,Date buildat) {
		super();
		this.identifier = identifier;
		this.type = type;
		this.cellphone = cellphone;
		this.buildat = buildat;
	}
    
    public Vericodes(Integer type,String cellphone,Date buildat) {
		super();
		this.type = type;
		this.cellphone = cellphone;
		this.buildat = buildat;
	}

	public void setClientid(String clientid) {
        this.clientid = clientid == null ? null : clientid.trim();
    }

	public Vericodes(Integer id, String identifier, String cellphone,
			String code, Integer type, Integer verified, Integer used,
			Integer errorcount, Integer times, Date buildat, String clientid) {
		super();
		this.id = id;
		this.identifier = identifier;
		this.cellphone = cellphone;
		this.code = code;
		this.type = type;
		this.verified = verified;
		this.used = used;
		this.errorcount = errorcount;
		this.times = times;
		this.buildat = buildat;
		this.clientid = clientid;
	}

	public Vericodes() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Vericodes [id=" + id + ", identifier=" + identifier
				+ ", cellphone=" + cellphone + ", code=" + code + ", type="
				+ type + ", verified=" + verified + ", used=" + used
				+ ", errorcount=" + errorcount + ", times=" + times
				+ ", buildat=" + buildat + ", clientid=" + clientid + "]";
	}

	public Vericodes(String code, Integer type) {
		super();
		this.code = code;
		this.type = type;
	}


}