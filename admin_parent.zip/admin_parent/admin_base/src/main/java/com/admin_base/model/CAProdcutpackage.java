package com.admin_base.model;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import com.admin_base.constant.ProductContent;
import com.admin_base.util.DateUtil;
import com.admin_base.util.ProductNoGenerateUtil;

/***
 * ����ʵ����
 * @author qiupeiwei
 * @date 2015-05-26
 */
public class CAProdcutpackage {
	//������ʶid����
	 private Integer packageId;
	 //��Ŀ���ı��
	 private String packageNo;
	//��������
	 @DateTimeFormat(pattern="yyyy-MM-dd")
	 @NotNull(message="�������ڲ���Ϊ��")
	 private Date packageSendDate;
	 //���뿪ʼ����
	 @NotEmpty(message = "���뿪ʼ���ڲ���Ϊ��") 
	 private String  packageApplyStartData;
    //�����ֹʱ��
	 @NotEmpty(message = "�������ʱ�䲻��Ϊ��") 
	 private String packageApplyEndData;
	 //Ͷ�ʷݶ����
	 @Min(value=0,message="Ͷ�ʷݶ��������С��0")
	 @NotNull(message="Ͷ�ʷݶ��������Ϊ��")
	 private Integer investmentProportion;
	 //������Ŀ�����
	 @Min(value=1,message="��Ŀ������С��0")
	 @NotNull(message="��Ŀ������Ϊ��")
	 private BigDecimal packageMoney;
	 //�껯������
	 @Range(min=1,max=100,message="�껯������1��100֮��") 
	 @NotNull(message="�껯���治��Ϊ��")
	 private BigDecimal interestRate;
	 //��Ŀ�����״̬(3.����ˡ�2.δͨ����1.���������״̬)
	 private Integer  packageStatus;
	 //����ͬ��״̬ 0.δͬ����1.��ͬ��,2.��ѯǰ̨������ͼ�쳣,3.��ѯ����������Ϣ�쳣,4.�����쳣5.���ʽ���붩���ܽ�һ��',
	 private String syncFlag;
	 //����״̬(0.δ����,1.�����쳣,2.����ͨ��)
	 private String accCheckFlag;
	 //��Ʒ����(10.�̶�����;20.����)
	 private Integer productType;
	 //������(1.Ԥ��������2.�������3.���߰�)
	 private Integer packageType;
	 //��Ŀ������
	 private String packageName;
	 //������ʱ��
	 private Date createTime;
	 //��Ȩί����
	 private Integer pledgeId;
	 //Ͷ��Э��
	 private Integer entrustId;
	 //�������ֽ��
	 private BigDecimal tomWithdraw;
	 
	 private String dateValue;//ҳ�����뿪ʼʱ��ͽ���ʱ��ʹ��
	 private String dateText;//ҳ�����뿪ʼʱ��ͽ���ʱ��ʹ��
	 
	 private Integer raiseStatus;//��Ʒ��ļ��״̬
	 private Date packageSendStartDate;//������ʼʱ��(����ʹ�ò��ͱ���Ӧ)
	 private Date packageSendEndDate;//��������ʱ��(����ʹ�ò��ͱ���Ӧ)
	 public static List<CAProdcutpackage> getCAPrPackList(List<CAProdcutpackage> caList) throws ParseException{
		 for(CAProdcutpackage ca : caList){
				ca.setPackageSendStartDate(DateUtil.GetStringDatePin(ca.getPackageSendDate(),ca.getPackageApplyStartData()));
				ca.setPackageSendEndDate(DateUtil.GetStringDatePin(ca.getPackageSendDate(),ca.getPackageApplyStartData()));
			}
		 return caList;
	 }
	 public Integer getRaiseStatus() {
		return raiseStatus;
	}

	public void setRaiseStatus(Integer raiseStatus) {
		this.raiseStatus = raiseStatus;
	}

	public Date getPackageSendStartDate() {
		return packageSendStartDate;
	 }
	 public void setPackageSendStartDate(Date packageSendStartDate) {
		this.packageSendStartDate = packageSendStartDate;
	 }
	public Date getPackageSendEndDate() {
		return packageSendEndDate;
	}
	public void setPackageSendEndDate(Date packageSendEndDate) {
		this.packageSendEndDate = packageSendEndDate;
	}
	public CAProdcutpackage(String packageNo, Integer packageStatus) {
		this.packageNo = packageNo;
		this.packageStatus = packageStatus;
	}
	public CAProdcutpackage(String packageNo) {
		this.packageNo = packageNo;
	}
	public static CAProdcutpackage getcaProductpackage(CAProdcutpackage propaclage) throws ParseException{
		propaclage.setPackageNo(ProductNoGenerateUtil.getProductNo("CA"));
		propaclage.setCreateTime(new Date());
		propaclage.setPackageStatus(1);
		propaclage.setPackageName(ProductContent.PACKAGE_NAME);
		propaclage.setProductType(20);
		return propaclage;
	}
	public String getDateValue() {
		return dateValue;
	}
	public void setDateValue(String dateValue) {
		this.dateValue = dateValue;
	}
	public String getDateText() {
		return dateText;
	}
	public void setDateText(String dateText) {
		this.dateText = dateText;
	}
	public Integer getPackageId() {
		return packageId;
	}
	public void setPackageId(Integer packageId) {
		this.packageId = packageId;
	}
	public String getPackageNo() {
		return packageNo;
	}
	public void setPackageNo(String packageNo) {
		this.packageNo = packageNo;
	}
	public Date getPackageSendDate() {
		return packageSendDate;
	}
	public void setPackageSendDate(Date packageSendDate) {
		this.packageSendDate = packageSendDate;
	}
	
	
	public String getPackageApplyStartData() {
		return packageApplyStartData;
	}
	public void setPackageApplyStartData(String packageApplyStartData) {
		this.packageApplyStartData = packageApplyStartData;
	}
	public String getPackageApplyEndData() {
		return packageApplyEndData;
	}
	public void setPackageApplyEndData(String packageApplyEndData) {
		this.packageApplyEndData = packageApplyEndData;
	}
	public Integer getInvestmentProportion() {
		return investmentProportion;
	}
	public void setInvestmentProportion(Integer investmentProportion) {
		this.investmentProportion = investmentProportion;
	}
	public BigDecimal getPackageMoney() {
		return packageMoney;
	}
	public void setPackageMoney(BigDecimal packageMoney) {
		this.packageMoney = packageMoney;
	}
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public Integer getPackageStatus() {
		return packageStatus;
	}
	public void setPackageStatus(Integer packageStatus) {
		this.packageStatus = packageStatus;
	}
	public String getSyncFlag() {
		return syncFlag;
	}
	public void setSyncFlag(String syncFlag) {
		this.syncFlag = syncFlag;
	}
	public String getAccCheckFlag() {
		return accCheckFlag;
	}
	public void setAccCheckFlag(String accCheckFlag) {
		this.accCheckFlag = accCheckFlag;
	}
	public Integer getProductType() {
		return productType;
	}
	public void setProductType(Integer productType) {
		this.productType = productType;
	}
	public Integer getPackageType() {
		return packageType;
	}
	public void setPackageType(Integer packageType) {
		this.packageType = packageType;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getPledgeId() {
		return pledgeId;
	}
	public void setPledgeId(Integer pledgeId) {
		this.pledgeId = pledgeId;
	}
	public Integer getEntrustId() {
		return entrustId;
	}
	public void setEntrustId(Integer entrustId) {
		this.entrustId = entrustId;
	}
	public BigDecimal getTomWithdraw() {
		return tomWithdraw;
	}
	public void setTomWithdraw(BigDecimal tomWithdraw) {
		this.tomWithdraw = tomWithdraw;
	}
	
	public CAProdcutpackage(String dateValue, String dateText) {
		super();
		this.dateValue = dateValue;
		this.dateText = dateText;
	}
	public  static List<CAProdcutpackage> getdateList(){
		List<CAProdcutpackage> caList = new ArrayList<CAProdcutpackage>();
		caList.add(new CAProdcutpackage("01:00","01:00"));
		caList.add(new CAProdcutpackage("02:00","02:00"));
		caList.add(new CAProdcutpackage("03:00","03:00"));
		caList.add(new CAProdcutpackage("04:00","04:00"));
		caList.add(new CAProdcutpackage("05:00","05:00"));
		caList.add(new CAProdcutpackage("06:00","06:00"));
		caList.add(new CAProdcutpackage("07:00","07:00"));
		caList.add(new CAProdcutpackage("08:00","08:00"));
		caList.add(new CAProdcutpackage("09:00","09:00"));
		caList.add(new CAProdcutpackage("10:00","10:00"));
		caList.add(new CAProdcutpackage("11:00","11:00"));
		caList.add(new CAProdcutpackage("12:00","12:00"));
		caList.add(new CAProdcutpackage("13:00","13:00"));
		caList.add(new CAProdcutpackage("14:00","14:00"));
		caList.add(new CAProdcutpackage("15:00","15:00"));
		caList.add(new CAProdcutpackage("16:00","16:00"));
		caList.add(new CAProdcutpackage("17:00","17:00"));
		caList.add(new CAProdcutpackage("18:00","18:00"));
		caList.add(new CAProdcutpackage("19:00","19:00"));
		caList.add(new CAProdcutpackage("20:00","20:00"));
		caList.add(new CAProdcutpackage("21:00","21:00"));
		caList.add(new CAProdcutpackage("22:00","22:00"));
		caList.add(new CAProdcutpackage("23:00","23:00"));
		caList.add(new CAProdcutpackage("00:00","00:00"));
		return caList;
	}
	public CAProdcutpackage(Integer packageId, String packageNo,
			Date packageSendDate, String packageApplyStartData,
			String packageApplyEndData, Integer investmentProportion,
			BigDecimal packageMoney, BigDecimal interestRate,
			Integer packageStatus, String syncFlag, String accCheckFlag,
			Integer productType, Integer packageType, String packageName,
			Date createTime, Integer pledgeId, Integer entrustId,
			BigDecimal tomWithdraw) {
		super();
		this.packageId = packageId;
		this.packageNo = packageNo;
		this.packageSendDate = packageSendDate;
		this.packageApplyStartData = packageApplyStartData;
		this.packageApplyEndData = packageApplyEndData;
		this.investmentProportion = investmentProportion;
		this.packageMoney = packageMoney;
		this.interestRate = interestRate;
		this.packageStatus = packageStatus;
		this.syncFlag = syncFlag;
		this.accCheckFlag = accCheckFlag;
		this.productType = productType;
		this.packageType = packageType;
		this.packageName = packageName;
		this.createTime = createTime;
		this.pledgeId = pledgeId;
		this.entrustId = entrustId;
		this.tomWithdraw = tomWithdraw;
	}
	public CAProdcutpackage() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CAProdcutpackage [packageId=" + packageId + ", packageNo="
				+ packageNo + ", packageSendDate=" + packageSendDate
				+ ", packageApplyStartData=" + packageApplyStartData
				+ ", packageApplyEndData=" + packageApplyEndData
				+ ", investmentProportion=" + investmentProportion
				+ ", packageMoney=" + packageMoney + ", interestRate="
				+ interestRate + ", packageStatus=" + packageStatus
				+ ", syncFlag=" + syncFlag + ", accCheckFlag=" + accCheckFlag
				+ ", productType=" + productType + ", packageType="
				+ packageType + ", packageName=" + packageName
				+ ", createTime=" + createTime + ", pledgeId=" + pledgeId
				+ ", entrustId=" + entrustId + ", tomWithdraw=" + tomWithdraw
				+ "]";
	}
}
