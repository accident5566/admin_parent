package com.admin_base.util;

import java.io.Serializable;

import org.codehaus.jackson.map.ObjectMapper;

/***
 * 
 * @author qiupeiwei
 * @Date 2015-03-12
 */

@SuppressWarnings("serial")
public class CommonMsg implements Serializable {
	
	public String toJson() throws Exception{
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(this);
	}

	public CommonMsg() {
		super();
	}
	
}
