package com.admin_base.util;

import java.util.UUID;
/***
 * java uuid ���� Ψһ��ʶ
 * @author qiupeiwei
 * @Date 2015-03-11
 */
public class UUIDGenerator {
	
	public UUIDGenerator() {
	
	}
	
	public static String getUUID() {
		UUID uuid = UUID.randomUUID();
		String str = uuid.toString();
		return str.replace("-", "");
	}
	public static void main(String[] args) {
		System.out.println(getUUID());
	}
}