package com.admin_base.model;

import java.math.BigDecimal;

public class WithdrawConfirm {

	/*���ֽ��*/
	private BigDecimal amount;
	
	/*�û�uuid*/
	private String userIdentifier;
	
	/*�û���*/
	private String userName;
	
	/*�ֻ�����*/
	private String cellphone;
	
	/*������*/
	private String orderNo;
	
	/*���п���*/
	private String cardNo;
	
	/*���п�����*/
	private String bankName;
	
	/*����֤*/
	private String idCard;
	
	/*������*/
	private BigDecimal fee;
	
	/*����״̬*/
	private Integer checkStatus;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public Integer getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}
	
	
}
