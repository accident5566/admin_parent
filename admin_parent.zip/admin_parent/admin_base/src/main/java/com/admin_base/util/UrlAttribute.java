package com.admin_base.util;

import java.util.HashMap;
import java.util.Iterator;

public class UrlAttribute {
	
	public  static String getUrl(HashMap<String,String> parms){
		if(parms !=null){
			Iterator<String> it = parms.keySet().iterator();
			StringBuffer sb = null;
			while(it.hasNext()){
				String parmKey = it.next();
				String parmValue = parms.get(parmKey);
				if(sb == null){
					sb = new StringBuffer();
				}else{
					sb.append("&");
				}
				sb.append(parmKey);
				sb.append("=");
				sb.append(parmValue);
			}	
			    return sb.toString();
			}
		        return null;	   
		}	
}
