package com.admin_base.message.dto;


public class SreceivedPaymentsDTO  extends BaseDTO{

	/*��Ʒ���*/
	private String productIdentitier;

	public String getProductIdentitier() {
		return productIdentitier;
	}

	public void setProductIdentitier(String productIdentitier) {
		this.productIdentitier = productIdentitier;
	}

	public SreceivedPaymentsDTO(String type, String phone,
			String productIdentitier) {
		super(type, phone);
		this.productIdentitier = productIdentitier;
	}

	public SreceivedPaymentsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SreceivedPaymentsDTO(String type, String phone) {
		super(type, phone);
	}

	public SreceivedPaymentsDTO(String productIdentitier) {
		this.productIdentitier = productIdentitier;
	}
	
	
}
