package com.admin_base.model;

import java.math.BigDecimal;
import java.util.Date;

/***
 * ����˻�ϵͳ_�û��˻���Ϣʵ��
 * @author guxiaojun
 * @Date 2015-11-18
 */
public class BalanceAmount {
	
	/*��ʶid*/
	private Integer id;
	
	/*�û�UUID*/
	private String userIdentifier;
	
	/*�û�����*/
	private String realName;
	
	/*�û���ϵ��ʽ*/
	private String cellphone;
	
	/*�������*/
	private BigDecimal availableAmount;
	
	/*������*/
	private BigDecimal freezeAmount;
	
	/*����ʱ��*/
	private Date updatedAt;
	
	/*���ձ���*/
	private BigDecimal dueInAmount;
	
	/*��������*/
	private BigDecimal dueInIncome;
	
	/*�ۼ�����*/
	private BigDecimal accumulatedIncome;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public BigDecimal getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(BigDecimal availableAmount) {
		this.availableAmount = availableAmount;
	}

	public BigDecimal getFreezeAmount() {
		return freezeAmount;
	}

	public void setFreezeAmount(BigDecimal freezeAmount) {
		this.freezeAmount = freezeAmount;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public BigDecimal getDueInAmount() {
		return dueInAmount;
	}

	public void setDueInAmount(BigDecimal dueInAmount) {
		this.dueInAmount = dueInAmount;
	}

	public BigDecimal getDueInIncome() {
		return dueInIncome;
	}

	public void setDueInIncome(BigDecimal dueInIncome) {
		this.dueInIncome = dueInIncome;
	}

	public BigDecimal getAccumulatedIncome() {
		return accumulatedIncome;
	}

	public void setAccumulatedIncome(BigDecimal accumulatedIncome) {
		this.accumulatedIncome = accumulatedIncome;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public BalanceAmount(Integer id, String userIdentifier, String realName,
			String cellphone, BigDecimal availableAmount,
			BigDecimal freezeAmount, Date updatedAt, BigDecimal dueInAmount,
			BigDecimal dueInIncome, BigDecimal accumulatedIncome) {
		super();
		this.id = id;
		this.userIdentifier = userIdentifier;
		this.realName = realName;
		this.cellphone = cellphone;
		this.availableAmount = availableAmount;
		this.freezeAmount = freezeAmount;
		this.updatedAt = updatedAt;
		this.dueInAmount = dueInAmount;
		this.dueInIncome = dueInIncome;
		this.accumulatedIncome = accumulatedIncome;
	}

	public BalanceAmount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
