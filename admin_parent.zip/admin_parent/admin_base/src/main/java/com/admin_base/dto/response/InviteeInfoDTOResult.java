package com.admin_base.dto.response;

import java.util.Date;

/***
 * 10���ƹ� ����������ϢDTO
 * @author guxiaojun
 * @Date 2015-10-15
 */
public class InviteeInfoDTOResult{
	
	
	/*��������ID*/
	private String userIdentifier;
	/*����*/
	private String realName;
	/*��ϵ��ʽ*/
	private String cellphone;
	/*ע��ʱ��*/
	private Date signUpTime;
	/*Ͷ��ʱ��*/
	private Date investTime;
	
	
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getCellphone() {
		return cellphone;
	}
	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	public Date getSignUpTime() {
		return signUpTime;
	}
	public void setSignUpTime(Date signUpTime) {
		this.signUpTime = signUpTime;
	}
	public Date getInvestTime() {
		return investTime;
	}
	public void setInvestTime(Date investTime) {
		this.investTime = investTime;
	}
	
	
}
