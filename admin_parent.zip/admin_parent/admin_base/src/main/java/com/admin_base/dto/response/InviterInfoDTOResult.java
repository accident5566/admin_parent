package com.admin_base.dto.response;

/***
 * 10���ƹ� ��������ϢDTO
 * @author guxiaojun
 * @Date 2015-10-14
 */
public class InviterInfoDTOResult{
	

	/*������ID*/
	private String userIdentifier;
	/*����������*/
	private String realName;
	/*��ϵ��ʽ*/
	private String cellphone;
	/*���������*/
	private Integer totalCount;
	/*����ɹ�����*/
	private Integer successCount;
	/*����ȴ�����*/
	private Integer waitingCount;
	
	
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getCellphone() {
		return cellphone;
	}
	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public Integer getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(Integer successCount) {
		this.successCount = successCount;
	}
	public Integer getWaitingCount() {
		return waitingCount;
	}
	public void setWaitingCount(Integer waitingCount) {
		this.waitingCount = waitingCount;
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	
}
