package com.admin_base.model;

import java.math.BigDecimal;
import java.util.Date;

/***
 * Ԥ����Ϣʵ��
 * @author ted.chen
 * @date 2015-03-20
 */
public class BookProducts {

	/*������ʶid*/
	private Integer id;
	
	/*�ֻ�����*/
	private String cellphone;
	
	/*��Ʒ��ʶ*/
	private Integer productid;
	
    /*��������*/
    private BigDecimal extrainterest;
    
    /*Ԥ������*/
    private BigDecimal interest;
    
    /*Ԥ�����*/
    private BigDecimal amount;
	
    /*������ʱ��*/
	private Date time;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public Integer getProductid() {
		return productid;
	}

	public void setProductid(Integer productid) {
		this.productid = productid;
	}

	public BigDecimal getExtrainterest() {
		return extrainterest;
	}

	public void setExtrainterest(BigDecimal extrainterest) {
		this.extrainterest = extrainterest;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public BookProducts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BookProducts(String cellphone, Integer productid, BigDecimal amount,
			BigDecimal interest, BigDecimal extrainterest, Date time) {
		super();
		this.cellphone = cellphone;
		this.productid = productid;
		this.extrainterest = extrainterest;
		this.interest = interest;
		this.amount = amount;
		this.time = time;
	}

	@Override
	public String toString() {
		return "BookProducts [id=" + id + ", cellphone=" + cellphone
				+ ", productid=" + productid + ", extrainterest="
				+ extrainterest + ", interest=" + interest + ", amount="
				+ amount + ", time=" + time + "]";
	}
}
