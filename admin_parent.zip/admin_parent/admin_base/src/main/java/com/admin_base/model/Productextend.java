package com.admin_base.model;

import java.text.ParseException;
import java.util.Date;

import com.admin_base.util.DateUtil;

/***
 * ��̨��Ʒ�ؿ��¼��
 * @author ted.chen
 * @date 2015-03-20
 */
public class Productextend {

	/*��Ʒ��identifier*/
	private String productIdentifier;
	
	/*��Ʒ�����κ�(�����ص�)*/
	private String productPayBatchNo;

	/*�ص�ִ�е�ʱ���*/
	private Date excuteTime;
	
	/*֧����Դ*/
	private Integer payFrom;
	
	
	
	

	public Integer getPayFrom() {
		return payFrom;
	}

	public void setPayFrom(Integer payFrom) {
		this.payFrom = payFrom;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public String getProductPayBatchNo() {
		return productPayBatchNo;
	}

	public void setProductPayBatchNo(String productPayBatchNo) {
		this.productPayBatchNo = productPayBatchNo;
	}

	public Productextend(String productIdentifier, String productPayBatchNo) {
		this.productIdentifier = productIdentifier;
		this.productPayBatchNo = productPayBatchNo;
		
	}
	
	public Productextend(String productIdentifier, Integer payFrom) {
		super();
		this.productIdentifier = productIdentifier;
		this.payFrom = payFrom;
	}

	public Productextend(String productIdentifier, String productPayBatchNo,
			Date excuteTime, Integer payFrom) {
		this.productIdentifier = productIdentifier;
		this.productPayBatchNo = productPayBatchNo;
		this.excuteTime = excuteTime;
		this.payFrom = payFrom;
	}

	public Productextend(String productIdentifier, String productPayBatchNo,Integer payFrom) {
		this.productIdentifier = productIdentifier;
		this.productPayBatchNo = productPayBatchNo;
		this.payFrom = payFrom;
	}
	
	public Date getExcuteTime() {
		return excuteTime;
	}

	public void setExcuteTime(Date excuteTime) {
		this.excuteTime = excuteTime;
	}

	
	

	public Productextend(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	
	public Productextend() {
		super();
	}

	@Override
	public String toString() {
		try {
			return "Productextend [productIdentifier=" + productIdentifier
					+ ", productPayBatchNo=" + productPayBatchNo + ",excuteTime="+ DateUtil.GetStringDate(excuteTime) + ",payForm="+ payFrom + "]";
		} catch (ParseException e) {
			e.printStackTrace();
			return "Productextend [productIdentifier=" + productIdentifier
					+ ", productPayBatchNo=" + productPayBatchNo + ",excuteTime="+ excuteTime + ",payForm="+ payFrom + "]";
		}
	}
	
}
