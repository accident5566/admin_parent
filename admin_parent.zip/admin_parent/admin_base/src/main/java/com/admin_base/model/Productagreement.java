package com.admin_base.model;

import java.io.Serializable;
/***
 * ��ƷЭ��ʵ����
 * @author qiupeiwei
 * @Date 2015-03-30
 */
@SuppressWarnings("serial")
public class Productagreement implements Serializable{
	/*��ʶid*/
	private Integer paid;
	/*��Ʒ�ı��*/
	private String productNo;
	/*�ж�Э��*/
	private String accAgreemContent;
	/*ί��Э��*/
	private String conAgreemContent;
	
	/*Э�����ơ�Э�������ǳжҡ�*/
	private String accName;
	
	/*Э�����ơ�Э��������ί�С�*/
	private String conName;
	
	private String ptype;/*ҳ�������ʶ�ͱ��ֶβ���Ӧ*/
	
	
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getConName() {
		return conName;
	}
	public void setConName(String conName) {
		this.conName = conName;
	}
	public Integer getPaid() {
		return paid;
	}
	public void setPaid(Integer paid) {
		this.paid = paid;
	}
	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	public String getAccAgreemContent() {
		return accAgreemContent;
	}
	public void setAccAgreemContent(String accAgreemContent) {
		this.accAgreemContent = accAgreemContent;
	}
	public String getConAgreemContent() {
		return conAgreemContent;
	}
	public void setConAgreemContent(String conAgreemContent) {
		this.conAgreemContent = conAgreemContent;
	}
	
    public Productagreement(String productNo,ProductAgreementTemplate p1,ProductAgreementTemplate p2){
    	this.accName = p1.getAgreementName();
		this.conName = p2.getAgreementName();
		this.productNo = productNo;
		this.accAgreemContent = p1.getAgreementcontent();
		this.conAgreemContent = p2.getAgreementcontent();
	}
	

	public Productagreement(Integer paid, String productNo,
			String accAgreemContent, String conAgreemContent) {
		super();
		this.paid = paid;
		this.productNo = productNo;
		this.accAgreemContent = accAgreemContent;
		this.conAgreemContent = conAgreemContent;
	}
	
	public Productagreement(String accName,String conName,String productNo, String accAgreemContent,
			String conAgreemContent) {
		super();
		this.accName = accName;
		this.conName = conName;
		this.productNo = productNo;
		this.accAgreemContent = accAgreemContent;
		this.conAgreemContent = conAgreemContent;
	}
	public Productagreement() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Productagreement(String productNo) {
		this.productNo = productNo;
	}
	@Override
	public String toString() {
		return "Productagreement [paid=" + paid + ", productNo=" + productNo
				+ ", accAgreemContent=" + accAgreemContent
				+ ", conAgreemContent=" + conAgreemContent + "]";
     }
}
