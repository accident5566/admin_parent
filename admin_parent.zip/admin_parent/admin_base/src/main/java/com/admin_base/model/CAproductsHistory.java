package com.admin_base.model;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import com.admin_base.util.DateUtil;

/***
 * ������¼ʵ����
 * @author peiwei
 * @Date 2015-05-20
 */
public class CAproductsHistory{
	/*����ʶid*/
	private Integer id;
	/*��Ʒ��uuid*/
	private String productIdentifier;
	/*��Ʒ�ı��*/
	private String productNo;
	/*��Ʒ������*/
	private String productName;
	/*���������ܷݶ�*/
	private Integer financingSumCount;
	/*�����ӱ��*/
	private String subProductNo;
	/*����*/
	private Integer unitPrice;
	/*���ڿ���ʱ��*/
	private Date nextEndSellTime;
	/*�����껯������*/
	private BigDecimal nextYield;
	/*�Ƿ���*/
	private Integer enableSale;
	/*�ж�Э������*/
	private String accName;
	/*�ж�Э������*/
	private String accAgreemContent;
	/*ί��Э������*/
	private String conName;
	/*ί��Э������*/
	private String conAgreemContent;
	/*�������ֶ��*/
	private BigDecimal perRemainRedeemAmount;
	/*����ʱ��*/
	private Date createTime;
	/*�޸�ʱ��*/
	private Date updateTime;
	
	public CAproductsHistory getCAproductsHistory(String productIdentifier){
		CAproductsHistory ca = new CAproductsHistory();
		ca.setProductIdentifier(productIdentifier);
		return ca;
	}
	public CAproductsHistory(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public CAproductsHistory getcaproHistory(CAProdcutpackage caProdcutpackage) throws ParseException{
		CAproductsHistory caprohistory = new CAproductsHistory();
		caprohistory.setCreateTime(new Date());
		caprohistory.setEnableSale(1);
		Integer portion = caProdcutpackage.getPackageMoney().divide(new BigDecimal(caProdcutpackage.getInvestmentProportion())).intValue();
		caprohistory.setFinancingSumCount(portion);
		caprohistory.setNextEndSellTime(DateUtil.GetStringDatePin(caProdcutpackage.getPackageSendDate(),caProdcutpackage.getPackageApplyStartData()));
		caprohistory.setNextYield(caProdcutpackage.getInterestRate());
		caprohistory.setPerRemainRedeemAmount(caProdcutpackage.getTomWithdraw());
		caprohistory.setProductNo("CA001");
		caprohistory.setProductName("���ڱ�");
		caprohistory.setProductIdentifier("CA1505290118");
		caprohistory.setSubProductNo(caProdcutpackage.getPackageNo());
		caprohistory.setUnitPrice(caProdcutpackage.getInvestmentProportion());
		caprohistory.setUpdateTime(new Date());
		caprohistory.setPerRemainRedeemAmount(new BigDecimal(0));
		caprohistory.setAccName("��ʱΪ��");
		caprohistory.setAccAgreemContent("��ʱΪ��");
		caprohistory.setConName("��ʱΪ��");
		caprohistory.setConAgreemContent("��ʱΪ��");
		return caprohistory;
	}
	public static void main(String[] args) {
		
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductIdentifier() {
		return productIdentifier;
	}
	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getFinancingSumCount() {
		return financingSumCount;
	}
	public void setFinancingSumCount(Integer financingSumCount) {
		this.financingSumCount = financingSumCount;
	}
	public String getSubProductNo() {
		return subProductNo;
	}
	public void setSubProductNo(String subProductNo) {
		this.subProductNo = subProductNo;
	}
	
	public Integer getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Integer unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Date getNextEndSellTime() {
		return nextEndSellTime;
	}
	public void setNextEndSellTime(Date nextEndSellTime) {
		this.nextEndSellTime = nextEndSellTime;
	}
	public BigDecimal getNextYield() {
		return nextYield;
	}
	public void setNextYield(BigDecimal nextYield) {
		this.nextYield = nextYield;
	}
	public Integer getEnableSale() {
		return enableSale;
	}
	public void setEnableSale(Integer enableSale) {
		this.enableSale = enableSale;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getAccAgreemContent() {
		return accAgreemContent;
	}
	public void setAccAgreemContent(String accAgreemContent) {
		this.accAgreemContent = accAgreemContent;
	}
	public String getConName() {
		return conName;
	}
	public void setConName(String conName) {
		this.conName = conName;
	}
	public String getConAgreemContent() {
		return conAgreemContent;
	}
	public void setConAgreemContent(String conAgreemContent) {
		this.conAgreemContent = conAgreemContent;
	}
	public BigDecimal getPerRemainRedeemAmount() {
		return perRemainRedeemAmount;
	}
	public void setPerRemainRedeemAmount(BigDecimal perRemainRedeemAmount) {
		this.perRemainRedeemAmount = perRemainRedeemAmount;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public CAproductsHistory(Integer id, String productIdentifier,
			String productNo, String productName, Integer financingSumCount,
			String subProductNo, Integer unitPrice, Date nextEndSellTime,
			BigDecimal nextYield, Integer enableSale, String accName,
			String accAgreemContent, String conName, String conAgreemContent,
			BigDecimal perRemainRedeemAmount, Date createTime, Date updateTime) {
		super();
		this.id = id;
		this.productIdentifier = productIdentifier;
		this.productNo = productNo;
		this.productName = productName;
		this.financingSumCount = financingSumCount;
		this.subProductNo = subProductNo;
		this.unitPrice = unitPrice;
		this.nextEndSellTime = nextEndSellTime;
		this.nextYield = nextYield;
		this.enableSale = enableSale;
		this.accName = accName;
		this.accAgreemContent = accAgreemContent;
		this.conName = conName;
		this.conAgreemContent = conAgreemContent;
		this.perRemainRedeemAmount = perRemainRedeemAmount;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}
	public CAproductsHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CAproductsHistory [id=" + id + ", productIdentifier="
				+ productIdentifier + ", productNo=" + productNo
				+ ", productName=" + productName + ", financingSumCount="
				+ financingSumCount + ", subProductNo=" + subProductNo
				+ ", unitPrice=" + unitPrice + ", nextEndSellTime="
				+ nextEndSellTime + ", nextYield=" + nextYield
				+ ", enableSale=" + enableSale + ", accName=" + accName
				+ ", accAgreemContent=" + accAgreemContent + ", conName="
				+ conName + ", conAgreemContent=" + conAgreemContent
				+ ", perRemainRedeemAmount=" + perRemainRedeemAmount
				+ ", createTime=" + createTime + ", updateTime=" + updateTime
				+ "]";
	}
	
	
	
}
