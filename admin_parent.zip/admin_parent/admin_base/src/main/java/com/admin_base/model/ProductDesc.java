package com.admin_base.model;

/**
 * ��Ʒ����ʵ����
 * @author peiwei
 * @Date 2015-05-29
 */
public class ProductDesc {
	/*��ʶid*/
	private Integer id;
	/*�ص�*/
	private String feature;
	/*�������*/
	private String borrowType;
	/*�ʽ���;*/
	private String purpose;
	/*����������*/
	private String association;
	/*����*/
	private String assure;
	/*���*/
	private String riskControl;
	/*��Ʒ���*/
	private String productIdentifier;
	
	public ProductDesc getProductDesc(Product product){
		ProductDesc pp = new ProductDesc();
		pp.setAssociation(product.getAssociation());
		pp.setAssure(product.getAssure());
		pp.setBorrowType(product.getBorrowType());
		pp.setFeature(product.getFeature());
		pp.setProductIdentifier(product.getProductIdentifier());
		pp.setPurpose(product.getPurpose());
		pp.setRiskControl(product.getRiskControl());
		return pp;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	public String getBorrowType() {
		return borrowType;
	}
	public void setBorrowType(String borrowType) {
		this.borrowType = borrowType;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getAssociation() {
		return association;
	}
	public void setAssociation(String association) {
		this.association = association;
	}
	public String getAssure() {
		return assure;
	}
	public void setAssure(String assure) {
		this.assure = assure;
	}
	public String getRiskControl() {
		return riskControl;
	}
	public void setRiskControl(String riskControl) {
		this.riskControl = riskControl;
	}
	public String getProductIdentifier() {
		return productIdentifier;
	}
	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}
	public ProductDesc(Integer id, String feature, String borrowType,
			String purpose, String association, String assure,
			String riskControl, String productIdentifier) {
		super();
		this.id = id;
		this.feature = feature;
		this.borrowType = borrowType;
		this.purpose = purpose;
		this.association = association;
		this.assure = assure;
		this.riskControl = riskControl;
		this.productIdentifier = productIdentifier;
	}
	public ProductDesc() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ProductDesc [id=" + id + ", feature=" + feature
				+ ", borrowType=" + borrowType + ", purpose=" + purpose
				+ ", association=" + association + ", assure=" + assure
				+ ", riskControl=" + riskControl + ", productIdentifier="
				+ productIdentifier + "]";
	}
    
}
