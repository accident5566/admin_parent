package com.admin_base.dto.response;

import java.math.BigDecimal;
import java.util.Date;

import com.admin_base.constant.DateConstant;
import com.admin_base.dto.request.EnPayMoneyDTO;
import com.admin_base.util.DateUtil;

public class PayMoneyDTOResult {
	private String merchantsn;//��Ʒ�����κ�
	private String name;//��ҵ������
	private String mobile;//�ֻ�����
	private String bankname;//��������
	private String account;//����
	private BigDecimal amount;//�ɹ������ܽ��
	private Date createdAt;//����ʱ��
	private String bankno;//���к�
	
	
	public PayMoneyDTOResult(EnPayMoneyDTO enPayMoneydtoj){
		this.merchantsn = enPayMoneydtoj.getBatchNo();
		this.name = enPayMoneydtoj.getEnterpriseName();
		this.mobile = "13000000000";
		this.bankname = enPayMoneydtoj.getBankName();
		this.account = enPayMoneydtoj.getBankCard();
		this.amount = enPayMoneydtoj.getTotalSuccessOrderMoney();
		this.createdAt = DateUtil.GetDate(new Date(), DateConstant.DATE_FORMAT_YMDHMS_ONE);
		this.bankno = enPayMoneydtoj.getBankCard();
	}
	
	public PayMoneyDTOResult() {
	}

	
	public String getMerchantsn() {
		return merchantsn;
	}

	public String getBankno() {
		return bankno;
	}

	public void setBankno(String bankno) {
		this.bankno = bankno;
	}

	public void setMerchantsn(String merchantsn) {
		this.merchantsn = merchantsn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
}
