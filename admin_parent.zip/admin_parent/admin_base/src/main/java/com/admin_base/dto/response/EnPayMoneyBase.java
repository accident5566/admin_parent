package com.admin_base.dto.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class EnPayMoneyBase {

	private String productNo;
	
	private BigDecimal toSuccessMoney;
    
	private List<EnPayMoneyDTOResult> enPayMoList = new ArrayList<EnPayMoneyDTOResult>();

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public BigDecimal getToSuccessMoney() {
		return toSuccessMoney;
	}

	public void setToSuccessMoney(BigDecimal toSuccessMoney) {
		this.toSuccessMoney = toSuccessMoney;
	}

	public List<EnPayMoneyDTOResult> getEnPayMoList() {
		return enPayMoList;
	}

	public void setEnPayMoList(List<EnPayMoneyDTOResult> enPayMoList) {
		this.enPayMoList = enPayMoList;
	}


}
