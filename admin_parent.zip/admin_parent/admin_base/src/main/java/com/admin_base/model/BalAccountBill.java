package com.admin_base.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/***
 * ����˻�ϵͳ_��ˮ��ѯʵ��
 * @author guxiaojun
 * @Date 2015-11-18
 */

public class BalAccountBill implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4794114752532272590L;

	/*��ʶid*/
	private Integer id;
	
	 /*����ʱ��*/
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdAt;
    
    /*�û�����*/
    private String userName;
    
    /*�û�UUID*/
    private String userIdentifier;
    
    /*���κ�*/
    private String batchNo;
    
    /*��ϵ��ʽ*/
    private String cellphone;
    
	/*��������*/
    private Integer type;
    
    /*������������*/
    private String typeName;
    
    /*��ˮ����*/
    private String orderNo;
    
    /*���*/
    private BigDecimal amount;
    
    /*״̬*/
    private Integer status;
    
    /*��������ʱ��*/
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date resultAt;
    
    /*��������*/
    private String bankName;
    
    /*���п���*/
    private String cardNo;
    

    private String statusName;
    
    private String idCard;
    
    /*�������*/
    private String resultMessage;
    
    /*֧������*/
    private Integer payType;
    
    /*ͨ������*/
    private String resultCode;
    
    /*������*/
    private BigDecimal fee;
    
    /*����ǰ���*/
    private BigDecimal beforeAvailableAmount;
    
    /*���׺���*/
    private BigDecimal afterAvailableAmount;
    
    private String returnUrl;

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}



	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getResultAt() {
		return resultAt;
	}

	public void setResultAt(Date resultAt) {
		this.resultAt = resultAt;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
	
    public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getPayType() {
		return payType;
	}

	public void setPayType(Integer payType) {
		this.payType = payType;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public BigDecimal getBeforeAvailableAmount() {
		return beforeAvailableAmount;
	}

	public void setBeforeAvailableAmount(BigDecimal beforeAvailableAmount) {
		this.beforeAvailableAmount = beforeAvailableAmount;
	}

	public BigDecimal getAfterAvailableAmount() {
		return afterAvailableAmount;
	}

	public void setAfterAvailableAmount(BigDecimal afterAvailableAmount) {
		this.afterAvailableAmount = afterAvailableAmount;
	}

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}





}
