package com.admin_base.dto.response;

import java.util.ArrayList;
import java.util.List;

public class ReconciliationQueryYiJiaDTOModel {
 private String message;
 private String resultCode;
 private String batchNo;
 private List<ReconciliationQueryYiJiaDTOMsg> properties = new ArrayList<ReconciliationQueryYiJiaDTOMsg>();
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getResultCode() {
	return resultCode;
}
public void setResultCode(String resultCode) {
	this.resultCode = resultCode;
}
public String getBatchNo() {
	return batchNo;
}
public void setBatchNo(String batchNo) {
	this.batchNo = batchNo;
}
public List<ReconciliationQueryYiJiaDTOMsg> getProperties() {
	return properties;
}
public void setProperties(List<ReconciliationQueryYiJiaDTOMsg> properties) {
	this.properties = properties;
}
 
}
