package com.admin_base.dto.response;

import java.util.ArrayList;
import java.util.List;

public class UserPaymentQueryModel {

	private String message;
	private String resultCode;
	private String batchNo;
	private List<UserPaymentQueryMessage> properties = new ArrayList<UserPaymentQueryMessage>();
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public List<UserPaymentQueryMessage> getProperties() {
		return properties;
	}
	public void setProperties(List<UserPaymentQueryMessage> properties) {
		this.properties = properties;
	}
    
}
