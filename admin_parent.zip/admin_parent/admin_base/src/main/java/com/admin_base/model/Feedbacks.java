package com.admin_base.model;

import java.util.Date;

/***
 * ������Ϣʵ����
 * @author qiupeiwei
 * @date 2015-03-10
 */
public class Feedbacks {

	/*������ʶid*/
	private Integer id;
	
	/*�ֻ�����*/
	private String cellphone;
	
	/*��������*/
	private String content;
	
    /*������ʱ��*/
	private Date time;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Feedbacks(String cellphone, String content, Date time) {
		super();
		this.cellphone = cellphone;
		this.content = content;
		this.time = time;
	}

	public Feedbacks() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Feedbacks [id=" + id + ", cellphone=" + cellphone
				+ ", content=" + content + ", time=" + time + "]";
	}
	
	
	
}
