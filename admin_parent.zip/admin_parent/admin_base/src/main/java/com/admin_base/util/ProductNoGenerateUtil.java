package com.admin_base.util;

import java.text.ParseException;
import java.util.Date;

import com.admin_base.constant.DateFormatConstant;

public class ProductNoGenerateUtil {

	public static String getProductNo(String str) throws ParseException{
//		StringBuffer sdf = new StringBuffer(SystemProperty.getProperty("product.number.initial.first"));
		StringBuffer sdf = new StringBuffer(str);
		sdf.append(DateUtil.GetStringDate(new Date(), DateFormatConstant.MINUTES_FORMAT_YMDMS));
		return sdf.toString();
	}
	
	public static String getBatchNo(String str) throws ParseException{
//		StringBuffer sdf = new StringBuffer(SystemProperty.getProperty("product.number.initial.first"));
		StringBuffer sdf = new StringBuffer(str);
		sdf.append(getRandomChar());
		sdf.append(DateUtil.GetStringDate(new Date(), DateFormatConstant.MINUTES_FORMAT_YMDMS));
		return sdf.toString();
	}
	
	public static char getRandomChar() {
		String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		return chars.charAt((int)(Math.random() * 26));
	}
	
	public static void main(String[] args) throws ParseException {
		System.out.println(getProductNo("O").toString());
	}
}
