package com.admin_base.model;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @see �����ʵ����
 * @author peiwei
 * @Date 2015-10-12
 */
public class Voucher implements Serializable {
	private static final long serialVersionUID = 1L;
	/* ��ʶid */
	private Integer id;
	/* ���� */
	private String voucherNo;
	/* ���� */
	private String voucherName;
	/* ����ʱ�� */
	private Date expiredTime;
	/* ��Чʱ�� */
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date effectiveTime;
	/* ʹ��״̬(1.δʹ��,2.ʹ���У�3.��ʹ��) */
	private Integer useState;
	/* ��� */
	private BigDecimal amount;
	/* �����Ķ������ */
	private String orderNo;
	/* ʹ��ʱ�� */
	private Date useDate;
	/* �����û� */
	private String userIdentifier;
	/* �Ƽ��ɹ����û���uuid */
	private String recommendUuid;
	/* ����� */
	private String activityName;
	/* �û����� �����ֶ�*/
	private String realname;
	/* ��ϵ��ʽ �����ֶ�*/
	private String cellphone;
	/* ���������������ֶ�*/
	private String loginName;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getRealname() {
		return realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getVoucherNo() {
		return voucherNo;
	}

	public void setVoucherNo(String voucherNo) {
		this.voucherNo = voucherNo;
	}

	public String getVoucherName() {
		return voucherName;
	}

	public void setVoucherName(String voucherName) {
		this.voucherName = voucherName;
	}

	public Date getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(Date expiredTime) {
		this.expiredTime = expiredTime;
	}

	public Date getEffectiveTime() {
		return effectiveTime;
	}

	public void setEffectiveTime(Date effectiveTime) {
		this.effectiveTime = effectiveTime;
	}

	public Integer getUseState() {
		return useState;
	}

	public void setUseState(Integer useState) {
		this.useState = useState;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getUseDate() {
		return useDate;
	}

	public void setUseDate(Date useDate) {
		this.useDate = useDate;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public String getRecommendUuid() {
		return recommendUuid;
	}

	public void setRecommendUuid(String recommendUuid) {
		this.recommendUuid = recommendUuid;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Voucher(Integer id, String voucherNo, String voucherName,
			Date expiredTime, Date effectiveTime, Integer useState,
			BigDecimal amount, String orderNo, Date useDate,
			String userIdentifier, String recommendUuid, String activityName) {
		super();
		this.id = id;
		this.voucherNo = voucherNo;
		this.voucherName = voucherName;
		this.expiredTime = expiredTime;
		this.effectiveTime = effectiveTime;
		this.useState = useState;
		this.amount = amount;
		this.orderNo = orderNo;
		this.useDate = useDate;
		this.userIdentifier = userIdentifier;
		this.recommendUuid = recommendUuid;
		this.activityName = activityName;
	}

	public Voucher() {
		super();
	}

	@Override
	public String toString() {
		return "Voucher [id=" + id + ", voucherNo=" + voucherNo
				+ ", voucherName=" + voucherName + ", expiredTime="
				+ expiredTime + ", effectiveTime=" + effectiveTime
				+ ", useState=" + useState + ", amount=" + amount
				+ ", orderNo=" + orderNo + ", useDate=" + useDate
				+ ", userIdentifier=" + userIdentifier + ", recommendUuid="
				+ recommendUuid + ", activityName=" + activityName + "]";
	}
}
