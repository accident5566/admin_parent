package com.admin_current.dto.response;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class GetUserRedeemResponse {
	
	/*�Ӱ����*/
	private String subPackageNo;
	
	/*��ˮ��(����)*/
	private String sn;
	
    /*����uuid*/
	private String orderIdentifier;
	
	/*�ֻ���*/
	private String phone;
	
	/*����*/
	private String name;
	
	/*������*/
	private BigDecimal principal;
	
	/*������Ϣ���*/
	private BigDecimal redeemInterest;
	
	/*����(���֣�����)*/
	private Integer type;
	
	/*״̬(������,����ɹ�,����ʧ��,������,���ִ���)*/
	private Integer status;
	
	/*����Ԥ������*/
	private Date delayDate;
	
	/*����ʱ��*/
	private Date createTime;
	
	/*���ʱ��*/
	private Date resultTime;
	
	/*���п���*/
	private String bankCardNo;
	
	/*������*/
	private String bankName;

	
	/*ҳ���ѯʹ��*/
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date startDate;//��ʼʱ��
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date endDate;//����ʱ��
	
	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getSubPackageNo() {
		return subPackageNo;
	}

	public void setSubPackageNo(String subPackageNo) {
		this.subPackageNo = subPackageNo;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getOrderIdentifier() {
		return orderIdentifier;
	}

	public void setOrderIdentifier(String orderIdentifier) {
		this.orderIdentifier = orderIdentifier;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}

	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}

	public BigDecimal getRedeemInterest() {
		return redeemInterest;
	}

	public void setRedeemInterest(BigDecimal redeemInterest) {
		this.redeemInterest = redeemInterest;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getDelayDate() {
		return delayDate;
	}

	public void setDelayDate(Date delayDate) {
		this.delayDate = delayDate;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getResultTime() {
		return resultTime;
	}

	public void setResultTime(Date resultTime) {
		this.resultTime = resultTime;
	}

	public String getBankCardNo() {
		return bankCardNo;
	}

	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
}
