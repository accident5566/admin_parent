package com.admin_current.controller;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.CAProdcutpackage;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_current.service.CAProdcutpackageService;
/**
 * ����Ŀ����
 * @author peiwei
 * @Date 2015-05-26
 */
@Controller
@RequestMapping("/proPackageController")
public class CAProductController {

	@Autowired
	private CAProdcutpackageService proPackageI;
	
	@RequestMapping(value="/getProjectPackage",method = RequestMethod.GET)
	public ModelAndView getProjectPackage(HttpServletRequest request, HttpServletResponse response,CAProdcutpackage proPackage) throws IOException{
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("pageView",pageView);
		model.addObject("proPackage",proPackage);
		model.addObject("now", new Date());
		model.addObject("proPackageList", proPackageI.getProPackageByPage(pageView, proPackage));
		model.setViewName("currentProduct/projectPackage/proPackageManager");
		return model;
	}
	
	@RequestMapping(value="/addProjectPackage",method = RequestMethod.POST)
	public  String  addProjectPackage(HttpServletRequest request, HttpServletResponse response,@Valid @ModelAttribute("addProjectPackage") CAProdcutpackage proPackage,BindingResult result){
	   System.out.println(result.hasErrors());
	   request.setAttribute("dateList", CAProdcutpackage.getdateList());
	   if(result.hasErrors()){
		    return "currentProduct/projectPackage/proPackageAdd";	   
	    }
	   if(proPackage.getPackageMoney().intValue() % proPackage.getInvestmentProportion() != 0){
		   request.setAttribute("checkPackmoney", "�����ǲ�Ʒ���۵�������,�����µ������Ľ����߲�Ʒ�ĵ���...");
		   return "currentProduct/projectPackage/proPackageAdd";
	   }
	   boolean falg = proPackageI.saveProPackageByPage(proPackage);
	   if(falg){
		   return "redirect:getProjectPackage";	 
	   }
	   return "currentProduct/projectPackage/proPackageAdd";	 
	}	
	@RequestMapping(value="/updateProjectPackage",method = RequestMethod.POST)
	public  String  updateProjectPackage(HttpServletRequest request, HttpServletResponse response,@Valid @ModelAttribute("updateProjectPackage") CAProdcutpackage proPackage,BindingResult result){
		 request.setAttribute("dateList", CAProdcutpackage.getdateList()); 
		 request.setAttribute("proPackage",proPackageI.getProPackageInfo(proPackage.getPackageNo()));
		 if(result.hasErrors()){
			    return "currentProduct/projectPackage/proPackageUpdate";	   
		 }
		 if(proPackage.getPackageMoney().intValue() % proPackage.getInvestmentProportion() != 0){
			   request.setAttribute("checkPackmoney", "�����ǲ�Ʒ���۵�������,�����µ������Ľ����߲�Ʒ�ĵ���...");
			   return "currentProduct/projectPackage/proPackageUpdate";
		   }
		 boolean flag = proPackageI.updateProPackage(proPackage);
		 if(flag){
			 return "redirect:getProjectPackage";	 
		 }
		 return "currentProduct/projectPackage/proPackageUpdate";
	}	
	
	@RequestMapping(value="/projectPackageOnLine",method = RequestMethod.POST)
	public  String  projectPackageOnLine(HttpServletRequest request, HttpServletResponse response,@Valid @ModelAttribute("projectPackageDetail") CAProdcutpackage proPackage,BindingResult result){
		 request.setAttribute("dateList", CAProdcutpackage.getdateList()); 
		 request.setAttribute("proPackage",proPackageI.getProPackageInfo(proPackage.getPackageNo()));
		 boolean flag = proPackageI.packageOnline(proPackageI.getProPackageInfo(proPackage.getPackageNo()));
		 if(flag){
			 return "redirect:getProjectPackage";	 
		 }
		 return "currentProduct/projectPackage/returnDetailProjectPackagePage";
	}	
	
	@RequestMapping(value="/returnAddProjectPackagePage",method = RequestMethod.GET)
	public  ModelAndView returnAddProjectPackagePage(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("addProjectPackage") CAProdcutpackage proPackage) throws ParseException, IOException{
	   ModelAndView  model = new ModelAndView();
	   model.addObject("dateList", CAProdcutpackage.getdateList());
	   model.setViewName("currentProduct/projectPackage/proPackageAdd");
	   return model;
	}	
	@RequestMapping(value="/returnUpdateProjectPackagePage",method = RequestMethod.GET)
	public  ModelAndView returnUpdateProjectPackagePage(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("updateProjectPackage") CAProdcutpackage proPackage) throws ParseException, IOException{
	   ModelAndView  model = new ModelAndView();
	   model.addObject("proPackage",proPackageI.getProPackageInfo(proPackage.getPackageNo()));
	   model.addObject("dateList", CAProdcutpackage.getdateList());
	   model.setViewName("currentProduct/projectPackage/proPackageUpdate");
	   return model;
	}
	@RequestMapping(value="/returnDetailProjectPackagePage",method = RequestMethod.GET)
	public  ModelAndView returnDetailProjectPackagePage(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("projectPackageDetail") CAProdcutpackage proPackage) throws ParseException, IOException{
	   ModelAndView  model = new ModelAndView();
	   model.addObject("proPackage",proPackageI.getProPackageInfo(proPackage.getPackageNo()));
	   model.addObject("dateList", CAProdcutpackage.getdateList());
	   model.setViewName("currentProduct/projectPackage/proPackageDetail");
	   return model;
	}
	
}
