package com.admin_current.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.constant.SelectConstant;
import com.admin_base.model.CAProdcutpackage;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_current.dto.response.GetUserRedeemResponse;
import com.admin_current.service.UserRedeemService;

/**
 * �û���ؼ�¼��Ϣ
 * @author peiwei
 * @Date 2015-06-05
 */
@Controller
@RequestMapping("/userRedeemController")
public class CAUserRedeemController {
	
	@Autowired private UserRedeemService userRedeemServiceI;
	
	@RequestMapping(value="/getUserRedeem",method = RequestMethod.GET)
	public ModelAndView getUserRedeem(HttpServletRequest request, HttpServletResponse response,GetUserRedeemResponse userRedeem) throws IOException{
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("userRedeemList", userRedeemServiceI.searchUserRedeemByPage(userRedeem, pageView));
		model.addObject("pageView",pageView);
		model.addObject("CABillList",SelectConstant.getCABillSelectList());
		model.addObject("userRedeem", userRedeem);
		model.setViewName("currentProduct/userRedeem/userRedeemManager");
		return model;
	}
}
