package com.admin_current.service;

import java.util.List;

import com.admin_base.model.CAProdcutpackage;
import com.admin_base.mybatis.plug.PageParameter;

public interface CAProdcutpackageService {
	public List<CAProdcutpackage> getProPackageByPage(PageParameter pageView, CAProdcutpackage propaclage);
	public boolean saveProPackageByPage(CAProdcutpackage propaclage);
	public boolean updateProPackage(CAProdcutpackage caProdcutpackage);
	public CAProdcutpackage getProPackageInfo(String packageNo);
	public boolean packageOnline(CAProdcutpackage proPackage); 
}
