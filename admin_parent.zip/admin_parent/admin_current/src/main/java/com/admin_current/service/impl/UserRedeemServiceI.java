package com.admin_current.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.mybatis.plug.PageParameter;
import com.admin_current.dao.CAUserRedeemDao;
import com.admin_current.dto.response.GetUserRedeemResponse;
import com.admin_current.service.UserRedeemService;

@Service
public class UserRedeemServiceI implements UserRedeemService {
	private static final Logger log = Logger.getLogger(UserRedeemServiceI.class);
	
	@Autowired private CAUserRedeemDao userRedeemDaoI;
	
	@Override
	public List<GetUserRedeemResponse> searchUserRedeemByPage(GetUserRedeemResponse userRedeem,PageParameter pageView) {
		List<GetUserRedeemResponse> userRedeemList = null;
		try {
			Map<String,Object> parameterMap = new HashMap<String,Object>();
			parameterMap.put("t", userRedeem);
			parameterMap.put("page", pageView);
			userRedeemList = userRedeemDaoI.getByPage(parameterMap);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("�û�������ؼ�¼��Ϣ��������UserRedeemServiceI����������searchUserRedeem�����쳣�쳣��ԭ����:"+e.getMessage());
		}
		return userRedeemList;
	}

}
