package com.admin_current.service;

import com.admin_base.model.CAproductsHistory;

public interface CAproductsHistoryService {

	public boolean saveProHistory(CAproductsHistory caProHistory);
	
	public  CAproductsHistory getproHistory(String proindentifier);
}
