package com.admin_current.service;

import com.admin_base.model.CAproducts;

public interface CAproductsService {

	public CAproducts getCAproductsInfo(String productIdentifier);
	
	public boolean updateCAproduct(CAproducts caproducts);
	
	public boolean saveCAproduct(CAproducts caproducts);
}
