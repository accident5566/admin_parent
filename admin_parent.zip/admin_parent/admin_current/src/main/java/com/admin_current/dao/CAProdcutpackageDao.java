package com.admin_current.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.CAProdcutpackage;

public interface CAProdcutpackageDao extends BaseMapper<CAProdcutpackage>{

}
