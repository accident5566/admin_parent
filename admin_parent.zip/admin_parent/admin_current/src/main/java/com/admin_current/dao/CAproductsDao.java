package com.admin_current.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.CAproducts;

public interface CAproductsDao extends BaseMapper<CAproducts>{

}
