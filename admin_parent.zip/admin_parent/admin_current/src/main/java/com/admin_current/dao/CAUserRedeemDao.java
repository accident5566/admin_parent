package com.admin_current.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_current.dto.response.GetUserRedeemResponse;
public interface CAUserRedeemDao extends BaseMapper<GetUserRedeemResponse>{

}
