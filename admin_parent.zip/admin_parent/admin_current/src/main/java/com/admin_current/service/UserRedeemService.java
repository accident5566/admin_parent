package com.admin_current.service;

import java.util.List;

import com.admin_base.mybatis.plug.PageParameter;
import com.admin_current.dto.response.GetUserRedeemResponse;

public interface UserRedeemService {

	public List<GetUserRedeemResponse> searchUserRedeemByPage(GetUserRedeemResponse userRedeem,PageParameter pageView);
}
