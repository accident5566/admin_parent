package com.admin_current.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.CAproductsHistory;

public interface CAproductsHistoryDao extends BaseMapper<CAproductsHistory>{

}
