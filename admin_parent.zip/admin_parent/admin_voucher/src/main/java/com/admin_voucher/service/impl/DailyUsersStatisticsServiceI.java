package com.admin_voucher.service.impl;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_voucher.dao.DailyUsersStatisticsDao;
import com.admin_voucher.service.DailyUsersStatisticsService;
import com.admin_base.dto.response.InviteeInfoDTOResult;
import com.admin_base.model.DailyUsersStatistics;
import com.admin_base.model.Orders;
import com.admin_base.model.Users;
import com.admin_base.mybatis.plug.PageParameter;

/***
 * �û�ͳ�ƽӿ�ʵ��
 * @author guxiaojun
 * @Date��2015-11-11
 */
@Service
public class DailyUsersStatisticsServiceI implements DailyUsersStatisticsService {

	
	@Autowired 
	private DailyUsersStatisticsDao dailyUsersStatisticsDao;

	@Override
	public boolean saveDailyUsersStatistics() {
		//��ȡ��ǰ��ǰһ������
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		Date date = cal.getTime();
		//����ͳ��
		DailyUsersStatistics yiLian = new DailyUsersStatistics();
		//����ͳ��
		DailyUsersStatistics yinJia = new DailyUsersStatistics();
		//����׹��û�����
		int YinJiaFirst=0;
		int YiLianFirst=0;
		List<Users> firstUsers = dailyUsersStatisticsDao.getFirstPurchaser();
		for(Users u:firstUsers){
			if(u.getSourceType()=="LAMI"){
				YinJiaFirst++;
			}
			else
			{
				YiLianFirst++;
			}
		}
		yiLian.setFirstPurchase(YiLianFirst);
		yinJia.setFirstPurchase(YinJiaFirst);
		// ͳ���û�ע����Ϣ
		List<Users> usersRigister = null;
		usersRigister = dailyUsersStatisticsDao.getUsersRegisterInformation();
		//ͳ���û���֤��Ϣ
		List<Users> usersVerified = null;
		usersVerified = dailyUsersStatisticsDao.getUsersVerifiedTimeInformation();
		//ͳ�ƶ��������ܶ�
		List<Orders> order = null;
		order = dailyUsersStatisticsDao.getOrderInformation();
		//��װ��������������
		yiLian.setDate(date);
		yiLian.setSource(10);
		yinJia.setDate(date);
		yinJia.setSource(20);
		//��װע���û���
		for(Users u:usersRigister){
			if(u.getSourceType()==null){
				yiLian.setRegisterQuantity(u.getDailyUserQuantity());
			}
			else{
				 yinJia.setRegisterQuantity(u.getDailyUserQuantity());
			}
		}
		//��װ��֤�û���
		for(Users u:usersVerified){
			if(u.getSourceType()==null){
				yiLian.setAuthUserQuantity(u.getAuthUserQuantity());
			}
			else{
				 yinJia.setAuthUserQuantity(u.getAuthUserQuantity());
			}
		}
		//��װ�������Լ������ܶ�
		if(order.size()>0){
		yiLian.setOrdersQuantity(order.get(0).getOrderQuantity());
		yiLian.setOrdersAmount(order.get(0).getOrderAmount());
		}
		if(order.size()>1){
		yinJia.setOrdersQuantity(order.get(1).getOrderQuantity());
		yinJia.setOrdersAmount(order.get(1).getOrderAmount());
		}
		//��������
		Integer yiLianCount = dailyUsersStatisticsDao.save(yiLian);
		Integer yinJiaCount = dailyUsersStatisticsDao.save(yinJia);
		if(yinJiaCount.intValue() <= 0 && yiLianCount.intValue() <= 0){
			return false;
		}
		else{
			return true;
		}
	}

	@Override
	public List<DailyUsersStatistics> getDailyUsersStatistics(PageParameter pageView, DailyUsersStatistics dailyUsersStatistics) {
		// ��ѯÿ��ͳ����Ϣ
		List<DailyUsersStatistics> dailyList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", dailyUsersStatistics);
		parameterMap.put("page", pageView);
		dailyList =dailyUsersStatisticsDao.getDailyUsersStatisticsByPage(parameterMap);
		return dailyList;
	}
	
	

}
