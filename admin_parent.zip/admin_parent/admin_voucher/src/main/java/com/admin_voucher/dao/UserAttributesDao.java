package com.admin_voucher.dao;

import java.util.List;
import java.util.Map;

import com.admin_base.dao.BaseMapper;
import com.admin_base.dto.response.InviteeInfoDTOResult;
import com.admin_base.dto.response.InviterInfoDTOResult;

public interface UserAttributesDao extends BaseMapper<InviterInfoDTOResult>{

	List<InviteeInfoDTOResult> getInviteeInfoByPage(Map<String, Object> parameterMap);

}
