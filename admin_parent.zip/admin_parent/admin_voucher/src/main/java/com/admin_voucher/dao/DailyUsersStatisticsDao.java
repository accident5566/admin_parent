package com.admin_voucher.dao;

import java.util.List;
import java.util.Map;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.DailyUsersStatistics;
import com.admin_base.model.Orders;
import com.admin_base.model.Users;



public interface DailyUsersStatisticsDao extends BaseMapper<DailyUsersStatistics>{
		
	public List<Orders> getOrderInformation();
	
	public List<Users> getUsersRegisterInformation();
	
	public List<Users> getUsersVerifiedTimeInformation();
	
	public List<DailyUsersStatistics> getDailyUsersStatisticsByPage(Map<String, Object> parameterMap);
	
	public List<Users> getFirstPurchaser();

}
