package com.admin_voucher.controller;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.admin_voucher.service.Activity_OCT_StatisticService;

/**
 * 
 * @author guxiaojun
 * @date 2015-10-15
 */
@Controller
@RequestMapping("/activity_OCT_StatisticController")
public class Activity_OCT_StatisticController {
	
	@Autowired private Activity_OCT_StatisticService activity_OCT_StatisticServiceImpl;
	
	@RequestMapping(value="/getDailyStatistic",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getDailyStatistic(HttpServletRequest request, HttpServletResponse response){
		
		Date currentTime = new Date();
		ModelAndView model = new ModelAndView();
		model.addObject("DailyPurchaseStatistic", activity_OCT_StatisticServiceImpl.getDailyPurchaseStatistic());
		model.addObject("HisPurchaseStatistic", activity_OCT_StatisticServiceImpl.getHisPurchaseStatistic());
		model.addObject("DailyVoucherStatistic", activity_OCT_StatisticServiceImpl.getDailyVoucherStatistic());
		model.addObject("HisVoucherStatistic",activity_OCT_StatisticServiceImpl.getHisVoucherStatistic() );
		model.addObject("currentTime", currentTime);
		model.setViewName("ActivityOct/activityTotalStatistic/index");
		return model;
	}
}

