package com.admin_voucher.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.model.Voucher;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_voucher.dao.VoucherDao;
import com.admin_voucher.service.VoucherService;
/**
 * ����ȯServiceʵ��
 * @author guxiaojun
 * @Date 2015-10-13
 */

@Service
public class VoucherServiceI implements VoucherService {

	@Autowired private VoucherDao voucherDao;
	
	@Override
	public List<Voucher> getVoucherByPage(PageParameter pageView,
			Voucher voucher) {
		List<Voucher> voucherList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", voucher);
		parameterMap.put("page", pageView);
		voucherList = voucherDao.getByPage(parameterMap);
		return voucherList;
	}


	@Override
	public List<Voucher> getPersonalVoucherByPage(PageParameter pageView,
			Voucher voucher) {
		List<Voucher> personalVoucherList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", voucher);
		parameterMap.put("page", pageView);
		personalVoucherList = voucherDao.getPersonalVoucherByPage(parameterMap);
		return personalVoucherList;
	}

}
