package com.admin_voucher.dao;

import java.util.List;
import java.util.Map;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.Voucher;
public interface VoucherDao extends BaseMapper<Voucher>{

	public List<Voucher> getPersonalVoucherByPage(Map<String, Object> parameterMap);

}
