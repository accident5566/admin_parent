package com.admin_voucher.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.constant.ActivityOCTConstant;
import com.admin_base.dto.response.InviteeInfoDTOResult;
import com.admin_base.dto.response.InviterInfoDTOResult;
import com.admin_base.model.Voucher;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_voucher.service.UserAttributesService;
import com.admin_voucher.service.VoucherService;
/***
 * 10���ƹ�Control
 * @author guxiaojun
 * @Date 2015-10-13
 */
@Controller("activity_OCT_Controller")
@RequestMapping("/activity_OCT_Info")
public class Activity_OCT_Controller {
   
	@Autowired private VoucherService voucherServiceImpl;
	@Autowired private UserAttributesService userAttributesServiceImpl;
	
	@RequestMapping(value="/getVoucherInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getVoucherInfo(HttpServletRequest request, HttpServletResponse response,Voucher voucher){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");	
		Integer status = 0;
		if(voucher == null){
			voucher = new Voucher();
		}
		if(voucher.getUseState()!=null){
		    status = Integer.valueOf(voucher.getUseState());
		}
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("voucherStatus",status);
		model.addObject("effectiveTime",voucher.getEffectiveTime());
		model.addObject("voucherList",voucherServiceImpl.getVoucherByPage(pageView, voucher));
		model.addObject("pageView",pageView);
		model.addObject("voucherStatusList", ActivityOCTConstant.getComUtil());
		model.setViewName("ActivityOct/activityManagement/voucherManager");
		return model;
	}	
	
	@RequestMapping(value="/getInviterInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getInviterInfo(HttpServletRequest request, HttpServletResponse response,InviterInfoDTOResult inviter) throws UnsupportedEncodingException{
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");	
		if(inviter == null){
			inviter = new InviterInfoDTOResult();
		}
		System.out.print(inviter.getRealName());
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("pageView",pageView);
		model.addObject("realName",inviter.getRealName());
		model.addObject("inviterList",userAttributesServiceImpl.getUserAttributesByPage(pageView, inviter));
		model.setViewName("ActivityOct/activityManagement/inviterManager");
		return model;	
	}
	
	@RequestMapping(value="/getVoucherDetailInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getVoucherDetailInfo(HttpServletRequest request, HttpServletResponse response){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");	
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		String userIdentifier  = request.getParameter("userIdentifier");
		Voucher voucher = new Voucher();
		voucher.setUserIdentifier(userIdentifier);
		ModelAndView model = new ModelAndView();
		model.addObject("pageView",pageView);
		model.addObject("personalVoucherList",voucherServiceImpl.getPersonalVoucherByPage(pageView, voucher));
		model.setViewName("ActivityOct/activityManagement/inviterVoucherDetail");
		return model;
	}
	
	@RequestMapping(value="/getInviteeDetailInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getInviteeDetailInfo(HttpServletRequest request, HttpServletResponse response){
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");	
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		String userIdentifier  = request.getParameter("userIdentifier");
		InviteeInfoDTOResult invitee = new InviteeInfoDTOResult();
		invitee.setUserIdentifier(userIdentifier);
		ModelAndView model = new ModelAndView();
		model.addObject("pageView",pageView);
		model.addObject("inviteeList",userAttributesServiceImpl.getInviteeInfoBypage(pageView, invitee));
		model.setViewName("ActivityOct/activityManagement/inviteeDetail");
		return model;	
	}
}
