package com.admin_voucher.service;

import java.util.Date;

import com.admin_base.dto.response.ActivityOCTStatisticDTOResult;

/**
 * 10�»��Ӫservice�ӿ�
 * @author guxiaojun
 * @Date 2015-10-15
 */
public interface Activity_OCT_StatisticService {


	public ActivityOCTStatisticDTOResult getDailyPurchaseStatistic();
	
	public ActivityOCTStatisticDTOResult getHisPurchaseStatistic();
	
	public ActivityOCTStatisticDTOResult getDailyVoucherStatistic();
	
	public ActivityOCTStatisticDTOResult getHisVoucherStatistic();
		
}
