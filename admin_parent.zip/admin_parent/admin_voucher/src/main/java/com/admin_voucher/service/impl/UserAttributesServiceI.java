package com.admin_voucher.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.dto.response.InviteeInfoDTOResult;
import com.admin_base.dto.response.InviterInfoDTOResult;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_voucher.dao.UserAttributesDao;
import com.admin_voucher.service.UserAttributesService;
/**
 * ������Serviceʵ��
 * @author guxiaojun
 * @Date 2015-10-13
 */

@Service
public class UserAttributesServiceI implements UserAttributesService {

	@Autowired private UserAttributesDao userAttributesDao;
	
	@Override
	public List<InviterInfoDTOResult> getUserAttributesByPage(PageParameter pageView,
			InviterInfoDTOResult inviter) {
		List<InviterInfoDTOResult> inviterList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", inviter);
		parameterMap.put("page", pageView);
		inviterList = userAttributesDao.getByPage(parameterMap);
		return inviterList;
	}

	@Override
	public List<InviteeInfoDTOResult> getInviteeInfoBypage(
			PageParameter pageView, InviteeInfoDTOResult invitee) {
		List<InviteeInfoDTOResult> inviteeList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		parameterMap.put("t", invitee);
		parameterMap.put("page", pageView);
		inviteeList = userAttributesDao.getInviteeInfoByPage(parameterMap);
		return inviteeList;
	}
}
