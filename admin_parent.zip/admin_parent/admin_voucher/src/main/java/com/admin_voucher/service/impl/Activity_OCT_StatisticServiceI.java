package com.admin_voucher.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.admin_base.dto.response.ActivityOCTStatisticDTOResult;
import com.admin_voucher.dao.Activity_OCT_StatisticDao;
import com.admin_voucher.service.Activity_OCT_StatisticService;

/**
 * ��Ӫ��Ϣservice�ӿڶ���ʵ��
 * @author guxiaojun
 * @Date 2015-10-15
 */

@Service
public class Activity_OCT_StatisticServiceI implements Activity_OCT_StatisticService{

	@Autowired private Activity_OCT_StatisticDao activity_OCT_StatisticDao;
	
	@Override
	public ActivityOCTStatisticDTOResult getDailyPurchaseStatistic() {
		return activity_OCT_StatisticDao.getDailyPurchaseStatistic();
	}

	@Override
	public ActivityOCTStatisticDTOResult getHisPurchaseStatistic() {
		return activity_OCT_StatisticDao.getHisPurchaseStatistic();
	}

	@Override
	public ActivityOCTStatisticDTOResult getDailyVoucherStatistic() {
		ActivityOCTStatisticDTOResult result = new ActivityOCTStatisticDTOResult();
		result.setDailyVoucherNum(activity_OCT_StatisticDao.getDailySendVoucherStatistic());
		result.setDailyUsedVoucherNum(activity_OCT_StatisticDao.getDailyUsedVoucherStatistic());
		return result;
	}

	@Override
	public ActivityOCTStatisticDTOResult getHisVoucherStatistic() {
		ActivityOCTStatisticDTOResult result = new ActivityOCTStatisticDTOResult();
		result.setHisVoucherNum(activity_OCT_StatisticDao.getHisSendVoucherStatistic());
		result.setHisUsedVoucherNum(activity_OCT_StatisticDao.getHisUsedVoucherStatistic());
		return result;
	}

}
