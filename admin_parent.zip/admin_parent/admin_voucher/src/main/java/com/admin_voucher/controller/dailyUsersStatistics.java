package com.admin_voucher.controller;

import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.DailyUsersStatistics;
import com.admin_base.model.Voucher;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_voucher.service.DailyUsersStatisticsService;
import com.admin_voucher.service.VoucherService;

/**
 * 
 * @author guxiaojun
 * @date 2015-11-11
 */
@Controller
@RequestMapping("/dailyUsersStatistics")
public class dailyUsersStatistics {
	
	@Autowired private DailyUsersStatisticsService dailyUsersStatisticsServiceI;
	
	@RequestMapping(value="/getDailyUsersStatistics",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView getDailyUsersStatistics(HttpServletRequest request, HttpServletResponse response,DailyUsersStatistics dailyUsersStatistics){
		if(dailyUsersStatistics == null){
			dailyUsersStatistics = new DailyUsersStatistics();
		}
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		Date date = cal.getTime();
		ModelAndView model = new ModelAndView();
		model.addObject("userList",dailyUsersStatisticsServiceI.getDailyUsersStatistics(pageView, dailyUsersStatistics));
		model.addObject("date", date);
		model.addObject("pageView",pageView);
		model.setViewName("ActivityOct/activityTotalStatistic/dailyUsersStatistics");
		return model;
	}
}
