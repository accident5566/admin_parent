package com.admin_voucher.service;

import java.util.List;
import com.admin_base.model.Voucher;
import com.admin_base.mybatis.plug.PageParameter;

public interface VoucherService {
          
	public List<Voucher> getVoucherByPage(PageParameter pageView, Voucher voucher);
	
	public List<Voucher> getPersonalVoucherByPage(PageParameter pageView, Voucher voucher);
	
}
