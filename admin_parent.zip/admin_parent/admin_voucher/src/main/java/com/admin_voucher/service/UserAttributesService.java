package com.admin_voucher.service;

import java.util.List;
import com.admin_base.dto.response.InviteeInfoDTOResult;
import com.admin_base.dto.response.InviterInfoDTOResult;
import com.admin_base.mybatis.plug.PageParameter;

public interface UserAttributesService {
        
	public List<InviterInfoDTOResult> getUserAttributesByPage(PageParameter pageView, InviterInfoDTOResult inviter);
	
	public List<InviteeInfoDTOResult> getInviteeInfoBypage(PageParameter pageView,InviteeInfoDTOResult invitee);
	
}
