package com.admin_voucher.quartz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.admin_voucher.service.DailyUsersStatisticsService;

/***
 * ��ʱ����ͳ��ÿ���û���Ϣ
 * @author guxiaojun
 * @Date��2015-11-11
 */
@Service
public class DailyUsersStatisticsBatchQuery {
	
	@Autowired 
	private DailyUsersStatisticsService dailyUsersStatisticsServiceI;

	
	public void doQuartz(){
		dailyUsersStatisticsServiceI.saveDailyUsersStatistics();
		

    }
}
