package com.admin_fixed.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.admin_base.model.Users;
import com.admin_base.util.SystemProperty;

@Controller("loginController")
@RequestMapping("/login")
public class LoginController {
	@RequestMapping(value="/checkLogin",method = RequestMethod.POST)
	public void checkLoginUser(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("checkLoginForm") Users user) throws IOException, ServletException{
		String name = SystemProperty.getProperty("login.name");
		String password = SystemProperty.getProperty("login.password");
		if(user != null && user.getLoginname().equals(name) && user.getEncryptedpassword().equals(password)){
			request.getSession().setAttribute("title",SystemProperty.getProperty("page.title.text.one"));
			 request.getRequestDispatcher("/static/jsp/mainframe.jsp").forward(request, response);
		}else{
		   response.sendRedirect("../welcome.jsp");
		
		}
	} 
}
