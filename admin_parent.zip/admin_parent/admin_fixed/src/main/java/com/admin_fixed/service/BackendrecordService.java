package com.admin_fixed.service;

import com.admin_base.model.Backendrecord;

public interface BackendrecordService {

	public boolean saveBackendRecords(Backendrecord backendrecord) throws Exception;
	
	public boolean updateBackendPayStatus(Backendrecord backendrecord);
	
	
}
