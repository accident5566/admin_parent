
package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.ProductDesc;

public interface ProductDescDao extends BaseMapper<ProductDesc>{

}
