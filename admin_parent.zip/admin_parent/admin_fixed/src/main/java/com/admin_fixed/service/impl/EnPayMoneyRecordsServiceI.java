package com.admin_fixed.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.admin_base.constant.DateConstant;
import com.admin_base.constant.ErrorMessage;
import com.admin_base.constant.ProductContent;
import com.admin_base.constant.ProductType;
import com.admin_base.dto.request.EnPayMoneyDTO;
import com.admin_base.dto.request.ReconciliationDTO;
import com.admin_base.dto.request.SreceivedPaymentDTO;
import com.admin_base.dto.response.EnPayMoneyBase;
import com.admin_base.dto.response.EnPayMoneyDTOResult;
import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.dto.response.PayMoneyDTOResult;
import com.admin_base.dto.yl.CommonModel;
import com.admin_base.dto.yl.CommonMsg;
import com.admin_base.model.EnterprisePayMoneyRecords;
import com.admin_base.model.Product;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.DateUtil;
import com.admin_base.util.HttpUtil;
import com.admin_base.util.MessageResult;
import com.admin_base.util.ProductNoGenerateUtil;
import com.admin_fixed.dao.EnPayMoneyRecordsDao;
import com.admin_fixed.service.EnPayMoneyRecordsService;
import com.admin_fixed.service.OrderService;
import com.admin_fixed.service.ProductService;

@Service
public class EnPayMoneyRecordsServiceI implements EnPayMoneyRecordsService {
	private static final Logger log = Logger.getLogger(EnPayMoneyRecordsServiceI.class);
	@Autowired private EnPayMoneyRecordsDao enDaoI;
	@Autowired private ProductService productServiceI;
	@Autowired private OrderService orderServiceI;
	private MessageResult messageResult;
	@Override
	public boolean saveEnPayMoneyRecords(EnterprisePayMoneyRecords enpayRecords) {
		try {
			Integer returnCode = enDaoI.save(enpayRecords);
			if(returnCode <= 0){
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		  return false;
		}
		return true;
	}

	@Override
	public List<EnterprisePayMoneyRecords> getEnPayMoneyRecordsByPage(
			PageParameter pageView, EnterprisePayMoneyRecords proenter) {
		List<EnterprisePayMoneyRecords> enpaymoneyList = null;
		try {
			Map<String,Object> parameterMap = new HashMap<String,Object>();
			parameterMap.put("t", proenter);
			parameterMap.put("page", pageView);
			enpaymoneyList = enDaoI.getByPage(parameterMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return enpaymoneyList;
	}
	@Override
	public MessageResult enterprisePayMoneyServiceYJ(String productIdentifier)
			throws ParseException, JsonProcessingException, IOException {
		try{
		messageResult = new MessageResult();
		Map<String,Object> param = null;
		if(StringUtils.isEmpty(productIdentifier)){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_ONE_JY, productIdentifier));
			return messageResult;
		}
		
		Product product = productServiceI.getProductForAccount(new Product(ProductContent.CHECKSTATUS_THREE,productIdentifier));
		if(StringUtils.isEmpty(product)){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_TWO_JY, productIdentifier));
			return messageResult;
		}
		
		EnterprisePayMoneyRecords enpayYinJia =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,20));
		if(enpayYinJia != null){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_THREE_JY, productIdentifier));
			return messageResult;
		}
		
		if(product.getCheckStatus() != ProductContent.CHECKSTATUS_THREE){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_FOUR_JY, productIdentifier));
			return messageResult;
		}
		String batchNo = ProductNoGenerateUtil.getBatchNo(ProductType.returnFirstName(ProductType.getProList(), String.valueOf(product.getProductType())));
		EnPayMoneyDTO enPayMoneydtoj = getEnPayMoneyInfo(new EnPayMoneyDTO(20,productIdentifier));
		enPayMoneydtoj.setBatchNo(batchNo);
		enPayMoneydtoj.setPaySource(20);
		enPayMoneydtoj.setProductIdentifier(productIdentifier);
		if(enPayMoneydtoj.getTotalSuccessOrderMoney().intValue() <= 0){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_FIVE_JY, enPayMoneydtoj.getTotalSuccessOrderMoney().intValue(),productIdentifier));
			return messageResult;
		}
		param = returnEnPayMoneyYinJia(enPayMoneydtoj);
		boolean flag = (boolean) param.get("boolean");
		String message = String.valueOf(param.get("message"));
		if(!flag){
			   enPayMoneydtoj.setPayStatus(2);
			   flag = saveEnPayMoneyRecords(new EnterprisePayMoneyRecords(enPayMoneydtoj));
				if(!flag){
					messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SIX_JY, productIdentifier));
					return messageResult;
				}
				messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEVEN_JY,productIdentifier,message));
				return messageResult;
		}else{
				flag = saveEnPayMoneyRecords(new EnterprisePayMoneyRecords(enPayMoneydtoj));
				if(!flag){
					messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_EIGHT_JY, productIdentifier));
					return messageResult;
				}
		}
		}catch (Exception e) {
			e.printStackTrace();
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_NINE_JY, productIdentifier,e.getMessage()));
			return messageResult;
		}
		messageResult.setResultCode("200");
		return messageResult;
	}
	
	@Override
	public MessageResult enterprisePayMoneyServiceYL(String productIdentifier)
			throws ParseException, JsonProcessingException, IOException {
		messageResult = new MessageResult();
		try{
		Map<String,Object> param = null;
		if(StringUtils.isEmpty(productIdentifier)){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_ONE_YL, productIdentifier));
			return messageResult;
		}
		
		Product product = productServiceI.getProductForAccount(new Product(ProductContent.CHECKSTATUS_THREE,productIdentifier));
		if(StringUtils.isEmpty(product)){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_TWO_YL, productIdentifier));
			return messageResult;
		}
		EnterprisePayMoneyRecords enpayYiLian =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,10));
		if(enpayYiLian != null){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_THREE_YL, productIdentifier));
			return messageResult;
		}
		
		if(product.getCheckStatus() != ProductContent.CHECKSTATUS_THREE){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_FOUR_YL, productIdentifier));
			return messageResult;
		}
		String batchNo = ProductNoGenerateUtil.getBatchNo(ProductType.returnFirstName(ProductType.getProList(), String.valueOf(product.getProductType())));
		EnPayMoneyDTO enPayMoneydtol = getEnPayMoneyInfo(new EnPayMoneyDTO(10,productIdentifier));
		enPayMoneydtol.setBatchNo(batchNo);
		enPayMoneydtol.setPaySource(10);
		enPayMoneydtol.setProductIdentifier(productIdentifier);
		if(enPayMoneydtol.getTotalSuccessOrderMoney().intValue() <= 0){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_FIVE_YL, enPayMoneydtol.getTotalSuccessOrderMoney().intValue(),productIdentifier));
			return messageResult;
		}
		param = retrunEnPayMoneyYiLian(enPayMoneydtol);
		boolean flag = (boolean) param.get("boolean");
		String message = String.valueOf(param.get("message"));
		if(!flag){
			   enPayMoneydtol.setPayStatus(2);
			   flag = saveEnPayMoneyRecords(new EnterprisePayMoneyRecords(enPayMoneydtol));
				if(!flag){
					messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SIX_YL, productIdentifier));
					return messageResult;
				}
				messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEVEN_YL, productIdentifier,message));
				return messageResult;
		}else{
				flag = saveEnPayMoneyRecords(new EnterprisePayMoneyRecords(enPayMoneydtol));
				if(!flag){
					messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_EIGHT_YL, productIdentifier));
					return messageResult;
				}
		}
		}catch(Exception e){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_NINE_YL, productIdentifier,e.getMessage()));
			return messageResult;
		}
		messageResult.setResultCode("200");
		return messageResult;
	}


	public Map<String,Object>  retrunEnPayMoneyYiLian(EnPayMoneyDTO enPayMoneydtol) throws ParseException, JsonProcessingException, IOException{
		    CommonModel com = getCommonModel(enPayMoneydtol,enPayMoneydtol.getBatchNo());
		    Map<String,Object> pamaram = new HashMap<String,Object>();
			String jsonStrs = JSONObject.fromObject(com).toString();
			log.info("�ص������ӿ�JSON�ַ���:"+jsonStrs);
			Map<String,Object> responseResult = null;
			HttpUtil httpUtil = new HttpUtil();
			System.out.println("p="+jsonStrs);
			responseResult = httpUtil.sendHttpRequest("pay.gateway", "pay.yilian.batch.return","p="+jsonStrs, "POST");
			String resResult = responseResult.get("respContent").toString();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode json = mapper.readTree(resResult);
			String resultCode = json.path("resultCode").getTextValue();
			String message = json.path("message").getTextValue();
			if(resultCode.equals("0000")){
				pamaram.put("boolean", true);
				pamaram.put("message", message);
			}else{
				pamaram.put("boolean", false);
				pamaram.put("message", message);
			}
			return pamaram;
	}
	
	public Map<String,Object>  returnEnPayMoneyYinJia(EnPayMoneyDTO enPayMoneydtoj) throws ParseException, JsonProcessingException, IOException{
		PayMoneyDTOResult payMoney = new PayMoneyDTOResult(enPayMoneydtoj);
		Map<String,Object> pamaram = new HashMap<String,Object>();
		Map<String,Object> responseResult = null;
		HttpUtil httpUtil = new HttpUtil();
		String jsonStr = "merchantsn="+payMoney.getMerchantsn()+"&name="+payMoney.getName()+"&mobile="+payMoney.getMobile()+"&bankname="+payMoney.getBankname()+"&account="+payMoney.getAccount()+"&amount="+payMoney.getAmount()+"&createdAt="+DateUtil.GetStringDate(new Date(),DateConstant.DATE_FORMAT_YMDHMS_ONE);
		log.info("�ص������ӿ�JSON�ַ���:"+jsonStr);
		responseResult = httpUtil.sendHttpRequest("pay.gateway", "pay.yinjia.business.payment",jsonStr, "POST");
		String resResult = responseResult.get("respContent").toString();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode json = mapper.readTree(resResult);
		String resultCode = json.path("resultCode").getTextValue();
		String message = json.path("message").getTextValue();
		if(resultCode.equals("0000")){
			pamaram.put("boolean", true);
			pamaram.put("message", message);
			return pamaram;
		}else{
			pamaram.put("boolean", false);
			pamaram.put("message", message);
			return pamaram;
		}
	}
	
	public CommonModel getCommonModel(EnPayMoneyDTO enPayMoneydto,String batchNo) throws ParseException{
		    CommonModel com = new CommonModel();
			com.setBatchNo(batchNo);
			List<CommonMsg> msgList = new ArrayList<CommonMsg>();
			CommonMsg commsg = new CommonMsg(enPayMoneydto);
			msgList.add(commsg);
			com.setTransDetails(msgList);
			return com;
	}
	@Override
	public EnPayMoneyDTO getEnPayMoneyInfo(EnPayMoneyDTO enpayMoneyDTO) {
		EnPayMoneyDTO enPayMoneydto = null;
		try {
			enPayMoneydto = enDaoI.searchEnPayMoneyInfo(enpayMoneyDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return enPayMoneydto;
	}

	@Override
	public MessageResult enterprisePayMoneySearch(String productIdentifier) throws JsonProcessingException, IOException {
		log.info("��ҵ����ѯ��ʼ-----start");
		messageResult = new MessageResult();
		Map<String,Object> param = null;
		if(StringUtils.isEmpty(productIdentifier)){
			messageResult.setMessage("��Ʒ��uuid��:"+productIdentifier+"\n��������½�����ҵ����ѯ����");
			return messageResult;
		}
		Product product = productServiceI.getProductForAccount(new Product(ProductContent.CHECKSTATUS_FOUR,productIdentifier));
		if(StringUtils.isEmpty(product)){
			messageResult.setMessage("����ҵ����ѯ�����쳣�������ڲ�ƷuuidΪ:"+productIdentifier+"�Ĳ�Ʒ��Ϣ��������½��д�����");
			return messageResult;
		}
		if(product.getCheckStatus() != ProductContent.CHECKSTATUS_FOUR){
			messageResult.setMessage("����ҵ����ѯ�����쳣���ò�Ʒ��ҵ���û�гɹ����ܽ��д���ѯ����\n��Ʒ��uuid��:"+productIdentifier+"�Ĳ�Ʒ��Ϣ��������½��д�����");
			return messageResult;
		}
		EnterprisePayMoneyRecords enpayRecordsYiLian = getEnpayMoneyRecords(new EnterprisePayMoneyRecords(productIdentifier,10));
		EnterprisePayMoneyRecords enpayRecordsYinJia = getEnpayMoneyRecords(new EnterprisePayMoneyRecords(productIdentifier,20));
		if(enpayRecordsYiLian != null){
			param = retrunEnPayMoneyYiLianQuery(enpayRecordsYiLian.getBatchNo());
			String payResult = (String)param.get("payResult");
			boolean pflag = (boolean)param.get("boolean");
			if(!pflag){
 		        messageResult.setMessage("����ҵ���--�������ӿڵ���ִ��ʧ��ʧ�ܵ�������Ϣ��:"+payResult);
				return messageResult;
			}
			boolean returnFlag = updateEnpayMoneyRecords(new EnterprisePayMoneyRecords(productIdentifier, 10, payResult));
			if(!returnFlag){
				messageResult.setMessage("���޸Ĵ���¼��Ϣʧ�ܡ�\n�����Դ�ǡ��������������payResult��Ʒ��uuid1��\n"+productIdentifier);
				return messageResult;
			}
		}
		if(enpayRecordsYinJia != null){
			param = retrunEnPayMoneyYinJiaQuery(enpayRecordsYinJia.getBatchNo());
			String payResult = (String)param.get("payResult");
			boolean returnFlag = updateEnpayMoneyRecords(new EnterprisePayMoneyRecords(productIdentifier, 20, payResult));
		    if(!returnFlag){
				messageResult.setMessage("���޸Ĵ���¼��Ϣʧ�ܡ�\n�����Դ�ǡ����Ρ��������payResult��Ʒ��uuid1��\n"+productIdentifier);
				return messageResult;
		    }
		}
		return null;
	}

	public Map<String,Object>  retrunEnPayMoneyYiLianQuery(String batchNo) throws JsonProcessingException, IOException{
		HttpUtil httpUtil = new HttpUtil();
		Map<String,Object> param = new HashMap<String,Object>();
		Map<String,Object> responseResult = httpUtil.sendHttpRequest("pay.gateway", "pay.yilian.batch.return.query","batchNo="+batchNo, "POST");
		String resResult = responseResult.get("respContent").toString();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode json = mapper.readTree(resResult);
		String resultCode = json.path("resultCode").getTextValue();
		String message = json.path("message").getTextValue();
		if(!resultCode.equals("0000")){
			param.put("boolean", false);
			return param;
		}
		JsonNode jsonNode = json.path("properties");
		String jsonStr = jsonNode.toString();
		JSONArray jsona =  JSONArray.fromObject(jsonStr);
		List<CommonModel> list = (List<CommonModel>) JSONArray.toCollection(jsona, CommonModel.class);
		List<CommonMsg> comList = list.get(0).getTransDetails();
		String remark = comList.get(0).getRemark();
		param.put("payResult", remark);
		param.put("boolean", true);
		return param;
	}
	
    public Map<String,Object>  retrunEnPayMoneyYinJiaQuery(String batchNo){
		return null;
	}
	@Override
	public EnterprisePayMoneyRecords getEnpayMoneyRecords(
			EnterprisePayMoneyRecords proenter) {
		EnterprisePayMoneyRecords enpayRecords = null;
		try {
			enpayRecords = enDaoI.getInfo(proenter);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return enpayRecords;
	}
	
	@Override
	public boolean updateEnpayMoneyRecords(EnterprisePayMoneyRecords proenter) {
		
		
		return false;
	}

	@Override
	public EnPayMoneyBase showPayMoneyInfo(String productIdentifier,String productNo) {
		EnPayMoneyBase en = new EnPayMoneyBase();
		try {
			List<OrderDetailDTOResult> orderListYiLian = orderServiceI.getSuccessOrdersList(new SreceivedPaymentDTO(productIdentifier,10));
			List<OrderDetailDTOResult> orderListYinJia = orderServiceI.getSuccessOrdersList(new SreceivedPaymentDTO(productIdentifier,20));
			Product product = productServiceI.getProByNo(productNo);
			if(product == null){
				return null;
			}
			en.setProductNo(productNo);
			en.setToSuccessMoney(new BigDecimal(product.getAmount()));
			List<EnPayMoneyDTOResult> enPayMoList = new ArrayList<EnPayMoneyDTOResult>();
			EnPayMoneyDTOResult  enpaymoney = null;
			BigDecimal yilianmoney = new BigDecimal(0);
			BigDecimal yinjiamoney = new BigDecimal(0);
			EnterprisePayMoneyRecords enPayMoneydtol =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,10));
			EnterprisePayMoneyRecords enPayMoneydtoj =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,20));
			Integer lok = null;
			Integer lokc = null;
			Integer jok = null;
			Integer jokc = null;
			if(enPayMoneydtol != null){
				 lok = enPayMoneydtol.getPayStatus();
				 lokc = enPayMoneydtol.getCharacteristic();
			}
			if(enPayMoneydtoj != null){
				 jok = enPayMoneydtoj.getPayStatus();
				 jokc = enPayMoneydtoj.getCharacteristic();
			}
			for(OrderDetailDTOResult yilian : orderListYiLian){
				yilianmoney = yilianmoney.add(yilian.getAmount());
			}
			for(OrderDetailDTOResult yinjia : orderListYinJia){
				yinjiamoney = yinjiamoney.add(yinjia.getAmount());
			}
			if(orderListYiLian != null && orderListYiLian.size() > 0){
				enpaymoney = new EnPayMoneyDTOResult("10", orderListYiLian.size(),yilianmoney,lok,lokc);
				enPayMoList.add(enpaymoney);
			}
			if(orderListYinJia != null && orderListYinJia.size() > 0){
				enpaymoney = new EnPayMoneyDTOResult("20", orderListYinJia.size(),yinjiamoney,jok,jokc);
				enPayMoList.add(enpaymoney);
			}
			en.setEnPayMoList(enPayMoList);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return en;
	}

	@Override
	public EnterprisePayMoneyRecords getEnpayMoneyRecordsBy(
			EnterprisePayMoneyRecords proenter) {
		EnterprisePayMoneyRecords  enrecords = enDaoI.getEnpayMoneyRecordsBy(proenter);
		return enrecords;
	}

	@Override
	public MessageResult enterprisePayMoneySearchYL(String productIdentifier) throws JsonProcessingException, IOException {
		try{
		EnterprisePayMoneyRecords enPayMoneydtol =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,10));
		messageResult = new MessageResult();
		if(StringUtils.isEmpty(enPayMoneydtol) && StringUtils.isEmpty(enPayMoneydtol.getBatchNo())){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEARCH_ONE_YL, productIdentifier));
			return messageResult;
		}
		Map<String,Object> param = paymentBatchQueryServiceYL(enPayMoneydtol.getBatchNo(),productIdentifier);
		String message = String.valueOf(param.get("message"));
		boolean flag = (boolean)(param.get("boolean"));
		if(!flag){
			messageResult.setMessage(message);
			return messageResult;
		}
		}catch(Exception e){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEARCH_SIX_YL, e.getMessage()));
			return messageResult;
		}
		messageResult.setResultCode("200");
		return messageResult;
	}
	@SuppressWarnings("unchecked")
	public Map<String,Object>  paymentBatchQueryServiceYL(String batchNo,String productIdentifier) throws JsonProcessingException, IOException{
		Map<String,Object> param = new HashMap<String,Object>();
		try{
			HttpUtil httpUtil = new HttpUtil();
			Map<String,Object> responseResult = httpUtil.sendHttpRequest("pay.gateway", "pay.yilian.batch.return.query","batchNo="+batchNo, "POST");
			String resResult = responseResult.get("respContent").toString();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode json = mapper.readTree(resResult);
			String resultCode = json.path("resultCode").getTextValue();
			String message = json.path("message").getTextValue();
//			String payState = json.findValue("payState").getTextValue();
//			String remark = json.findValue("remark").getTextValue();
			if(!resultCode.equals("0000")){
				param.put("message", String.format(ErrorMessage.ENTERPRISE_SEARCH_TWO_YL, resultCode,message));
				param.put("boolean", false);
				return param;
			}
			JsonNode jsonNode = json.path("properties");
			String jsonStr = jsonNode.toString();
			JSONArray jsona =  JSONArray.fromObject(jsonStr);
			List<CommonModel> list = (List<CommonModel>) JSONArray.toCollection(jsona, CommonModel.class);
			JSONObject object = JSONObject.fromObject(list.get(0).getTransDetails().get(0));
			CommonMsg comsg= (CommonMsg) JSONObject.toBean(object, CommonMsg.class);
			if(comsg == null){
		    	param.put("message",ErrorMessage.ENTERPRISE_SEARCH_THREE_YL);
				param.put("boolean", false);
				return param;
		    }
		
		    if(comsg.getPayState().equals("0000")){
		    	 boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 10, batchNo, 1, 1,comsg.getRemark()));
		    	 if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_FOUR_YL);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    }
		    else if(comsg.getPayState().equals("00A4")){
		    	boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 10, batchNo, 3, 2,comsg.getRemark()));
		    	if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_FOUR_YL);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_SEVEN_JY);
	 			param.put("boolean", false);
	 			return param;
		    }else{
		    	boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 10, batchNo, 2, 1,comsg.getRemark()));
		    	if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_FOUR_YL);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    }
	   }catch(Exception e){
		    e.printStackTrace();
		    param.put("message", String.format(ErrorMessage.ENTERPRISE_SEARCH_FIVE_YL, e.getMessage()));
			param.put("boolean", false);
			return param; 
	   }
	    param.put("message", ErrorMessage.ENTERPRISE_SEARCH_TEN_JY);
		param.put("boolean", true);
		return param;
	}
	@Override
	public MessageResult enterprisePayMoneySearchYJ(String productIdentifier) throws JsonProcessingException, IOException {
	try{
			EnterprisePayMoneyRecords enPayMoneydtoj =  getEnpayMoneyRecordsBy(new EnterprisePayMoneyRecords(productIdentifier,20));
			messageResult = new MessageResult();
			if(StringUtils.isEmpty(enPayMoneydtoj) && StringUtils.isEmpty(enPayMoneydtoj.getBatchNo())){
				messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEARCH_ONE_JY, productIdentifier));
				return messageResult;
			}
			Map<String,Object> param = paymentBatchQueryServiceYJ(enPayMoneydtoj.getBatchNo(),productIdentifier);
			String message = String.valueOf(param.get("message"));
			boolean flag = (boolean)(param.get("boolean"));
			if(!flag){
				messageResult.setMessage(message);
				return messageResult;
			}
		}catch(Exception e){
			messageResult.setMessage(String.format(ErrorMessage.ENTERPRISE_SEARCH_NINE_YJ, e.getMessage()));
			return messageResult;
		}
		messageResult.setResultCode("200");
		return messageResult;
	}
	public Map<String,Object> paymentBatchQueryServiceYJ(String batchNo,String productIdentifier) throws JsonProcessingException, IOException{
		    
		Map<String,Object> param = new HashMap<String,Object>();
	    try{
		    HttpUtil httpUtil = new HttpUtil();
			Map<String,Object> responseResult = httpUtil.sendHttpRequest("pay.gateway", "pay.yinjia.business.Payment.query","merchantSn="+batchNo, "POST");
			String resResult = responseResult.get("respContent").toString();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode json = mapper.readTree(resResult);
			String resultCode = json.path("resultCode").getTextValue();
			String message = json.path("message").getTextValue();
			String status = json.findValue("status").asText();
			if(!resultCode.equals("0000")){
				param.put("message", String.format(ErrorMessage.ENTERPRISE_SEARCH_TWO_JY, resultCode,message,productIdentifier,batchNo));
				param.put("boolean", false);
				return param;
			}
			if(status.equals("0")){
				 boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 20, batchNo, 1, 1,ErrorMessage.ENTERPRISE_SEARCH_SUCCESS));
		    	 if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_THREE_JY);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    	  param.put("message", ErrorMessage.ENTERPRISE_SEARCH_TEN_JY);
		 		  param.put("boolean", true);
		 		  return param;
			}
			if(status.equals("1")){
				 boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 20, batchNo, 2, 1,ErrorMessage.ENTERPRISE_SEARCH_ERROR));
		    	 if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_FOUR_JY);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    	    param.put("message", ErrorMessage.ENTERPRISE_SEARCH_FIVE_JY);
		 			param.put("boolean", false);
		 			return param;
			}
			if(status.equals("2")){
				 boolean flag = updatepayStatusBy(new EnterprisePayMoneyRecords(productIdentifier, 20, batchNo, 3, 2,ErrorMessage.ENTERPRISE_SEARCH_PROCESSING));
		    	 if(!flag){
		 	    	param.put("message", ErrorMessage.ENTERPRISE_SEARCH_SIX_JY);
		 			param.put("boolean", false);
		 			return param;
		    	 }
		    	 param.put("message", ErrorMessage.ENTERPRISE_SEARCH_SEVEN_JY);
		 		 param.put("boolean", false);
		 		 return param;
			}
			if(status.equals("3")){
				    param.put("message", ErrorMessage.ENTERPRISE_SEARCH_EIGHT_JY);
		 			param.put("boolean", false);
		 			return param;
			}
		}catch(Exception e){
			e.printStackTrace();
			param.put("message", String.format(ErrorMessage.ENTERPRISE_SEARCH_NINE_JY, e.getMessage()));
			param.put("boolean", false);
			return param;
		}
		param.put("message", ErrorMessage.ENTERPRISE_SEARCH_TEN_JY);
		param.put("boolean", true);
		return param;
	}

	@Override
	public boolean updatepayStatusBy(
			EnterprisePayMoneyRecords enterprisePayMoneyRecords) {
		try {
			Integer returnCode =  enDaoI.updatepayStatusBy(enterprisePayMoneyRecords);
			if(returnCode <= 0){
				return false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		  return false;
		}
		return true;
	}
	
	public static void main(String[] args) {
		System.out.println(String.format("���%s/n�ѻ���", "�ǵ�"));
	}

	@Override
	public EnterprisePayMoneyRecords getEnPayMoneyRecordsInfo(
			EnterprisePayMoneyRecords proenter) {
		EnterprisePayMoneyRecords records = null;
		try {
			records = enDaoI.getEnPayMoneyRecordsInfo(proenter);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("��������쳣ԭ����:"+e.getMessage());
		}
		return records;
	}

}
