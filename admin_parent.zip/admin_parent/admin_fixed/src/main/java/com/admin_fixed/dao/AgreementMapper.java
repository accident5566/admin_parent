package com.admin_fixed.dao;

import java.util.List;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.ProductAgreementTemplate;

public interface AgreementMapper extends BaseMapper<ProductAgreementTemplate>{

	public List<ProductAgreementTemplate> getByType(ProductAgreementTemplate ProductAgreementTemplate);
}
