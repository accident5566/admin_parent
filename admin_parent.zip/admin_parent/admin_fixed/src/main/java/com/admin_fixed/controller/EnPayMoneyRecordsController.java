package com.admin_fixed.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.EnterprisePayMoneyRecords;
import com.admin_base.model.Product;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;
import com.admin_fixed.service.EnPayMoneyRecordsService;

/**
 * ��ҵ����ѯcontroller����
 * @author qiupeiwei
 * @Date 2015-06-09
 */
@Controller("enPayMoneyRecordsController")
@RequestMapping("/enPayMoneyRecords")
public class EnPayMoneyRecordsController {
	private static final Logger log = Logger.getLogger(EnPayMoneyRecordsController.class);
	
	@Autowired private EnPayMoneyRecordsService enmoneyRecordsServiceI;
	
	   @InitBinder
	   public void initBinder(WebDataBinder binder){
		   binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	   } 
	   
	   @RequestMapping(value="/showAllEnpayMoneyRecords",method = RequestMethod.GET)
		public ModelAndView showAllProductInfo(HttpServletRequest request, HttpServletResponse response,EnterprisePayMoneyRecords enmoneyRecords){
		   //			PageParameter pageView = null;
//			String pageNow  = request.getParameter("pageNow");
//			if("".equals(pageNow) || pageNow == null){
//				pageView = new PageParameter();
//			}else{
//				pageView = new PageParameter(Integer.parseInt(pageNow));
//			}
			ModelAndView model = new ModelAndView();
			model.addObject("enMoneyRecordsList",enmoneyRecordsServiceI.getEnPayMoneyRecordsInfo(enmoneyRecords));
//			model.addObject("pageView",pageView);
//			model.addObject("enmoneyRecords",enmoneyRecords);
			model.setViewName("enterprise/proEnterpriseManager");
			return model;
		}
	
	   @RequestMapping(value="/enterprisePayMoney",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
		public @ResponseBody String enterprisePayMoney(HttpServletRequest request,HttpServletResponse response, ModelMap model) throws JsonProcessingException, IOException, InterruptedException, ParseException{
			String productIdentifier = request.getParameter("productIdentifier");
			String channel = request.getParameter("channel");
			MessageResult messageresult = null;
			if(StringUtils.isEmpty(channel)){
				messageresult = new MessageResult();
				messageresult.setMessage("�����쳣ԭ���Ǻ�˻�ȡ��֧��ͨ��Ϊ����������½�����ҵ������������");
				return messageresult.getAsJSON();
			}
			if(channel.equals("10")){
				messageresult = enmoneyRecordsServiceI.enterprisePayMoneyServiceYL(productIdentifier);
				return messageresult.getAsJSON(); 
			}
			if(channel.equals("20")){
				messageresult = enmoneyRecordsServiceI.enterprisePayMoneyServiceYJ(productIdentifier);
				return messageresult.getAsJSON(); 
			}
			messageresult = new MessageResult();
			messageresult.setMessage("�����쳣��������½�����ҵ������������");
			return messageresult.getAsJSON();
		}
	   
	   @RequestMapping(value="/redirectEnterprisePayMoneyPage",method = RequestMethod.GET)
		public  ModelAndView redirectEnterprisePayMoneyPage(HttpServletRequest request,HttpServletResponse response) throws JsonProcessingException, IOException, InterruptedException, ParseException{
			String productIdentifier = request.getParameter("productIdentifier");
			String productNo = request.getParameter("pno");
			ModelAndView model = new ModelAndView();
			model.addObject("payMoney", enmoneyRecordsServiceI.showPayMoneyInfo(productIdentifier,productNo));
			model.addObject("productIdentifier", productIdentifier);
			model.setViewName("enterprise/enterprisePayMoney");
			return model;
		}
	   
	   @RequestMapping(value="/enterprisePayMoneySearch",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
		public @ResponseBody String enterprisePayMoneySearch(HttpServletRequest request,HttpServletResponse response, ModelMap model,Product product) throws JsonProcessingException, IOException, InterruptedException, ParseException{
		    String productIdentifier = request.getParameter("productIdentifier");
			String channel = request.getParameter("channel");
			MessageResult messageresult = null;
			if(StringUtils.isEmpty(channel)){
				messageresult = new MessageResult();
				messageresult.setMessage("�����쳣ԭ���Ǻ�˻�ȡ��֧��ͨ��Ϊ����������½�����ҵ������������");
				return messageresult.getAsJSON();
			}
			if(channel.equals("10")){
				messageresult = enmoneyRecordsServiceI.enterprisePayMoneySearchYL(productIdentifier);
				return messageresult.getAsJSON(); 
			}
			if(channel.equals("20")){
				messageresult = enmoneyRecordsServiceI.enterprisePayMoneySearchYJ(productIdentifier);
				return messageresult.getAsJSON(); 
			}
			messageresult = new MessageResult();
			messageresult.setMessage("�����쳣��������½�����ҵ������������");
			return messageresult.getAsJSON();
		}  
}
