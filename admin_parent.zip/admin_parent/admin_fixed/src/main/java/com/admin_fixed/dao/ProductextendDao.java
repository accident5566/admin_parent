package com.admin_fixed.dao;

import java.util.List;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.Productextend;

/***
 * ��Ʒ��չDAO
 * @author qiupeiwei
 * @Date 2015-03-16
 *
 */
public interface ProductextendDao extends BaseMapper<Productextend> {

	public List<Productextend> getProductextendByExcTime(Integer payform);
	
	public List<Productextend> getInfos(Productextend productextend);
	
}
