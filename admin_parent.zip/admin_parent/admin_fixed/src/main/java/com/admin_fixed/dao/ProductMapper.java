package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.Product;
/**
 * ��Ʒģ��mapper
 * @author qiupeiwei
 * @Date 2015-03-25
 */

public interface ProductMapper extends BaseMapper<Product>{

	public Integer updateProductStatus(Product product);
	public Integer updateProStatus(Product product);
	public Product getProductByIdentifier(Product product);
	public Product checkProductNumber(Product product);
	public Integer updateProductInfo(Product product);
	public Product getProByNo(String productNo);
	public Product getInfos(Product product);
	public Integer updateProifnoStatus(Product product);
	public Product getProductForAccount(Product product);
	public Integer updateCheckStatusForEnPayMoney(Product product);
}
