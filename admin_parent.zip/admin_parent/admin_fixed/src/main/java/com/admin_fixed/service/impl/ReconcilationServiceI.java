package com.admin_fixed.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.dto.response.ReconciliationQueryYiJiaDTOMsg;
import com.admin_base.model.Orders;
import com.admin_base.util.DateUtil;
import com.admin_base.util.HttpUtil;
import com.admin_fixed.dao.OrderMapper;
import com.admin_fixed.dto.MerchantsAmountResponse;
import com.admin_fixed.service.ReconcilationService;

@Service
public class ReconcilationServiceI implements ReconcilationService {
	
	private static final Logger log = Logger.getLogger(ReconcilationServiceI.class);
	
	@Autowired
	private OrderMapper orderMapper;

	@Override
	public List<ReconciliationQueryYiJiaDTOMsg> getAllOrdersFromYJ(String startDate,String endDate) {
		log.info("���ζ��˽ӿڵ��ÿ�ʼ-----start");
		try {
			Map<String, Object> responseResult = null;
			HttpUtil httpUtil = new HttpUtil();
			String paramStr = "startDate="+ startDate + "&endDate="+endDate;
			responseResult = httpUtil.sendHttpRequest("pay.gateway","pay.yinjia.checkorder",paramStr, "POST");
			String resResult = responseResult.get("respContent").toString();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode json = mapper.readTree(resResult);
			JsonNode jsonNode = json.path("properties");
			String jsonStr = jsonNode.toString();
			JSONArray jsona = JSONArray.fromObject(jsonStr);
			List<ReconciliationQueryYiJiaDTOMsg> list = (List<ReconciliationQueryYiJiaDTOMsg>) JSONArray.toCollection(jsona, ReconciliationQueryYiJiaDTOMsg.class);
			log.info("���ζ��˽ӿڵ��ý���-----start");
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("���ζ��˽ӿڲ����쳣----exception-----�쳣��ԭ����:" + e.getMessage());
			return null;
		}
	}

	@Override
	public MerchantsAmountResponse getMerchantsAmount() {
		log.info("�����̻���Ϣ�ӿڵ��ÿ�ʼ-----start");
		try {
			Map<String, Object> responseResult = null;
			HttpUtil httpUtil = new HttpUtil();
			responseResult = httpUtil.sendHttpRequest("pay.gateway","pay.yinjia.merchantsInfo", "", "POST");
			String resResult = responseResult.get("respContent").toString();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode json = mapper.readTree(resResult);
			JsonNode jsonNode = json.path("properties");
			String jsonStr = jsonNode.toString();
			JSONArray jsona = JSONArray.fromObject(jsonStr);
			List<MerchantsAmountResponse> list = (List<MerchantsAmountResponse>) JSONArray.toCollection(jsona, MerchantsAmountResponse.class);
			if (list == null || list.size() != 1) {
				return null;
			}
			log.info("�����̻���Ϣ�ӿڵ��ý���-----start");
			return list.get(0);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("�����̻���Ϣ�ӿڲ����쳣----exception-----�쳣��ԭ����:" + e.getMessage());
			return null;
		}
	}

	@Override
	public List<ReconciliationQueryYiJiaDTOMsg> beginReconciliation(String startDate, String endDate) {
		/**
		 * 1����ƽ̨�õ��Ķ���
		 */
		List<ReconciliationQueryYiJiaDTOMsg> queryOrdersByYJ = this.getAllOrdersFromYJ(startDate, endDate);
		/**
		 * 2�õ�ϵͳ�Ķ��� (����֧���ɹ�)
		 */
		List<OrderDetailDTOResult> myQueryOrders= new ArrayList<OrderDetailDTOResult>();
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		Orders temp = new Orders();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if (StringUtils.isNotBlank(startDate)) {
				Date d1 = DateUtil.returnDateTime(startDate, "yyyyMMdd");
				startDate = formatter.format(d1);
				startDate += " 00:00:00";
			}
			if (StringUtils.isNotBlank(endDate)) {
				Date d2 = DateUtil.returnDateTime(endDate, "yyyyMMdd");
				endDate = formatter.format(d2);
				endDate += " 23:59:59";
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		temp.setOrderStatus(20);
		temp.setPaySource(20);
        parameterMap.put("t", temp);
        parameterMap.put("start", startDate);
        parameterMap.put("end", endDate);
        myQueryOrders = orderMapper.getCheckBill(parameterMap);
        
        /**
         * 3���շ��ؽ��
         */
        List<ReconciliationQueryYiJiaDTOMsg> finalResult = new ArrayList<ReconciliationQueryYiJiaDTOMsg>();
		/**
		 * ֧����Դ������  ����������֧���ɹ�  ��Ʒ����productNo   ������ʼʱ��startDate  ��������ʱ��endDate
		 * (�Ե����ö��˳ɹ�, ���Ե����� ������ ,  �����쳣����.  ���ö���״̬) ������Ϊֻ�ǲ鿴,���޸����ݿ�,�ʲ���Ҫ
		 */
		Map<String, Object> map = new HashMap<String, Object>();
		for (OrderDetailDTOResult result : myQueryOrders) {
			map.put(result.getOrderNo(), result);
		}
		for (ReconciliationQueryYiJiaDTOMsg reconciliationQueryYiJiaDTOMsg : queryOrdersByYJ) {
			if (reconciliationQueryYiJiaDTOMsg == null) {
				continue;
			}
			OrderDetailDTOResult orderDetailDTOResult = (OrderDetailDTOResult) map.get(reconciliationQueryYiJiaDTOMsg.getOrderno());
			if (orderDetailDTOResult== null) {
				reconciliationQueryYiJiaDTOMsg.setMsg("���ε�����");
				finalResult.add(reconciliationQueryYiJiaDTOMsg);
			}else {
				myQueryOrders.remove(orderDetailDTOResult);
				if (orderDetailDTOResult.getRealAmount() == null || comparYJAndSysMoney(reconciliationQueryYiJiaDTOMsg.getAmount(),orderDetailDTOResult.getRealAmount()) != 0) {
					reconciliationQueryYiJiaDTOMsg.setMsg("������ƥ��");
					finalResult.add(reconciliationQueryYiJiaDTOMsg);
				}
			}
		}
		
		/**
		 * �ҷ�ʣ�ඩ��,Ϊ�ҷŵ�����
		 */
		for(OrderDetailDTOResult o : myQueryOrders){
			ReconciliationQueryYiJiaDTOMsg r = new ReconciliationQueryYiJiaDTOMsg();
			//ת��Ϊ��
			r.setAmount(o.getAmount().multiply(BigDecimal.TEN).multiply(BigDecimal.TEN));
			r.setMobile(o.getCellphone());
			r.setMsg("ϵͳ������");
			r.setOrderno(o.getOrderNo());
			finalResult.add(r);
		}
		return finalResult;
	}
 	/**
 	 * @return
 	 */
	private int comparYJAndSysMoney(BigDecimal YJMoney , BigDecimal myMoney){
		YJMoney = YJMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
		myMoney = myMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
		return YJMoney.compareTo(myMoney);
	}
}
