package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.Backendrecord;

public interface BackendrecordDao extends BaseMapper<Backendrecord>{

	public Integer updateBackendPayStatus(Backendrecord backendrecord);
	
	public Integer savePayStatus(Backendrecord backendrecord);
}
