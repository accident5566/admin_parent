package com.admin_fixed.service;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonProcessingException;

import com.admin_base.model.Productextend;

/***
 * ��Ʒ��չservice�ӿڶ���
 * @author ted.chen
 * @Date��2015-03-20
 */
public interface ProductextendService {
	
   boolean saveProExtendInfo(Productextend productextend);
   
   Productextend searchByProIndentifier(Productextend productextend);
   
   List<Productextend> searchByProIndentifierList(Productextend productextend);
   
   List<Productextend> getProductextendByExcTime(Integer parform);
   
   boolean paymentBatchQueryYL(String productBatchNo,String productIdentifier) throws JsonProcessingException, IOException;
   
   boolean paymentBatchQueryYJ(String productBatchNo,String productIdentifier) throws JsonProcessingException, IOException;
}
