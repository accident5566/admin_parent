package com.admin_fixed.service;

import java.util.List;

import com.admin_base.model.JobRecord;

public interface JobRecordService {
	
	
	public void save(JobRecord jobrecord);
	
	public void delete(JobRecord jobrecord);
	
	
	public List<JobRecord> findRecordAll();

}
