package com.admin_fixed.service;

import java.util.List;

import com.admin_base.model.ScheduleCtrl;
import com.admin_base.mybatis.plug.PageParameter;

public interface ScheduleCtrlService {
	
	public List<ScheduleCtrl> findByName(String jobName,String execFlag,String lastExecFlag,PageParameter pageView);
	
	public int update(ScheduleCtrl scheduleCtrl);

}
