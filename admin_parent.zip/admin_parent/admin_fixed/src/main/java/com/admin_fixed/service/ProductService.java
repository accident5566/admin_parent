package com.admin_fixed.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonProcessingException;

import com.admin_base.dto.yl.CommonMsg;
import com.admin_base.model.Product;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;


/**
 * ��Ʒģ��service�ӿڶ���
 * @author qiupeiwei
 * @Date 2015-03-25
 */

public interface ProductService{
	
	public List<Product> getProductByPage(PageParameter pageView, Product product);
	
	public Product getProductByIdentifier(Product product);
	
    public boolean saveProductInfo(Product product);
	
	public boolean deleteProductInfo(Product product);
	
	public Product getProductInfo(Product product);
	
	public Product getProductInfos(Product product);
	
	public boolean  updateProductInfo(Product product);
	public boolean  updateProductInfos(Product product);
	
	public boolean updateProductStatus(Product product);
	
	public boolean checkProductNumber(Product product);
	
	public MessageResult reconciliation(String productNo) throws JsonProcessingException, IOException; 
	
	public List<CommonMsg> reconciliationQuery(String productNo) throws JsonProcessingException, IOException;
	
	public boolean recheckproductStatus(String productNo);
	
	public Map<String,Object> orderMatchRaise(List<CommonMsg>   comLists,String productNo);
	
	public Product getProByNo(String productNo);
	
	public boolean updateProStatus(Product product);
	
	public Product getProductForAccount(Product product);
	
	public boolean updateCheckStatusForEnPayMoney(Product product);
	
}
