package com.admin_fixed.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.admin_base.model.JobRecord;
import com.admin_fixed.dao.JobRecordDao;
import com.admin_fixed.service.JobRecordService;

@Service
@Transactional(rollbackFor=Exception.class)
public class JobRecordServiceImpl implements JobRecordService {

	@Autowired
	private JobRecordDao jobRecordDao;
	
	public void save(JobRecord jobrecord) {
		jobRecordDao.save(jobrecord);		
	}

	public void delete(JobRecord jobrecord) {
		jobRecordDao.delete(jobrecord);
	}

	public List<JobRecord> findRecordAll() {
		return jobRecordDao.findRecordAll();
	}

	public JobRecordDao getJobRecordDao() {
		return jobRecordDao;
	}

	public void setJobRecordDao(JobRecordDao jobRecordDao) {
		this.jobRecordDao = jobRecordDao;
	}
}
