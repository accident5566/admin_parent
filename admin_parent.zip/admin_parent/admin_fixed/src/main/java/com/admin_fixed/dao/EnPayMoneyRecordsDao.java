package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.dto.request.EnPayMoneyDTO;
import com.admin_base.model.EnterprisePayMoneyRecords;

public interface EnPayMoneyRecordsDao extends BaseMapper<EnterprisePayMoneyRecords>{
	public EnPayMoneyDTO searchEnPayMoneyInfo(EnPayMoneyDTO enpayMoneyDTO);
	public EnterprisePayMoneyRecords getEnpayMoneyRecordsBy(EnterprisePayMoneyRecords proenter);
	public Integer updatepayStatusBy(EnterprisePayMoneyRecords enterprisePayMoneyRecords);
	public EnterprisePayMoneyRecords getEnPayMoneyRecordsInfo(EnterprisePayMoneyRecords proenter);
}
