package com.admin_fixed.service;

import com.admin_base.model.ProductDesc;

public interface ProductDescService {

	public boolean saveProductDesc(ProductDesc productDesc);
	
	public boolean updateProductDesc(ProductDesc productDesc);
}
