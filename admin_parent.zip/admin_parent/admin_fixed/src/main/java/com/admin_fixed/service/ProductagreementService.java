package com.admin_fixed.service;

import com.admin_base.model.Productagreement;

public interface ProductagreementService {

	public boolean saveProductAgreementInfo(Productagreement productagreement);
	
	public Productagreement getpagreementInfo(String  productNo);
	
	public boolean updatePaContent(Productagreement productagreement);
}
