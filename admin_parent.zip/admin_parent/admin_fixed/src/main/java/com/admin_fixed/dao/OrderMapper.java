package com.admin_fixed.dao;

import java.util.List;
import java.util.Map;

import com.admin_base.dao.BaseMapper;
import com.admin_base.dto.request.SreceivedPaymentDTO;
import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.model.Orders;
import com.admin_base.model.OrdersEx;
import com.admin_base.model.Productextend;

public interface OrderMapper extends BaseMapper<Orders> {

	public List<Orders> getSuccessByPage(Map<String,Object> parametersMap);
	
	public List<OrderDetailDTOResult> getSuccessOrdersList(SreceivedPaymentDTO sreceivedPaymentdto);
	
	public Integer updateOrderStatus(OrderDetailDTOResult orderDetailDTOResult);
	
	public List<OrderDetailDTOResult> getSuccessOrdersLists(Productextend productextend);
	
	public OrdersEx getSuccessOrders(Orders orders);
	
	public Integer updateOrders(Orders orders);
	
	public List<OrderDetailDTOResult> getOrdersByPage(Map<String,Object> parametersMap);

    public List<OrderDetailDTOResult> getCheckBill(Map<String, Object> parametersMap);
    public List<OrderDetailDTOResult> getEndBill(Map<String, Object> parametersMap);
	
	public List<Orders> getSuccessOrdersListBy(Map<String,Object> parametersMap);
	public List<Orders> getSuccessOrdersListBys(Map<String,Object> parametersMap);
	
}
