package com.admin_fixed.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.dto.response.ReconciliationQueryYiJiaDTOMsg;
import com.admin_base.model.Orders;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.ExcelUtil;
import com.admin_fixed.dto.MerchantsAmountResponse;
import com.admin_fixed.service.OrderService;
import com.admin_fixed.service.ReconcilationService;

/**
 * ����excel������
 * @author Chengfei.Sun on 2015/7/20.
 */
@Controller("exportController")
@RequestMapping("/export")
public class ExportController {
    private static final Logger log = Logger.getLogger(ExportController.class);
    
    /**
     * ����õ��Ķ��˶���
     */
    private static List<ReconciliationQueryYiJiaDTOMsg> resultList;
    
    /**
     * �����̻���Ϣ
     */
    private static MerchantsAmountResponse mResponse;
    
    /**
     * �������
     */
    private static String start;
    
    private static String end;

    @Autowired
    private OrderService orderServiceI;
    
    @Autowired
    private ReconcilationService reconcilationService;
    
    /**
     * ��ѯ�̻���Ϣ
     */
    @RequestMapping(value = "/merchantsInfo", method = RequestMethod.GET)
    public ModelAndView merchantsInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	mResponse = reconcilationService.getMerchantsAmount();
    	ModelAndView modelAndView = new ModelAndView();
    	modelAndView.addObject("merchantsInfo",mResponse);
    	modelAndView.setViewName("export/exportManager");
    	return modelAndView;
    }
    /**
     * ��ҳ
     * @param request
     * @return
     */
	@RequestMapping(value="/reconciliationOrderFenye",method = RequestMethod.GET)
	public ModelAndView uploadAssetFenye(HttpServletRequest request){
		List<ReconciliationQueryYiJiaDTOMsg> orderList = new ArrayList<ReconciliationQueryYiJiaDTOMsg>();
		orderList.addAll(resultList);
		String pageNow = request.getParameter("pageNow");
		int n = Integer.parseInt(pageNow);
		PageParameter pageView = new PageParameter(n);
		pageView.setQueryResult(orderList.size(), orderList);
		int size = orderList.size();
		if (size<=n*10) {
			orderList = orderList.subList(10*(n-1), orderList.size());
		}else {
			orderList = orderList.subList(10*(n-1), 10*n);
		}
		
		//������֮������ݷ���
		ModelAndView modelAndView = new ModelAndView();
		if (mResponse == null) {
			mResponse = reconcilationService.getMerchantsAmount();
		}
		modelAndView.addObject("merchantsInfo",mResponse);
    	modelAndView.addObject("orderList",orderList);
    	modelAndView.addObject("pageView",pageView);
    	modelAndView.addObject("startTime",start);
    	modelAndView.addObject("endTime",end);
    	modelAndView.setViewName("export/exportManager");
		return modelAndView;
	}
	
	/**
	 * ��ʼ���ж���
	 */
	@RequestMapping(value="/reconciliationOrder",method = RequestMethod.POST)
	public ModelAndView reconciliationOrder(HttpServletRequest request,HttpServletResponse response){
		ModelAndView modelAndView = new ModelAndView();
    	start = request.getParameter("startTime");
    	end = request.getParameter("endTime");
    	PageParameter pageView = new PageParameter();
    	resultList = reconcilationService.beginReconciliation(start, end);
    	List<ReconciliationQueryYiJiaDTOMsg> orderList = new ArrayList<ReconciliationQueryYiJiaDTOMsg>();
    	if (resultList == null || resultList.size() <= 0 ) {
    		modelAndView.addObject("orderList",orderList);
    		modelAndView.addObject("success",1);
		}else {
			orderList.addAll(resultList);
			//�õ���nҳ���� Ĭ��һҳ10����¼
			int n=1;
			pageView.setQueryResult(orderList.size(), orderList);
			if (orderList.size()<=n*10) {
				orderList = orderList.subList(10*(n-1), orderList.size());
			}else {
				orderList = orderList.subList(10*(n-1), 10*n);
			}
			modelAndView.addObject("orderList",orderList);
		}
    	if (mResponse == null) {
			mResponse = reconcilationService.getMerchantsAmount();
		}
		modelAndView.addObject("merchantsInfo",mResponse);
    	modelAndView.addObject("pageView",pageView);
    	modelAndView.addObject("startTime",start);
    	modelAndView.addObject("endTime",end);
    	modelAndView.setViewName("export/exportManager");
		return modelAndView;
	}

    /**
     * ���������˵�
     * @throws IOException
     */
    @RequestMapping(value = "/exportCheckBill", method = RequestMethod.GET)
    public String exportCheckBill(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //ʱ������
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        if (StringUtils.isEmpty(startTime)) {
            startTime = "1970-01-01";
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        if (StringUtils.isEmpty(endTime)) {
            endTime = formatter.format(new Date());
        }
        startTime = startTime + " 00:00:00";
        endTime = endTime + " 23:59:59";

        //��ѯ����
        Orders order = new Orders();
        order.setOrderStatus(20);
        order.setPaySource(20);
        List<OrderDetailDTOResult> orderResult = orderServiceI.getCheckBill(order, startTime, endTime);

        //���projects����
        List<Map<String, Object>> list = createCheckBillRecord(orderResult);
        String columnNames[] = {"�������", "����ʱ��", "ʵ�����", "�ֻ�����", "Ͷ��������", "��Ʒ���", "��Ʒ����"};//����
        String keys[] = {"orderNo", "resultTime", "amount", "cellphone", "realName", "productNo", "productNum"};//map�е�key

        //����excel
        this.geneExcel(list, keys, columnNames, formatter.format(new Date()) + "�����˵�.xls", response,false);
        return null;
    }

    /**
     * ������Ʒ�����˵�
     * @throws IOException
     */
    @RequestMapping(value = "/exportEndBill", method = RequestMethod.GET)
    public String exportEndBill(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        //��Ʒ���
        String productIdentifier = request.getParameter("productIdentifier");

        //���ݲ�Ʒ��Ų�ѯ����
        Orders order = new Orders();
        order.setProductIdentifier(productIdentifier);
        List<OrderDetailDTOResult> orderResult = orderServiceI.getEndBill(order);
        
        if (orderResult == null || orderResult.size() <= 0) return null;

        //���projects����
        List<Map<String, Object>> list = createEndBillRecord(orderResult);
        String columnNames[] = {"�������", "����ʱ��", "������", "ʵ�����", "��Ʒ����", "�տ�����", "������", "Ͷ��������",
                "��", "��ʼ��", "������", "��Ϣ����(����)", "Ӧ����Ϣ(����)", "��Ϣ����(�����)",
                "Ӧ����Ϣ(�����)", "Ͷ����Ԥ������", "Ͷ��������(������)", "�����", "֤������", "��ע"};//����
        String keys[] = {"orderNo", "resultTime", "amount", "realPayAmount", "productName", "paySource", "yield", "realName",
                "jiekuanfang", "valueDate", "settleDate", "jixidaysY", "lixiY", "jixidays",
                "lixi", "interest", "allshouyi", "activityInterest", "credentialNo","note"};//map�е�key

        //����excel
        this.geneExcel(list, keys, columnNames, orderResult.get(0).getProductName()+"�˵�.xls", response,true);
        return null;
    }

    /**
     * ���ɲ�Ʒ�����˵�����
     * @param orderResult
     * @return
     */
    private List<Map<String, Object>> createEndBillRecord(List<OrderDetailDTOResult> orderResult) throws ParseException {
        List<Map<String, Object>> listmap = new ArrayList<Map<String, Object>>();
        Map<String, Object> sheet = new HashMap<String, Object>();
        sheet.put("sheetName", "��Ʒ�����˵�");
        listmap.add(sheet);

        Map<String, Object> title = new HashMap<String, Object>();
        title.put("title", orderResult.get(0).getProductName() + "��Ʒ����");
        listmap.add(title);

        BigDecimal totalAmount = new BigDecimal(0); // �����ܽ��
        BigDecimal totalInterest = new BigDecimal(0); // �û�������
        BigDecimal totalLixiY = new BigDecimal(0);    // ��������Ϣ
        BigDecimal totalLixi = new BigDecimal(0);     // �û�����Ϣ

        OrderDetailDTOResult orderDetail = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
        for (int j = 0; j < orderResult.size(); j++) {
            orderDetail = orderResult.get(j);

//            totalAmount = totalAmount.add(orderDetail.getAmount());
//            totalInterest = totalInterest.add(orderDetail.getInterest());

            Map<String, Object> mapValue = new HashMap<String, Object>();
            mapValue.put("orderNo", orderDetail.getOrderNo());
            mapValue.put("resultTime", formatter.format(orderDetail.getResultTime()));
            mapValue.put("amount", orderDetail.getAmount());
            if(orderDetail.getVirtualAmount()==null){
            	mapValue.put("realPayAmount", orderDetail.getAmount());
            }
            else{
            	 mapValue.put("realPayAmount", orderDetail.getAmount().subtract(orderDetail.getVirtualAmount()));         
            }
            mapValue.put("productName", orderDetail.getProductName());
            mapValue.put("paySource", orderDetail.getPaySource().equals(10) ? "����" : "����");
            mapValue.put("yield", orderDetail.getYield()+"%");
            mapValue.put("realName", orderDetail.getRealName());
            mapValue.put("credentialNo", orderDetail.getCredentialNo());
            mapValue.put("valueDate", formatter.format(orderDetail.getValueDate()));
            mapValue.put("settleDate", formatter.format(orderDetail.getSettleDate()));
            mapValue.put("jixidaysY", 0);
            mapValue.put("lixiY", new BigDecimal("0"));
            mapValue.put("jixidays", 0);
            mapValue.put("lixi", new BigDecimal("0"));
            //�������Ȿ��+���Ȿ�𲿷�����
            BigDecimal virtualInterest = null;
            if(orderDetail.getVirtualAmount()!=null){
            virtualInterest = orderDetail.getVirtualAmount().add(orderDetail.getInterest().divide(orderDetail.getAmount(), 2).multiply(orderDetail.getVirtualAmount()));
            }
            //�����������Ԥ������,������Լ���������+���Ȿ���Լ����Ȿ�����������
            mapValue.put("interest", orderDetail.getInterest().add(orderDetail.getExtraInterest().add(orderDetail.getActivityInterest()).add(virtualInterest)));
            mapValue.put("activityInterest", orderDetail.getActivityInterest().add(orderDetail.getExtraInterest()).add(virtualInterest));
            mapValue.put("allshouyi", orderDetail.getAmount().add((BigDecimal) mapValue.get("interest")));
            listmap.add(mapValue);

//            totalLixiY = totalLixiY.add((BigDecimal) mapValue.get("lixiY"));
//            totalLixi = totalLixi.add((BigDecimal) mapValue.get("lixi"));
        }

        //���ͳ����
        Map<String, Object> mapValue = new HashMap<String, Object>();
        mapValue.put("amount", totalAmount);
        mapValue.put("interest", totalInterest);
        mapValue.put("lixiY", totalLixiY);
        mapValue.put("lixi", totalLixi);
        listmap.add(mapValue);

        return listmap;
    }

    /**
     * ���ɶ����˵�����
     * @param orderResult
     * @return
     */
    private List<Map<String, Object>> createCheckBillRecord(List<OrderDetailDTOResult> orderResult) {
        List<Map<String, Object>> listmap = new ArrayList<Map<String, Object>>();
        Map<String, Object> sheet = new HashMap<String, Object>();
        sheet.put("sheetName", "ÿ�ն����˵�");
        listmap.add(sheet);
        Map<String, Object> title = new HashMap<String, Object>();
        title.put("title", "ÿ�ն����˵�");
        listmap.add(title);
        OrderDetailDTOResult orderDetail = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        for (int j = 0; j < orderResult.size(); j++) {
            orderDetail = orderResult.get(j);
            Map<String, Object> mapValue = new HashMap<String, Object>();
            mapValue.put("orderNo", orderDetail.getOrderNo());
            mapValue.put("resultTime", formatter.format(orderDetail.getResultTime()));
            mapValue.put("amount", orderDetail.getAmount().subtract(orderDetail.getVirtualAmount()));
            mapValue.put("cellphone", orderDetail.getCellphone());
            mapValue.put("realName", orderDetail.getRealName());
            mapValue.put("productNo", orderDetail.getProductNo());
            mapValue.put("productNum", orderDetail.getProductNum());
            listmap.add(mapValue);
        }
        return listmap;
    }

    /**
     * �����������
     * @param smdate ��ʼ���ڣ���ʽ"yyyy/MM/dd"
     * @param bdate  ��������
     * @return
     * @throws ParseException
     */
    private int daysBetween(String smdate, String bdate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(smdate));
        long time1 = cal.getTimeInMillis();
        cal.setTime(sdf.parse(bdate));
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);

        return Integer.parseInt(String.valueOf(between_days));
    }

    /**
     * ������Ϣ
     * @param amount ������
     * @param yield  ������
     * @param days   ��Ϣ����
     * @return
     */
    public BigDecimal genelixi(BigDecimal amount, BigDecimal yield, int days){
        yield = yield.divide(new BigDecimal(100));
        BigDecimal total = amount.multiply(yield).multiply(new BigDecimal(days));
        BigDecimal lixi = total.divide(new BigDecimal(360), 2);
        return lixi.setScale(2, BigDecimal.ROUND_DOWN);
    }

    /**
     * ����excel
     * @param list
     * @param keys
     * @param columnNames
     * @param fileName
     * @param response
     * @throws IOException
     */
    private void geneExcel(List<Map<String, Object>> list, String[] keys, String[] columnNames,
                           String fileName, HttpServletResponse response,boolean isEnd) throws IOException{
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            ExcelUtil.createWorkBook(list, keys, columnNames,isEnd).write(os);
        } catch (IOException e) {
            log.error(ExceptionUtils.getStackTrace(e));
        }
        byte[] content = os.toByteArray();
        InputStream is = new ByteArrayInputStream(content);
        //����response���������Դ�����ҳ��
        response.reset();
        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" +
                new String((fileName).getBytes(), "iso-8859-1"));
        ServletOutputStream out = response.getOutputStream();
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            bis = new BufferedInputStream(is);
            bos = new BufferedOutputStream(out);
            byte[] buff = new byte[2048];
            int bytesRead;
            // Simple read/write loop.
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
        } catch (final IOException e) {
            throw e;
        } finally {
            if (bis != null)
                bis.close();
            if (bos != null)
                bos.close();
        }
    }
}
