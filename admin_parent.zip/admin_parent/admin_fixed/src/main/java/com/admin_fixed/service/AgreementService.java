package com.admin_fixed.service;

import java.util.List;

import com.admin_base.model.ProductAgreementTemplate;
import com.admin_base.model.Productagreement;
import com.admin_base.mybatis.plug.PageParameter;

public interface AgreementService {
	
	    public List<ProductAgreementTemplate> getAgreementByPage(PageParameter pageView, ProductAgreementTemplate agreement);
	
	    public boolean saveProductInfo(ProductAgreementTemplate agreement);
		
		public boolean deleteProductInfo(ProductAgreementTemplate agreement);
		
		public ProductAgreementTemplate getProductInfo(ProductAgreementTemplate agreement);
		
		public boolean  updateProductInfo(ProductAgreementTemplate agreement);
		
		public List<ProductAgreementTemplate> getAllProductInfo();
		
		public List<ProductAgreementTemplate> getByType(ProductAgreementTemplate ProductAgreementTemplate);
		
		public ProductAgreementTemplate getProAgreeInfoByNo(Integer productagreementNo);
}
