package com.admin_fixed.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.codehaus.jackson.JsonProcessingException;

import com.admin_base.dto.request.EnPayMoneyDTO;
import com.admin_base.dto.response.EnPayMoneyBase;
import com.admin_base.model.EnterprisePayMoneyRecords;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;

public interface EnPayMoneyRecordsService {
	public EnPayMoneyDTO getEnPayMoneyInfo(EnPayMoneyDTO enpayMoneyDTO);
	public boolean saveEnPayMoneyRecords(EnterprisePayMoneyRecords enpayRecords);
	public List<EnterprisePayMoneyRecords> getEnPayMoneyRecordsByPage(PageParameter pageView, EnterprisePayMoneyRecords proenter);
	public MessageResult enterprisePayMoneyServiceYL(String productIdentifier) throws ParseException, JsonProcessingException, IOException;
	public MessageResult enterprisePayMoneyServiceYJ(String productIdentifier) throws ParseException, JsonProcessingException, IOException;
	public MessageResult enterprisePayMoneySearch(String productIdentifier) throws JsonProcessingException, IOException;
	public EnterprisePayMoneyRecords getEnpayMoneyRecords(EnterprisePayMoneyRecords proenter);
	public boolean updateEnpayMoneyRecords(EnterprisePayMoneyRecords proenter);
	public EnPayMoneyBase showPayMoneyInfo(String productIdentifier,String productNo);
	public EnterprisePayMoneyRecords getEnpayMoneyRecordsBy(EnterprisePayMoneyRecords proenter);
	public MessageResult enterprisePayMoneySearchYL(String productIdentifier) throws JsonProcessingException, IOException;
	public MessageResult enterprisePayMoneySearchYJ(String productIdentifier) throws JsonProcessingException, IOException;
	
	public boolean updatepayStatusBy(EnterprisePayMoneyRecords enterprisePayMoneyRecords);
	
	public EnterprisePayMoneyRecords getEnPayMoneyRecordsInfo(EnterprisePayMoneyRecords proenter);
}
