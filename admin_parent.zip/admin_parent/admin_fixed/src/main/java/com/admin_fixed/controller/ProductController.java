package com.admin_fixed.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.constant.ComConstant;
import com.admin_base.constant.ProductType;
import com.admin_base.model.Product;
import com.admin_base.model.ProductAgreementTemplate;
import com.admin_base.model.Productagreement;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;
import com.admin_fixed.service.AgreementService;
import com.admin_fixed.service.ProductService;
import com.admin_fixed.service.ProductagreementService;
/**
 * ��Ʒģ��controller����
 * @author qiupeiwei
 * @Date 2015-03-25
 */
@Controller("productController")
@RequestMapping("/productInfo")
public class ProductController {
	private static final Logger log = Logger.getLogger(ProductController.class);
	

   @Autowired private ProductService productServiceImpl;
	
   @Autowired private AgreementService agreementServiceI;
   
   @Autowired private ProductagreementService pserviceI;
   
   
       @InitBinder
	   public void initBinder(WebDataBinder binder){
		   binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	   }
	@RequestMapping(value="/showAllProductInfo",method = RequestMethod.GET)
	public ModelAndView showAllProductInfo(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("productAdd") Product product){
		
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		//1.��ȡ�ڶ�����ѯ����ļ��״̬
		String raiseStatus=request.getParameter("raiseStatus");
		//2.��ҳ���ȡ��ֵת����Integer���͵�status
		Integer status = 0;
		if(product == null || product.getName() == null || product.getName().equals("")){
			product = new Product();
		}
		//3.����ڶ�����ѯ����ļ��״̬��ֵ(ת����Integer���͵�status)
		if(raiseStatus!=null&&raiseStatus!=""){
			status = Integer.valueOf(raiseStatus);
		}
		//4.����ڶ�����ѯ����ļ��״̬ûֵ(ֱ��ʹ��Integer���͵�status��ֵ)
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("raiseStatus",status);
		//5.��ҳ��ѯ֮ǰ��֯��ѯ����(��ļ��״̬���з�ҳ��ѯ)
		product.setRaiseStatus(status);
		model.addObject("productList",productServiceImpl.getProductByPage(pageView, product));
		model.addObject("pageView",pageView);
		model.addObject("now", new Date());
		model.addObject("name",product.getName());
		model.addObject("raiseList", ComConstant.getComUtil());
		model.setViewName("product/pruductManager");
		return model;
	}
	
	@RequestMapping(value="/getProductInfoDetailPage",method = RequestMethod.GET)
	public ModelAndView getProductInfoDetailPage(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("modifyProductInfo") Product product) throws IOException{
		ModelAndView model = new ModelAndView();
		String pid = String.valueOf(request.getParameter("id"));
		String ptype = String.valueOf(request.getParameter("ptype"));
		if(pid != null || !pid.equals("") || ptype != null || ptype.equals("")){
			ProductAgreementTemplate pTemplate = new ProductAgreementTemplate();
			pTemplate.setAgreementtype(1);
			ModelAndView mv = new ModelAndView();
			System.out.println(agreementServiceI.getByType(pTemplate));
			request.setAttribute("accAgreement", agreementServiceI.getByType(pTemplate));
			pTemplate.setAgreementtype(2);
			request.setAttribute("conAgreement",agreementServiceI.getByType(pTemplate));
			Product pro = productServiceImpl.getProductInfo(new Product(Integer.parseInt(pid)));
			model.addObject("product", pro);
			if(ptype.equals("10")){
				model.setViewName("product/pruductBaseDetail");
			}
			if(ptype.equals("30")){
				model.setViewName("product/pruductSADetail");
			}
			return model;
		}else{
			 response.sendRedirect("showAllProductInfo");
		}
		return model;
	}
	
	@RequestMapping(value="/addProductInfo",method = RequestMethod.POST)
	public  void addProductInfo(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("addProductInfo") Product product,@DateTimeFormat(pattern="yyyy-MM-dd") Date tim) throws ParseException, IOException, ServletException{
		System.out.println(request.getParameter("beginTime"));
		
		PrintWriter out =  response.getWriter();
		if(!Product.checkBlank(product)){
			out.println("<script>");
		    out.println("alert('��Ʒ��ҵ��Ϣһ��...������Ϊ��..!');");
		    out.println("history.back();");
		    out.println("</script>");
			return;
		}
		if(product.getEndTime().before(product.getBeginTime())){
			out.println("<script>");
		    out.println("alert('��Ʒ���۽���ʱ�������ڲ�Ʒ�Ŀ��ۿ�ʼʱ�䣡');");
		    out.println("history.back();");
		    out.println("</script>");
			return;
		}
		if(product.getInterestSetDate().before(product.getBeginTime())){
			out.println("<script>");
		    out.println("alert('��Ʒ��Ϣ����Ӧ�ô��ڲ�Ʒ�Ŀ�ʼ��ʼʱ�䣡');");
		    out.println("history.back();");
		    out.println("</script>");
			return;
		}
		if(product.getAmount()%product.getUnitPrice() != 0){
//			 response.sendRedirect("addProductInfoPage");
			out.println("<script>");
		    out.println("alert('��Ʒ���ʽ������ǲ�Ʒ���۵���������');");
		    out.println("history.back();");
		    out.println("</script>");
			 return;
		}
//		Integer protype = Integer.valueOf(request.getParameter("ptype").split(",")[0]);
		String productTypeStr = request.getParameter("ptype");
		product.setProductType(Integer.valueOf(productTypeStr.split(",")[0]));
		boolean flags = productServiceImpl.checkProductNumber(product);
		if(!flags){
//			response.sendRedirect("addProductInfoPage");
			product.setProductMessage("������Ψһ����������");
			out.println("<script>");
		    out.println("alert('������Ψһ���������룡');");
		    out.println("history.back();");
		    out.println("</script>");
			return;
		}else{
			product.setProductTypeStr(productTypeStr);
			boolean flag = productServiceImpl.saveProductInfo(product);
			if(flag){
				 response.sendRedirect("showAllProductInfo");
				 return;
			}
		}
	}
	
	@RequestMapping(value="/productInfoOnLine",method = RequestMethod.POST)
	public  void productInfoOnLine(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("modifyProductInfo") Product product,@DateTimeFormat(pattern="yyyy-MM-dd") Date tim) throws ParseException, IOException{
		String productNo = String.valueOf(request.getParameter("productNo"));
		String id = request.getParameter("id");
		if(productNo != null || !productNo.equals("")){
			boolean flag = productServiceImpl.updateProductStatus(new Product(productNo,2,10));
			if(flag){
				response.sendRedirect("showAllProductInfo");
			}else{
				response.sendRedirect("getProductInfoDetailPage?id="+id);
			}
		}
	}
	
	@RequestMapping(value="/addProductInfoPage",method = RequestMethod.GET)
	public ModelAndView addProductInfoPage(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("addProductInfo") Product product){
		String typeStr = request.getParameter("productTypeStr");
		Integer protype = Integer.valueOf(typeStr.split(",")[0]);
		ModelAndView mv = new ModelAndView();
		if(protype == 10){
			ProductAgreementTemplate pTemplate = new ProductAgreementTemplate();
			pTemplate.setAgreementtype(1);
			mv.addObject("accAgreement", agreementServiceI.getByType(pTemplate));
			mv.addObject("productType",typeStr);
			pTemplate.setAgreementtype(2);
			mv.addObject("conAgreement",agreementServiceI.getByType(pTemplate));
			mv.addObject("ptypeList",ProductType.getProList());
			mv.setViewName("product/productBaseAdd");
		}
		if(protype == 30){
			ProductAgreementTemplate pTemplate = new ProductAgreementTemplate();
			pTemplate.setAgreementtype(1);
			mv.addObject("accAgreement", agreementServiceI.getByType(pTemplate));
			pTemplate.setAgreementtype(2);
			mv.addObject("conAgreement",agreementServiceI.getByType(pTemplate));
			mv.addObject("productType", typeStr);
			mv.addObject("ptypeList",ProductType.getProList());
			mv.setViewName("product/productSAAdd");
		}
		return mv;
	}
	
	@RequestMapping(value="/getPagreementInfoDetail",method = RequestMethod.GET)
	public ModelAndView getPagreementInfoDetail(HttpServletRequest request, HttpServletResponse response){
		String productNo = request.getParameter("pno");
		String ptype = request.getParameter("ptype");
		ModelAndView mv = new ModelAndView();
		mv.addObject("pagreement",pserviceI.getpagreementInfo(productNo));
		if(ptype.equals("1")){
			mv.setViewName("product/pagreementDetailacc");
		}
		if(ptype.equals("2")){
			mv.setViewName("product/pagreementDetailcon");
		}
		return mv;
	}
	
	@RequestMapping(value="/productUpdatePageRedirect",method = RequestMethod.GET)
	public ModelAndView productUpdatePageRedirect(HttpServletRequest request, HttpServletResponse response){
		String pid = request.getParameter("id");
		String ptype = request.getParameter("ptype");
		String error = request.getParameter("error");
		Product p = productServiceImpl.getProductInfos(new Product(Integer.valueOf(pid)));
		ModelAndView model = new ModelAndView();
		model.addObject("product",p);
		if(error !=null){
			if(error.equals("e1")){
				model.addObject("interestSetDateSpan","��Ʒ��Ϣ����Ӧ�ô��ڲ�Ʒ�Ŀ���ʱ��");
			}
			if(error.equals("e2")){
				model.addObject("unitPriceSpan","���ʽ������ǲ�Ʒ���۵�������");
			}
			if(error.equals("e3")){
				model.addObject("productNumSpan","��Ʒ������Ψһ����������");
			}
			if(error.equals("e4")){
				model.addObject("endTimeSpan","��Ʒ���۽���ʱ��Ӧ�ô��ڲ�Ʒ���ۿ�ʼʱ��");
			}
			if(error.equals("e5")){
				model.addObject("enterprise","��Ʒ��ҵ��Ϣ����Ϊ��");
			}
		}
		if(ptype.equals("10")){
			model.setViewName("product/pruductBaseUpdate");
		}
		if(ptype.equals("30")){
			model.setViewName("product/pruductSAUpdate");
		}
		return model;
	}
	
	@RequestMapping(value="/product/productUpdateSubmit",method = RequestMethod.POST)
	public void productUpdateSubmit(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("product") Product product) throws IOException{
		if(product.getAmount()%product.getUnitPrice() != 0){
			 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&error=e1&&ptype="+product.getProductType());
			 return;
		}
		if(product.getInterestSetDate().before(product.getBeginTime())){
			 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&error=e2&&ptype="+product.getProductType());
			 return;
		}
		if(product.getEndTime().before(product.getBeginTime())){
			 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&error=e4&&ptype="+product.getProductType());
			 return;
		}
		if(product.getProductNum().intValue() != product.getProductNums().intValue()){
			boolean flags = productServiceImpl.checkProductNumber(product);
			if(!flags){
				 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&error=e3&&ptype="+product.getProductType());
				 return;
			}
		}
		if(!Product.checkBlank(product)){
			 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&error=e5&&ptype="+product.getProductType());
			 return;
		}
		boolean flag = productServiceImpl.updateProductInfo(product);
		if(flag){
				 response.sendRedirect("../showAllProductInfo");
				 return;
		}else{
			 response.sendRedirect("../productUpdatePageRedirect?id="+product.getId()+"&&ptype="+product.getProductType());
			 return;
		}
	}
	
	
	@RequestMapping(value="/getProductInfo",method = RequestMethod.GET)
	public ModelAndView getProductInfo(HttpServletRequest request, HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		return model;
	}
	
	@RequestMapping(value="/reconciliation",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public @ResponseBody String reconciliation(HttpServletRequest request,HttpServletResponse response, ModelMap model) throws JsonProcessingException, IOException, InterruptedException{
		String productNo = request.getParameter("productNo");
		MessageResult messageresult =  productServiceImpl.reconciliation(productNo);
		return messageresult.getAsJSON();
	}
	
	@RequestMapping(value="/checkProductNumber",method = RequestMethod.POST)
	public @ResponseBody String checkProductNumber(HttpServletRequest request,HttpServletResponse response){
		String pnumber = request.getParameter("productNumber");
		String ptype = request.getParameter("productType");
		if(pnumber == null || pnumber.equals("") || ptype == null || ptype.equals("")){
			return "blank";
		}
		Integer protype = Integer.valueOf(ptype.split(",")[0]);
		Product product = new Product();
		product.setProductType(protype);
		product.setProductNum(Integer.valueOf(pnumber));
		boolean flags = productServiceImpl.checkProductNumber(product);
		if(flags){
		    return "true";	
		}else{
			return "false";
		}
	}
	
	@RequestMapping(value="/productTypeSelect",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public  ModelAndView productTypeSelect(HttpServletRequest request,HttpServletResponse response) throws JsonProcessingException, IOException{
		ModelAndView mv = new ModelAndView();
		mv.addObject("ptypeList",ProductType.getProList());
		mv.setViewName("product/productGuide");
		return mv;
	}
	
	@RequestMapping(value="/pagreementUpdate",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public  ModelAndView pagreementUpdate(HttpServletRequest request,HttpServletResponse response,Productagreement product) throws JsonProcessingException, IOException{
		ModelAndView mv = new ModelAndView();
		pserviceI.updatePaContent(product);
		mv.addObject("pagreement",pserviceI.getpagreementInfo(product.getProductNo()));
		if(product.getPtype().equals("pacc")){
			mv.setViewName("product/pagreementDetailacc");
		}
		if(product.getPtype().equals("pcon")){
			mv.setViewName("product/pagreementDetailcon");
		}
		return mv;
	}
	
	@RequestMapping(value="/productStatusUpdate",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public @ResponseBody  String productStatusUpdate(HttpServletRequest request,HttpServletResponse response) throws JsonProcessingException, IOException{
		String productIdentifier = request.getParameter("productIdentifier");
		MessageResult messageresult =  new MessageResult();
		try{
			boolean flag = productServiceImpl.updateProStatus(new Product().getProduct(productIdentifier));
			if(!flag){
				messageresult.setMessage("���Ĳ�Ʒ״̬ʧ�ܣ����ֶ�����!!!");
				return messageresult.getAsJSON();
			}
			messageresult.setResultCode("200");
			return messageresult.getAsJSON();
		}catch(Exception e){
			messageresult.setMessage("���Ĳ�Ʒ״̬�쳣ԭ����:"+e.getMessage());
			return messageresult.getAsJSON();
		}
	}
}
