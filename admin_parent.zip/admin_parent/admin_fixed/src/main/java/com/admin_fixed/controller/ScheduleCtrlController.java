package com.admin_fixed.controller;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.JobRecord;
import com.admin_base.model.Product;
import com.admin_base.model.ScheduleCtrl;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.Json;
import com.admin_base.util.SpringBeanFactory;
import com.admin_fixed.service.JobRecordService;
import com.admin_fixed.service.ScheduleCtrlService;
import com.admin_fixed.service.VerifyJobService;

/**
 * @author qiupeiwei
 * @Date 2015-03-25
 */
@Controller("scheduleCtrlController")
@RequestMapping("/scheduleCtrl")
public class ScheduleCtrlController{
	protected Json json=new Json();
	private static final Logger log = Logger.getLogger(ScheduleCtrlController.class);
	
	@Autowired
	private ScheduleCtrlService scheduleCtrlService;
	@Autowired	
	private transient VerifyJobService verifyJobService;
	@Autowired
	private JobRecordService jobRecordService; 
	
	private static List<String> quartzJobNameList= new ArrayList<String>();//jobName 
	
	
	
	@RequestMapping(value="/scheduleCtrlList",method = RequestMethod.GET)
	public ModelAndView scheduleCtrlList(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("ScheduleCtrlList") Product product){
		String jobName = request.getParameter("jobName");
		String fieldExecFlag = request.getParameter("fieldExecFlag");
		String fieldLastExecFlag = request.getParameter("fieldLastExecFlag");
		ModelAndView model = new ModelAndView();
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		List<ScheduleCtrl> schedulelist=scheduleCtrlService.findByName(jobName,fieldExecFlag,fieldLastExecFlag,pageView);		
		model.addObject("list", schedulelist);
		model.addObject("jobName", jobName);
		model.addObject("fieldExecFlag", fieldExecFlag);
		model.addObject("fieldLastExecFlag", fieldLastExecFlag);
		model.addObject("pageView",pageView);
		model.setViewName("schedulectrl/schedulManager");
		return model;
	}
	
	@RequestMapping(value="/scheduleCtrlupdate",method = RequestMethod.GET)
	public void scheduleCtrlupdate(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("scheduleCtrlupdate") Product product) throws IOException{
		String id = request.getParameter("id");
		String execFlag = request.getParameter("execFlag");
		if(id == null){
			 response.sendRedirect("scheduleCtrlList");
		}
		if(execFlag == null){
			 response.sendRedirect("scheduleCtrlList");
		}
		ScheduleCtrl scheduleCtrl=new ScheduleCtrl();
		scheduleCtrl.setScheduleId(Integer.valueOf(id));
		scheduleCtrl.setExecFlag(Integer.valueOf(execFlag));
		scheduleCtrlService.update(scheduleCtrl);
		response.sendRedirect("scheduleCtrlList");
	}
	
	@RequestMapping(value="/executeJob",method = RequestMethod.POST)
	public void executeJob(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("executeJob") Product product) throws IOException{
		String jobNameParam = request.getParameter("jobNameParam");
		if(quartzJobNameList==null||quartzJobNameList.isEmpty()){
			quartzJobNameList.add(jobNameParam);
			executeJobMethod(jobNameParam);
		}else{
			if(!quartzJobNameList.contains(jobNameParam)){
				quartzJobNameList.add(jobNameParam);
				executeJobMethod(jobNameParam);
			}else{
				json.setSuccess(false);
				json.setMsg("�������Ѿ���ִ����,���Ժ�...");
			}
		}
		JSONObject jsonObject = JSONObject.fromObject(json);
		response.getWriter().write(jsonObject.toString());
		response.getWriter().flush();
	}
	
	public String getQuartzByMethod(String jobName){
		InputStream inputStream=null;
		try {
			String connCfgFile = "yj_admin.properties";
			
			inputStream = this.getClass().getClassLoader().getResourceAsStream(connCfgFile);   
			Properties properties = new Properties();   
			
			properties.load(inputStream);
			return properties.getProperty(jobName);
		} catch (IOException e) {
			e.printStackTrace();
			log.error("�쳣��"+e.getMessage());
		}finally{
			if(null!=inputStream){
				try {
					inputStream.close();
				} catch (IOException e) { 
					e.printStackTrace();
				}
			}
		}
		return null;		
	}
	public void executeJobMethod(String jobNameParam){
		String className=null;//����
		String methodJob=null;//������
		try {
			String jobNameObj=getQuartzByMethod(jobNameParam);//��ȡ������ͷ���
			if(jobNameObj!=null){
				String[] array=jobNameObj.split(",");
				className=array[0];
				methodJob=array[1];
				Object obj = null;
				System.out.println(SpringBeanFactory.getContext());
			    obj=SpringBeanFactory.getContext().getBean(className);
				Method invokeMethod=null;//��ȡ������ִ�еķ���
				Method[] methodArr = obj.getClass().getDeclaredMethods();
				for (Method method : methodArr) {
					if (methodJob.equals(method.getName())) {
						invokeMethod = method;
						break;
					}
				}
				
				if (invokeMethod != null){
					int types = invokeMethod.getModifiers();//1:���з�����2:˽�з���
					if(types == 2){
						invokeMethod.setAccessible(true);
					}
					//ִ�ж���
					invokeMethod.invoke(obj);
					
					//��������״̬
					verifyJobService.updateScheduleFlag(jobNameParam, 1);
					
			        //����ִ�м�¼
			        JobRecord job = new JobRecord();
			        job.setJobName(jobNameParam);
			        job.setJvmNum(InetAddress.getLocalHost().getHostAddress());
			        job.setExecFlag((short)1);
			        job.setExecMessage("�ֶ�����ִ�����쳣!");
			        jobRecordService.save(job);
					
			        json.setSuccess(true);
			        json.setMsg("�ֶ�ִ�гɹ�!");
				}else{
					json.setMsg("ִ��ʧ��,����"+methodJob+"����������,���ʵ��");
					log.error("ִ��ʧ��,����"+methodJob+"����������,���ʵ��");
				}
			}else {
				json.setMsg("ִ��ʧ��,"+jobNameParam+"������,���ʵ��");
				log.error("ִ��ʧ��,"+jobNameParam+"������,���ʵ��");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			json.setSuccess(false);
			json.setMsg("�ֶ�ִ�������쳣!������"+className+",������"+methodJob+" �쳣��Ϣ��"+e);
			log.error("�ֶ�ִ�������쳣!������"+className+",������"+methodJob+" �쳣��Ϣ��"+e);
		}
		quartzJobNameList.remove(jobNameParam);
	}
	
	
}
