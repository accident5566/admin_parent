package com.admin_fixed.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin_base.model.Backendrecord;
import com.admin_fixed.dao.BackendrecordDao;
import com.admin_fixed.service.BackendrecordService;


@Service
public class BackendrecordServiceI implements BackendrecordService {

	@Autowired
	private BackendrecordDao  backendrecordDaoI;
	
	@Override
	public boolean saveBackendRecords(Backendrecord backendrecord) {
		 Integer retrunCode = backendrecordDaoI.savePayStatus(backendrecord);
		 if(retrunCode <= 0){
		    	return false;
		    }
			return true;
	}

	@Override
	public boolean updateBackendPayStatus(Backendrecord backendrecord) {
		 Integer retrunCode = backendrecordDaoI.updateBackendPayStatus(backendrecord);
		    if(retrunCode <= 0){
		    	return false;
		    }
			return true;
	}

}
