package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.ProductEnterprise;

public interface ProductEnterpriseDao extends BaseMapper<ProductEnterprise>{

	
}
