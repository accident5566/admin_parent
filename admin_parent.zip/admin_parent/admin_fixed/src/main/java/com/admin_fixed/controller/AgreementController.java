package com.admin_fixed.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.model.ProductAgreementTemplate;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_fixed.service.AgreementService;
@Controller("agreementController")
@RequestMapping("/agreementInfo")
public class AgreementController {
	
	private static final Logger log = Logger.getLogger(AgreementController.class);
	
	@Autowired private AgreementService agreementServiceImpl;
	
	@RequestMapping(value="/showAllAgreementInfo",method = RequestMethod.GET,produces="text/plain;charset=UTF-8")
	public ModelAndView showAllAgreementInfo(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("agreementAdd") ProductAgreementTemplate agreement) throws UnsupportedEncodingException{
		List<ProductAgreementTemplate> ptypeList = agreementServiceImpl.getAllProductInfo();
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		if(agreement == null && agreement.getId() == null){
			agreement = new ProductAgreementTemplate();
		}
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		ModelAndView model = new ModelAndView();
		model.addObject("agreeTempleList",agreementServiceImpl.getAgreementByPage(pageView, agreement));
		model.addObject("pageView",pageView);
		model.addObject("ptypeList", ptypeList);
		model.addObject("agreementid",agreement.getId());
		model.setViewName("agreement/agreementManager");
		return model;
	}
	
	@RequestMapping(value="/addAgreementInfo",method = RequestMethod.POST)
	public void addAgreementInfo(HttpServletRequest request, HttpServletResponse response,@Valid @ModelAttribute("agreementAdd") ProductAgreementTemplate agreement) throws IOException{
		agreement.setCreatedat(new Date());
		agreement.setUpdatedat(new Date());
		boolean flag = agreementServiceImpl.saveProductInfo(agreement);
		if(flag){
       	    response.sendRedirect("showAllAgreementInfo");
          }else{
        	  response.sendRedirect("addAgreementPageRedirect");
          }
	}
	
	@RequestMapping(value="/addAgreementPageRedirect",method = RequestMethod.GET)
	public String addAgreementPageRedirect(HttpServletRequest request, HttpServletResponse response,@Valid @ModelAttribute("agreementAdd") ProductAgreementTemplate agreement){
		return "agreement/agreementAdd";
	}
	
	@RequestMapping(value="/updateAgreementPage",method = RequestMethod.GET)
	public String updateAgreementPage(HttpServletRequest request, HttpServletResponse response){
		 String id = request.getParameter("id");
		 if(id !=null && !id.equals("")){
			 request.setAttribute("agreementTemple",agreementServiceImpl.getProductInfo(new ProductAgreementTemplate(Integer.parseInt(id))));
			 return "agreement/agreementUpdate";
		 }
		 return "forward:agreementInfo/showAllAgreementInfo";
	}
	@RequestMapping(value="/updateAgreement",method = RequestMethod.POST)
	public void updateAgreement(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String content = request.getParameter("agreementcontent");
		Integer id = Integer.parseInt(request.getParameter("id"));
		Integer status = Integer.parseInt(request.getParameter("status"));
		ProductAgreementTemplate p = new ProductAgreementTemplate();
		p.setAgreementcontent(content);
		p.setId(id);
		p.setAgreementStatus(status);
		boolean flag = agreementServiceImpl.updateProductInfo(p);
		if(flag){
			 response.sendRedirect("showAllAgreementInfo");
		}else{
			 response.sendRedirect("updateAgreementPage?id="+id);
		}
	}
	
	
	@RequestMapping(value="/getAgreementInfo",method = RequestMethod.GET)
	public String getAgreementInfo(HttpServletRequest request, HttpServletResponse response){
		 String id = request.getParameter("id");
		 if(id !=null && !id.equals("")){
			 request.setAttribute("agreementTemple", agreementServiceImpl.getProductInfo(new ProductAgreementTemplate(Integer.parseInt(id))));
			 return "agreement/agreementDetail";
		 }
		     return "forward:agreementInfo/showAllAgreementInfo";
	}
	
}
