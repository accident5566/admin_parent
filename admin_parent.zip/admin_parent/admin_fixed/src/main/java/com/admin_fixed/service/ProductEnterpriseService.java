package com.admin_fixed.service;

import com.admin_base.model.ProductEnterprise;

public interface ProductEnterpriseService {

	public boolean saveProductEnterprise(ProductEnterprise proenter);
	
	public boolean updateProductEnterprise(ProductEnterprise proenter);
}
