package com.admin_fixed.dao;
import java.util.List;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.JobRecord;


public interface JobRecordDao extends BaseMapper<JobRecord>{
	public List<JobRecord> findRecordAll();
}
