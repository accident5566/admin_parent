package com.admin_fixed.service;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.codehaus.jackson.JsonProcessingException;

import com.admin_base.model.Orders;
import com.admin_base.model.OrdersEx;
import com.admin_base.model.Productextend;
import com.admin_base.dto.request.SreceivedPaymentDTO;
import com.admin_base.dto.response.OrderDetailDTOResult;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;

public interface OrderService {
	
	public List<Orders> getOrdersList(String productNo);
	public List<Orders> getSuccessOrdersByPage(PageParameter pageView, Orders orders);
	public OrdersEx getSuccessOrders(Orders orders);
	public MessageResult sreceivedPaymentsYL(String productIdentifier,String productType);
	public MessageResult sreceivedPaymentsToBalance(String productIdentifier, String productType, int paySource);
	public MessageResult sreceivedPaymentsYJ(String productIdentifier,String productType);
	public List<OrderDetailDTOResult> getOrdersByPage(PageParameter pageView, Orders orders);
    public List<OrderDetailDTOResult> getCheckBill(Orders orders, String start, String end);
    public List<OrderDetailDTOResult> getEndBill(Orders orders);
	public List<OrderDetailDTOResult> getSuccessOrdersList(SreceivedPaymentDTO sreceivedPaymentdto);
	public MessageResult sreceivedPayments(String productIdentifie,String productType) throws ParseException, JsonProcessingException, IOException, Exception;
	public boolean updateOrderStatus(OrderDetailDTOResult orderDetailDTOResult);
	public List<OrderDetailDTOResult> getSuccessOrdersLists(Productextend productextend);
	public boolean updateOrders(Orders orders);
	public List<Orders> getSuccessOrdersListBy(String productNo,Integer payForm);
	boolean returnPaymentsBackYiLian(List<OrderDetailDTOResult> orderListYiLian,String productIdentifier,String productType) throws Exception;
	boolean returnPaymentsBackBalance(List<OrderDetailDTOResult> orderListYiLian, String productIdentifier, String productType, int paySource) throws Exception;
	public List<Orders> getSuccessOrdersList(String productNo,Integer payForm);
	
}
