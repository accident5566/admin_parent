package com.admin_fixed.service;

/**
 * 
 * @author qiupeiwei
 *
 */
public interface VerifyJobService {
	
	public boolean verifyJob(String jobTriggerName) throws Exception;
	
	public void updateScheduleFlag(String jobTriggerName,Integer lastExecFlag);
	
}
