package com.admin_fixed.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.ScheduleCtrl;
public interface ScheduleCtrlDao extends BaseMapper<ScheduleCtrl> {

	public List<ScheduleCtrl> findByName(@Param("jobName")String jobName,@Param("execFlag")String execFlag,@Param("lastExecFlag")String lastExecFlag);

	public int updateSchedule(ScheduleCtrl schedulectrl);

	public int updateExecFlag(ScheduleCtrl schedulectrl);
}
