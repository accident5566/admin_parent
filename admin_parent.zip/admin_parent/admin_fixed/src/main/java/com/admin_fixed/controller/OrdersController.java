package com.admin_fixed.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.admin_base.constant.OrderStatus;
import com.admin_base.dto.response.SreceivedPayDTO;
import com.admin_base.model.Orders;
import com.admin_base.model.OrdersEx;
import com.admin_base.model.Product;
import com.admin_base.model.Productextend;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_base.util.MessageResult;
import com.admin_fixed.service.OrderService;
import com.admin_fixed.service.ProductService;
import com.admin_fixed.service.ProductextendService;

@Controller("ordersController")
@RequestMapping("/orders")
public class OrdersController {
	private static final Logger log = Logger.getLogger(OrdersController.class);
	@Autowired private OrderService orderServiceI;
	
	@Autowired private ProductService productServiceI; 
	
	@Autowired private ProductextendService productextendServiceI;
	@RequestMapping(value="/getOrderInfByProductNo",method = RequestMethod.GET)
	public ModelAndView getOrderInfByProductNo(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Orders order = null;
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		String productNo = request.getParameter("productNo");
		String ordersStatus = request.getParameter("ordersStatus");
		String orderPaySource = request.getParameter("orderPaySource");
		String  orderNo=request.getParameter("orderNo");
		if(ordersStatus == null || ordersStatus.equals("")){
			order = new Orders();
		}else{
			order = new Orders();
			order.setOrderStatus(Integer.valueOf(ordersStatus));
		}
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		if(orderNo!= null && orderNo!=""){
			order.setOrderNo(orderNo);
		}
		if(orderPaySource != null && orderPaySource != ""){
			order.setPaySource(Integer.valueOf(orderPaySource));
		}
		order.setProductIdentifier(productNo);
		ModelAndView model = new ModelAndView();
		model.addObject("ordersList",orderServiceI.getOrdersByPage(pageView, order));
		model.addObject("pageView",pageView);
		model.addObject("productNo",productNo);
		model.addObject("ordersStatusList",OrderStatus.getOrderStatusList());
		model.addObject("ordersStatus",ordersStatus);
		model.addObject("orderPaySource",orderPaySource);
		model.addObject("paySourceList",OrderStatus.getOrderPaySourceList());
		model.addObject("orderNo",orderNo);
		model.setViewName("order/OrdersSearch");
		return model;
	}

    /**
     * 通过用户信息查询定期产品订单
     * @return
     */
    @RequestMapping(value="/getOrderbyUser",method = RequestMethod.GET)
    public ModelAndView getOrderbyUser(HttpServletRequest request, HttpServletResponse response) throws IOException{
        Orders order = new Orders();
        PageParameter pageView = null;
        String pageNow = request.getParameter("pageNow");
        String realname = request.getParameter("realname");
//        if (realname != null)
//        	realname = new String(realname.getBytes("ISO-8859-1"),"UTF-8");
        String cellphone = request.getParameter("cellphone");
        String orderNo = request.getParameter("orderNo");

        if(StringUtils.isEmpty(pageNow)) {
            pageView = new PageParameter();
        }else{
            pageView = new PageParameter(Integer.parseInt(pageNow));
        }
        if(StringUtils.isNotEmpty(realname)){
            order.setRealname(realname);
        }
        if(StringUtils.isNotEmpty(cellphone)){
            order.setCellphone(cellphone);
        }
        if(StringUtils.isNotEmpty(orderNo)){
            order.setOrderNo(orderNo);
        }

        // 默认查询定期产品订单
        order.setOrderType(10);

        ModelAndView model = new ModelAndView();
        model.addObject("ordersList", orderServiceI.getOrdersByPage(pageView, order));
        model.addObject("realName", realname);
        model.addObject("cellphone", cellphone);
        model.addObject("orderNo",orderNo);
        model.addObject("pageView", pageView);
        model.setViewName("order/orderManager");
        return model;
    }
	
	@RequestMapping(value="/getSuccessOrderInfByProductNo",method = RequestMethod.GET)
	public ModelAndView getSuccessOrderInfByProductNo(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Orders order = null;
		PageParameter pageView = null;
		String pageNow  = request.getParameter("pageNow");
		String productNo = request.getParameter("productNo");
		String payFrom = request.getParameter("payFrom");
		String productType = request.getParameter("productType");
		String ordersStatus = request.getParameter("ordersStatus");
		String  orderNo=request.getParameter("orderNo");
		if(ordersStatus == null || ordersStatus.equals("")){
			order = new Orders();
		}else{
			order = new Orders();
			order.setOrderStatus(Integer.valueOf(ordersStatus));
		}
		if("".equals(pageNow) || pageNow == null){
			pageView = new PageParameter();
		}else{
			pageView = new PageParameter(Integer.parseInt(pageNow));
		}
		if(orderNo!= null && orderNo!=""){
			order.setOrderNo(orderNo);
		}
		order.setProductIdentifier(productNo);
		order.setPaySource(Integer.valueOf(payFrom));
		ModelAndView model = new ModelAndView();
		model.addObject("ordersList",orderServiceI.getSuccessOrdersByPage(pageView, order));
		model.addObject("pageView",pageView);
		model.addObject("orderex", orderServiceI.getSuccessOrders(order));
		model.addObject("productNo",productNo);
		model.addObject("ordersStatusList",OrderStatus.getOrderStatusList());
		model.addObject("ordersStatus",ordersStatus);
		model.addObject("orderNo",orderNo);
		model.addObject("payFrom",payFrom);
		model.addObject("productType",productType);
		model.setViewName("order/sreceivedPayments");
		return model;
	}
	
   @RequestMapping(value="/sreceivedPayments",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
   public @ResponseBody String sreceivedPayments(HttpServletRequest request, HttpServletResponse response) throws Exception{
	   String productIdentifier = request.getParameter("productIdentifier");
	   String paySource = request.getParameter("paySource");
	   String productType = request.getParameter("productType");
	   MessageResult messageresult = null;
	   if(paySource.equals("10")){
		   messageresult = orderServiceI.sreceivedPaymentsToBalance(productIdentifier, productType, 10);
	   }
      if(paySource.equals("20")){
          messageresult =  orderServiceI.sreceivedPaymentsYJ(productIdentifier,productType); 
	   }
	   return messageresult.getAsJSON();
	}
	
	
	@RequestMapping(value="/userPaymentRedirect",method = RequestMethod.GET)
	public  ModelAndView userPaymentRedirect(HttpServletRequest request,HttpServletResponse response) throws JsonProcessingException, IOException{
		ModelAndView mv = new ModelAndView();
		String productIdentifier = request.getParameter("productNo");
		List<Productextend> productextendYiLianList = productextendServiceI.searchByProIndentifierList(new Productextend(productIdentifier,10));
		List<Productextend> productextendYinJiaList = productextendServiceI.searchByProIndentifierList(new Productextend(productIdentifier,20));
		Orders  order = new Orders(productIdentifier,10);
		OrdersEx ylOrders = orderServiceI.getSuccessOrders(order);
		order = new Orders(productIdentifier,20);
		OrdersEx yjOrders = orderServiceI.getSuccessOrders(order);
		List<SreceivedPayDTO> screPayList = new ArrayList<SreceivedPayDTO>();
		if(ylOrders != null && ylOrders.getCountSize() > 0){
			if(productextendYiLianList != null && productextendYiLianList.size() > 0){
				screPayList.add(new SreceivedPayDTO(10, ylOrders.getCountSize(), ylOrders.getSumMoney(), productIdentifier,1));
			}else{
				screPayList.add(new SreceivedPayDTO(10, ylOrders.getCountSize(), ylOrders.getSumMoney(), productIdentifier,0));
			}
		 }
	    if(yjOrders != null && yjOrders.getCountSize() > 0){
	    	if(productextendYinJiaList != null && productextendYinJiaList.size() > 0){
	    		  screPayList.add(new SreceivedPayDTO(20, yjOrders.getCountSize(), yjOrders.getSumMoney(), productIdentifier,1));
	  		}else{
	  			 screPayList.add(new SreceivedPayDTO(20, yjOrders.getCountSize(), yjOrders.getSumMoney(), productIdentifier,0));
	  		}
	    }
		mv.addObject("screPayList", screPayList);
		mv.addObject("product", productServiceI.getProductByIdentifier(new Product(productIdentifier)));
		mv.setViewName("order/sreceivedPayCollect");
		return mv;
	} 
}
