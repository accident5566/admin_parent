package com.admin_fixed.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.admin_base.model.ScheduleCtrl;
import com.admin_base.mybatis.plug.PageParameter;
import com.admin_fixed.dao.ScheduleCtrlDao;
import com.admin_fixed.service.ScheduleCtrlService;

@Service
@Transactional(rollbackFor=Exception.class)
public class ScheduleCtrlServiceImpl implements ScheduleCtrlService {

	@Autowired
	private ScheduleCtrlDao scheduleCtrlDao;
	
	
	public List<ScheduleCtrl> findByName(String jobName,String execFlag,String lastExecFlag,PageParameter pageView) {
		List<ScheduleCtrl> scheduleList = null;
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		ScheduleCtrl sche = new ScheduleCtrl();
		if(execFlag != null){
			sche.setExecFlag(Integer.valueOf(execFlag));
		}
		if(lastExecFlag != null){
			sche.setLastExecFlag(Integer.valueOf(lastExecFlag));
		}
		sche.setJobName(jobName);
		parameterMap.put("t", sche);
		parameterMap.put("page", pageView);
		scheduleList = scheduleCtrlDao.getByPage(parameterMap);
		return scheduleList;
	}

	public int update(ScheduleCtrl scheduleCtrl) {
		return scheduleCtrlDao.updateExecFlag(scheduleCtrl);
	}
}
