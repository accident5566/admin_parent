package com.admin_fixed.dao;

import com.admin_base.dao.BaseMapper;
import com.admin_base.model.Productagreement;

public interface ProductagreementMapper extends BaseMapper<Productagreement> {

	public Integer updatePaContent(Productagreement productagreement);
}
